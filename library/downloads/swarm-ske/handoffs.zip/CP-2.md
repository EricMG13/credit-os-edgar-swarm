---
module_id: CP-2
module_name: Fundamental credit
issuer_id: ske
issuer_name: Skeena Resources Ltd
analysis_date: 2026-11-05
pathway: credit_snapshot
module_status: Ready with limitations
---

# Skeena Resources Ltd (ske): fundamental credit as of 2026-11-05

## Request

Skeena Resources Ltd (ske), as of 2026-11-05, credit snapshot pathway. Scope: the integrated fundamental credit view of the issuer, built from the supplied filings and the earlier work on source readiness, financial foundation and business and governance. No ratings, quotes, peers or executed legal documents are supplied, and no rating or security recommendation is given.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 40-F_2025-12-31_ske-20251231x40f.htm.jsonl | Annual report on Form 40-F of Skeena Resources Limited for the fiscal year ended December 31, 2025 (cover document; the annual information form, management's discussion and audited statements are exhibits not in this file) | 2026-03-24 (signature date) | db53ff9f8d0ca28c9b2edfb7202c651bb5c9ec8c989c923bb91bcc11481dd65e | Audit committee, internal control conclusion, exhibit list showing consents of independent technical firms, evidence that the annual exhibits are absent. |
| 6-K-EX-99.1_2026-03-24_exh_991.htm.jsonl | Press release furnished on Form 6-K, fourth quarter and annual 2025 results (text states no results) | 2026-03-24 | 2c276dba594c2df305ad125f0ece05f65167118a8d8060b6fa5d7edae3ae61ff | Company description and management's timing statement. |
| 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl | Press release furnished on Form 6-K, Q1 2026 results (text states no results) | 2026-05-15 | 232a824d9608ba6939a5237ea02786aae7b7f6f4a3ef441bec526b8439fdd718 | Risk wording on concentrate sales, smelter terms and export restrictions. |
| 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl | Press release furnished on Form 6-K, Q2 2026 results (text states no results) | 2026-08-13 | c4db22929f19fe544f88a7604e2308cdbc32700c4f1804f3c24f0271e5a2ab28 | Construction and commissioning timetable, updated technical report, risk list. |
| 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl | Condensed interim consolidated financial statements (unaudited) for the three and nine months ended September 30, 2025 and 2024 | 2025-11-12 (Board approval for issuance; filing date not stated) | a3b00c87d028f94b90bcea93f3fd8fe3b7d050af714766a40adae75d64ae2545 | Study history, February 2025 equity issue price, Gold Stream buy-down terms, title contingency. |
| 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl | Condensed interim consolidated financial statements (unaudited) for the three months ended March 31, 2026 and 2025 | 2026-05-15 (Board approval for issuance) | 23892a03c3bd6fd8f48bf0d8bc66e12cf89a073a244322844de1eee4158909d7 | Gold Stream covenants and security as last printed, royalty terms. |
| 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | Condensed interim consolidated financial statements (unaudited) for the three and six months ended June 30, 2026 and 2025 | 2026-08-13 (Board approval for issuance) | f089cfed7c41a13c1124e873c8cf9d986ddb809584e80594413f338c0cb3dda8 | Balance sheet, cash flows, notes, Gold Stream, royalties, liquidity table, fair value inputs, share-based payments. |
| Source readiness (CP-0) | Source readiness module output for this run | not stated | b8cc21a4710d7539c7efd1e066fad828d1c16932f406277db63b96082fda74a5 | Source authority, the gap list and the finding that annual exhibits and legal documents are not supplied. |
| Financial foundation (CP-1) | Financial foundation module output for this run | not stated | 0c95b30e440fdb585e5508eaa81b62b8ac9fba09e0feb32ae725c1152869c27c | Statement tables, net debt, debt principal to carrying value, derived EBITDA, claims outside Total Debt, post-balance-sheet adjustments. |
| Business & governance (CP-1A) | Business and governance module output for this run | not stated | 3873da9d7d624e07259f328a52722ae79359080f4d0785618194bf8d9700ba26 | Operating model, transactions, ownership, governance and sponsor behaviour findings. |

## Findings

### Bottom line

Skeena is a pre-revenue, single-project developer whose senior secured notes rest on construction funding and on Eskay Creek reaching production on management's 2027 timetable, so creditors are underwriting completion risk that prefunding mitigates but does not remove. The profile is weak on today's fundamentals: there is no revenue, derived EBITDA is negative in every period, and leverage cannot rank the credit.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–4; 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–2; Financial foundation (CP-1)

Prefunding is the main support: cash of CAD 134,808 thousand and restricted cash of CAD 500,853 thousand at June 30, 2026 exceed obligations due within a year of CAD 316,513 thousand, and a reserve funds the first three coupons. These balances already include the April 10, 2026 notes issuance; a pro forma position for earlier dates is not established. The main downside is a delay or overrun that outlasts the funds before first cash flow.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 4, 10–12; calculation C1; calculation C3

### Key findings

- The credit is a completion credit, not a cash-flow credit, so leverage and coverage cannot rank it and the time to first production is the measure that matters. The statements show no revenue, derived EBITDA of negative CAD 121,007 thousand for the six months to June 30, 2026 and cash used in operations of CAD 30,235 thousand, against additions to mineral property, plant and equipment of CAD 203,600 thousand, which is 80.95% of cash spent on operations, construction, prepayments and leases. Until commissioning every coupon is paid from money raised, so each month of delay adds spending with no inflow.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 2–3; Financial foundation (CP-1); calculation C6; calculation C17
- Funding covers management's timetable only if spending slows as construction finishes, because the cushion beyond the first-production window is thin. Cash outside the interest reserve of CAD 505,433 thousand lasts 9.78 months at the second quarter 2026 spending pace of CAD 51,676.33 thousand a month and 12.06 months at the first-half pace of CAD 41,916.67 thousand a month, which ends between late April and early July 2027 against a management target of April to June 2027 for first production. Management states that the notes proceeds are sufficient to reach commercial production if the conditions precedent to the notes are met and the statements give no budget, so this is arithmetic on current pace and not a forecast, but it shows how little slack a delay would leave before more financing is needed.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 3–4, 12; calculation C4; calculation C5; calculation C6; calculation C7; calculation C8
- Liquidity is conditional rather than free, because most of the cash cannot be spent without a release. Restricted cash is 78.79% of total cash of CAD 635,661 thousand, unrestricted cash covers only 0.43 times the obligations of CAD 316,513 thousand due within a year, the statements name no committed facility after the US$350,000,000 term loan was terminated on April 10, 2026, and the statements say further financing is needed if the construction funds cannot be released or the notes prove insufficient. A failed release condition would turn a prefunded credit into a near-term liquidity problem, and the Gold Stream minimum unrestricted cash test of CAD 25,000 thousand, printed to March 31, 2026 and not restated, would be a further tripwire if it still applies.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 4, 10–11, 14; 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, pages 10–11; calculation C2; calculation C3
- Claims on the same production narrow what reaches noteholders after commissioning, and the ranking of part of them is not stated. The Gold Stream takes 3.52% of payable gold for the life of the mine at 10% of the market price, ranks pari passu with the notes and is carried at CAD 209,286 thousand; royalty liabilities of CAD 214,718 thousand include a 1% net smelter royalty and an option on more; together the claims outside Total Debt are CAD 424,004 thousand, or 40.15% of the notes' carrying value of CAD 1,055,969 thousand. If the stream completion test is not met by September 30, 2027 the stream percentage rises by 0.05 percentage points to 0.28 percentage points, which cuts the cash left for the coupon at about the time the interest reserve is used up.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 12, 14–15; Financial foundation (CP-1); calculation C10
- Capital market access is demonstrated, which lowers refinancing and overrun-funding risk, but the evidence on its price is thin. The company placed US$750,000,000 of 8.50% notes due April 1, 2031, the notes' fair value of CAD 1,119,655 thousand is 6.03% above their carrying value, and common shares issued at CAD 14.70 in February 2025 were followed by options struck at CAD 36.32 on June 12, 2026, which indicates an equity value of about CAD 4,545,061 thousand, against which the notes' carrying value is 23.23%. An open equity market is the most plausible way to fund an overrun without adding senior claims, but the statements value the Gold Stream at a credit spread of 15.77% against an effective interest rate of 8.57% on the notes and print no price or yield, so the cost of new money is not established.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 12–13, 17; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 12; calculation C12; calculation C13; calculation C14; calculation C19
- Currency and gold exposure is a reported-loss issue before production and the main commercial exposure after it. US dollar liabilities exceed US dollar assets by US$524,531,000 against a Canadian dollar functional currency with no hedging, a 1% move in the exchange rate changes the loss before tax by CAD 7,465 thousand, and the six months to June 30, 2026 already carried a foreign exchange loss of CAD 17,684 thousand, almost all of it unrealised. After commissioning, gold sold at a US dollar price will offset the US dollar coupon, but the gold price input fell 6.75% from USD 4,308 to USD 4,017 per ounce in six months and a 5% move in the forward gold curve moves the Gold Stream liability by CAD 10,464 thousand, so the exposure shifts from the balance sheet to the cash flow that services the notes.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 2–3, 8, 10; calculation C15; calculation C16
- Governance is a secondary driver: there is no sponsor and no dividend, so the evidence points to dilution rather than cash leakage, and control is not established. Share-based payments were 49.96% of general and administration expenses in the first half of 2026 and outstanding awards equal 6.15% of shares outstanding; the audit committee has three independent members, management reports effective internal control at December 31, 2025 with KPMG LLP as auditor, but no holder list or board composition beyond the committee is supplied, which leaves sponsor and governance risk at Medium as Business & governance concludes.
  Basis: Business & governance (CP-1A); 40-F_2025-12-31_ske-20251231x40f.htm.jsonl, pages 5, 7; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 17–18; calculation C22

### Contrary evidence and what would change the view

The strongest evidence against a weak reading is that the financing was sized for construction: total cash is 2.01 times the obligations due within a year, a reserve funds the first three coupons, the project is described as fully permitted, feasibility studies from 2021 to 2023 are referred to in the statements and the annual report lists consents from eight independent engineering and environmental firms. The equity value indicated by option pricing is far above the notes' carrying value, the notes carry a fair value above carrying value, and a gold price near the USD 4,017 per ounce used in the valuations would favour project economics if costs are as management describes. If construction stays on schedule these facts make a funding failure before commissioning less likely than the absence of revenue suggests; what they cannot show is operating cost, which decides whether mine cash flow covers the coupon.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 4, 8, 12, 17; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 16; 40-F_2025-12-31_ske-20251231x40f.htm.jsonl, page 9; calculation C3; calculation C13

Evidence that would soften the view is release of restricted funds on schedule, ore mining and stockpiling starting on the timetable, spending in the third quarter of 2026 and later running below the first-half pace, initial production reported in the second quarter of 2027 and the stream completion test met before September 30, 2027, which keeps the stream at 3.52% of payable gold. Evidence that would harden it is spending near the second-quarter pace without matching progress, any change in the release conditions, new financing that ranks with or ahead of the notes, a fall in the notes' fair value below carrying value, or disclosure of a cost per ounce above what management implies by calling the mine one of the lowest-cost open-pit mines.
Basis: 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–3; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 4, 8, 14; calculation C6; calculation C7

### Limitations

- No mine plan, throughput, grade, recovery, operating cost per ounce or sustaining capital is in the supplied files, so cash flow after commissioning cannot be sized and the conclusion that mine cash flow can carry the 8.50% coupon is a judgement about structure, not a calculation.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–3; Business & governance (CP-1A)
- The months of funding use average spending in the first half and second quarter of 2026 and the interest reserve as deposited on April 10, 2026, because no budget and no reserve balance at June 30, 2026 are printed, so the conclusion that the cushion beyond the first-production window is thin moves with the pace assumed.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 3, 12; calculation C4; calculation C7; calculation C8
- No peer, sector or price series is supplied beyond the issuer's two gold price inputs, so the judgement that the business profile sits below that of producing gold issuers, and the reading of sector direction, rest on structure and not on benchmark data.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 8; Source readiness (CP-0)
- The statements value the Gold Stream at a company credit spread of 15.77% while the notes carry an effective interest rate of 8.57%, and they print no price, yield or spread for the notes, so the cost of any additional financing, and with it how easily an overrun could be funded, is not established.
  Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 13

### Company description and credit linkage

Skeena Resources Limited is a British Columbia development-stage mining company whose credit is one asset, the Eskay Creek Gold-Silver Project in the Golden Triangle, which management describes as fully permitted and under construction. The statements show no revenue and no segment schedule, so the business model is a construction project that will sell gold and silver once commissioned, and cash flow visibility is nil until then. Management expects initial production and cash flow in the second quarter of 2027 and commercial production in 2027, and a gold stream and royalties already claim part of future production, so debt service capacity, liquidity preservation and refinancing confidence all depend on completion on that timetable.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–4, 14–15; 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–2; 6-K-EX-99.1_2026-03-24_exh_991.htm.jsonl, page 1; Business & governance (CP-1A)

Management calls the mine one of the world's highest-grade and lowest-cost open-pit precious metals mines with silver by-product output, but no grade, cost or output figure is supplied to test the claim. The statements refer to a 2021 prefeasibility study, a 2022 feasibility study and a 2023 updated feasibility study, and the August 2026 release says an updated technical report is planned that could change the production profile and mine life, so the production base behind the timetable is subject to revision.
Basis: 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–2; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 16

### Ownership and group structure

No parent, sponsor or controlling holder is named and the statements are consolidated for Skeena Resources Limited with no subsidiary, guarantor or co-issuer identified, so structural subordination of the notes to subsidiary creditors is not established. The notes rank pari passu with the Gold Stream obligations, which carry general security and a share pledge in favour of the stream holder as printed to March 2026, and the notes' own collateral is not stated, so the position of noteholders against the stream holder on the same assets is not established.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 12; 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, page 11; Business & governance (CP-1A)

Financial policy shows no dividend in any period supplied and equity raised in 2025, and the share count rose by 3.16% between December 31, 2025 and June 30, 2026 through option exercises and vesting of share units. Business & governance puts sponsor and governance risk at Medium on incomplete evidence: the evidence shows no extraction and the filings supply no holder list, so creditor alignment is plausible but unproven.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 2; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 12; Business & governance (CP-1A); calculation C21

### Revenue, cost and capital intensity

There is no revenue to test for durability. After commissioning revenue will come from gold and silver sold as concentrate, less the stream and royalty deductions, and its predictability will turn on throughput, metal prices and smelter terms, none of which the filings let a reader test. The May 2026 release lists concentrate sales risks, including smelter terms that are market dependent, possible export restrictions on critical minerals that limit the choice of smelters, and geopolitical risk in contracting with customers in regions such as China, so revenue visibility after commissioning rests on contracts the filings do not describe and a policy change could cut the buyers available.
Basis: 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl, page 3; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–3

Cost cannot be assessed beyond the construction stage. Cash used in operations was CAD 30,235 thousand in the first half of 2026 against additions of CAD 203,600 thousand, and general and administration expenses of CAD 43,418 thousand included share-based payments of CAD 21,690 thousand. Once built, an open-pit mine is mostly fixed cost, so margins will be sensitive to throughput and recoveries, while the stream, delivered at 10% of the market price, and the royalties scale with revenue and so thin the cash left for debt without adding fixed cost. Cost flexibility before commissioning is low because construction is committed: contractual commitments due within a year are CAD 138,109 thousand, and although some may contain cancellation clauses the statements say they are disclosed on management's intent to fulfil them.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 3, 10–11, 14; calculation C6

Capital intensity dominates at this stage. Additions to mineral property, plant and equipment are 80.95% of first-half cash spending, and the statements do not split maintenance from growth capital, so capex flexibility over the debt life cannot be assessed. Conversion of EBITDA to free cash flow is not calculable because EBITDA is negative; the only free cash flow evidence is outflow, with CAD 242,979 thousand used on operations, additions and prepayments in the six months to June 30, 2026, so creditors depend on completion rather than on conversion.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 2–3; calculation C6; calculation C17

### Industry forces, macro factors and SWOT

Competitive rivalry works through the cost curve because a gold producer takes the gold price, and Eskay Creek's cost position is asserted by management and not evidenced, so margin resilience in a gold price fall is not established. Barriers to new entrants are permits and capital, and the project already holds its permits, but the release risk language names changes to, delays in or challenges to permits and the environmental assessment certificate, so permit durability stays a creditor risk. Substitutes are not a driver for gold, and silver adds a second price exposure. Concentrate buyers and smelters set terms and the May 2026 release names smelter terms and export restrictions as risks. Contractors, equipment, power and labour matter during construction, and the August 2026 release names cost inflation, tariffs, supply-chain disruption, grid energization and contractor performance, each of which raises the chance of an overrun that would be paid from a finite fund.
Basis: 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–3; 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl, pages 3–4

Four groups of external factors matter to the credit. Regulatory and Indigenous relationships and permits are named risks, and the 2024 court decision on rights to stored materials at Albino Lake was sent back for rehearing with no outcome printed in the 2026 statements, although the company says it should not affect the carrying value of Eskay. The gold price, exchange rate and interest rates are unhedged, and the statements name inflation among cost risks. Metallurgical testwork and the updated technical report can still change the production profile and mine life.
Basis: 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 2–3; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 16; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8–10

In credit terms the strengths are prefunded construction with a reserve for the first three coupons, a fully permitted project and open debt and equity markets. The weaknesses are no revenue, one asset, restricted liquidity, claims from the stream and royalties on the same production, and an unhedged US dollar liability position. Opportunities are an updated technical report that improves the production profile, completion before September 30, 2027 that keeps the stream at 3.52% of payable gold, and redemption at fixed prices from April 1, 2028 that allows refinancing once cash is generated. Threats are construction delay or overrun, failure to release restricted funds, a lower gold price and a permit or title challenge.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 4, 12–14; 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–3; calculation C3; calculation C10

### Strengths and weaknesses

The first strength is prefunding: the notes placed CAD 683,168 thousand into restricted accounts, so construction and the first three coupons do not depend on market access in the next year, which lowers near-term default risk, although the release terms are unseen. The second is demonstrated capital market access, with US$750,000,000 of notes placed, equity raised in 2025 and a later share price indicator far above that issue price, which gives a route to fund an overrun and supports recovery through an equity cushion. The third is the project's status as fully permitted and under construction with a feasibility-level study base, which removes permitting from the near-term path and narrows the downside to execution and funding.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 4, 8, 12, 17; 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, page 1; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, pages 12, 16; Business & governance (CP-1A)

The first weakness is the absence of revenue on a single project, which makes completion the only route to debt service and leaves leverage and coverage not calculable. The second is conditional liquidity, with 78.79% of cash restricted and no committed facility named. The third is the stack of claims on the same production, CAD 424,004 thousand outside Total Debt with the stream pari passu with the notes, which lowers cash for the coupon and recoveries. The fourth is an unhedged US dollar liability position and a gold price that moves the stream and royalty values and the future revenue of the project.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 10, 14–15; Financial foundation (CP-1); calculation C2

### Financial profile and credit quality

The financial profile is weak today and cannot yet be measured in the usual way. Scale and diversification are weak because the issuer has no revenue and one project in one jurisdiction, and the competitive advantage claimed by management is not evidenced. Cost and capex flexibility are low because construction is committed, margin stability cannot be assessed without revenue, and free cash flow is an outflow. Capital market access is demonstrated, since a large secured issue and an equity raise have been completed, but it is priced at an 8.50% coupon with a covenant package the filings do not show. Liquidity covers the stated timetable on management's own assertion but falls short on the current spending pace, and it is conditional on release of restricted funds; financial policy is neutral so far, with no distributions and dilution through share-based pay.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–3, 10–11, 17–18; Financial foundation (CP-1); Business & governance (CP-1A)

The trend is dominated by the April 10, 2026 financing. Funded debt first appears with the notes, carried at CAD 1,055,969 thousand, and net debt on unrestricted cash is CAD 921,161 thousand at June 30, 2026, which already includes the April 10, 2026 notes issuance; a pro forma net debt for the earlier balance sheet dates is not established. The Gold Stream liability fell from CAD 421,902 thousand at December 31, 2025 to CAD 209,286 thousand after a buy-down that cost US$184,000,000, which swaps a revenue-linked claim whose buy-down price embedded an imputed 18% return for notes at an 8.50% coupon, adding US$15,640,000 a year of fixed interest on that portion before production but leaving more of the future gold revenue to the company. Key missing datapoints are full-year statements, cash interest paid, operating cost and the indenture covenants.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 12–14; 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, page 10; Financial foundation (CP-1); calculation C11; calculation C20

### Outlook, tailwinds and headwinds

Over the next 12 months to 24 months the outcome turns on construction and commissioning. Tailwinds are a permitted project, funded construction, a gold price near USD 4,017 per ounce in the valuation inputs and an equity market that has accepted the company's shares. Headwinds are execution risk on a single project, spending at a pace that leaves little slack beyond the first-production window, and a calendar that crowds together the stream completion test on September 30, 2027, the end of the reserve cover around eighteen months after issue and the first date of fixed redemption prices, April 1, 2028. The fourth semi-annual coupon, about two years after issue, is the first that must be paid from operating cash or other funds, so first production needs to arrive well before it.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 4, 8, 12–14; 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 1–2; calculation C7; calculation C8; calculation C9

Over three to five years the notes are the only debt maturity, due in full on April 1, 2031, with redemption prices starting at 104.25% from April 1, 2028 and falling to par from 2030, and a right to redeem up to 40% with equity proceeds at 108.5% before April 1, 2028. A producing mine would allow refinancing or equity-funded paydown on those terms, while a delayed one would leave the single maturity to be met from a smaller cash cushion. Sector headwinds are cost inflation, tariffs and smelter and export policy, and the sector tailwind is the gold price level, which also raises the stream and royalty claims in value.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 11–13; 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl, page 3

### Downside scenario

The realistic downside is a construction or commissioning delay on the single project. Management's own risk list names delays in grid energization, commissioning or ramp-up and cost overruns, so the scenario starts with a delay of a quarter or more to initial production. The first operational break is that ore mining and stockpiling slip, so the mill is not fed on time and no concentrate is sold. The financial transmission is that spending continues at CAD 41,916.67 thousand to CAD 51,676.33 thousand a month with no inflow, so cash outside the interest reserve of CAD 505,433 thousand is used up between late April and early July 2027, and the statements say additional financing would then be needed.
Basis: 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, pages 2–3; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 3–4; calculation C4; calculation C7; calculation C8

The consequences follow in order. If the completion test is not met by September 30, 2027 the stream percentage steps up, by 0.05 percentage points if completion falls in the first quarter after that date and by 0.28 percentage points if it falls after the third, and the fourth coupon, about two years after issue, may fall due before operating cash arrives. New money would be raised during construction, probably as equity given the indicated equity cushion, or as debt or a stream whose cost the statements do not establish, since the stream is valued at a 15.77% credit spread. Management's levers are limited: committed spending is CAD 138,109 thousand within a year, marketable securities are CAD 14,240 thousand and equity is the main source. Resilience appears sufficient to avoid liquidity distress if first production arrives in the second quarter of 2027 and spending slows as construction ends, and insufficient for a delay beyond about a quarter without new money, so default risk before commissioning is driven by funding access rather than by operations.
Basis: 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 8, 10–11, 14; calculation C7; calculation C8; calculation C10; calculation C11

### Overall credit view

Overall, Skeena presents a weak business profile for a leveraged credit today, with no revenue and one project, supported by prefunded construction, a permitted project and open capital markets. Against typical leveraged gold issuers, which earn operating cash flow, its profile is weaker by construction, although no peer figures are supplied. Cash-flow durability cannot yet be established because there is no operating history to measure and no cost data to size margins. Refinancing capacity is likely to depend on commissioning on schedule, the gold price and the cost of any new money. The primary downside path is a construction delay that outlasts restricted funds before first cash flow. Further analysis would require operating cost and production data, the construction budget, the indenture and stream agreement and statements after June 30, 2026.
Basis: Financial foundation (CP-1); Business & governance (CP-1A); Source readiness (CP-0); calculation C7; calculation C8

### Credit figures used

| Measure | Amount | Period | Unit | Source |
|---|---|---|---|---|
| Cash and cash equivalents | 134,808 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1 |
| Restricted cash | 500,853 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1 |
| Total Debt (carrying value of the senior secured notes) | 1,055,969 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1; Financial foundation (CP-1) |
| Interest reserve deposited | 130,228 (US$94,208,000) | 2026-04-10 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 12 |
| Proceeds placed in restricted accounts | 683,168 (US$494,208,000) | 2026-04-10 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 12 |
| Principal of the senior secured notes | 750,000,000 | 2026-04-10 | US$ | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 12 |
| Coupon and effective interest rate of the notes | 8.50%; 8.57% | 2026-06-30 | percent a year | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 12–13 |
| Fair value of the notes | 1,119,655 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 8 |
| Gold Stream buy-down paid | 254,352 (US$184,000,000) | 2026-04-10 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 3, 14 |
| Imputed return in the buy-down price | 18% | as printed to 2026-03-31 | percent | 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, page 10 |
| Gold Stream derivative liability | 209,286; 421,902 | 2026-06-30; 2025-12-31 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 14 |
| Royalty liabilities | 214,718 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 15 |
| Derived EBITDA, six months | -121,007 | 2026-01-01 to 2026-06-30 | CAD thousands | Financial foundation (CP-1) |
| Derived EBITDA, second quarter | -22,065 | 2026-04-01 to 2026-06-30 | CAD thousands | Financial foundation (CP-1) |
| Foreign exchange loss | 17,684 | 2026-01-01 to 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 2 |
| Marketable securities | 14,240 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1 |
| Effect on loss before tax of a 1% move in the exchange rate | 7,465 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 10 |
| Effect on loss before tax of a 5% move in the forward gold curve | 10,464 | 2026-06-30 | CAD thousands | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 10 |
| Redemption terms of the notes | 104.25% from April 1, 2028 to March 31, 2029; par from April 1, 2030; up to 40% redeemable at 108.5% with equity proceeds before April 1, 2028; 101% on a change of control | as printed | percent of principal | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 12–13 |
| Studies referred to in the statements | Prefeasibility 2021; feasibility 2022; updated feasibility 2023 | as printed | year | 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 16 |

### T2.1 Source register

| source_document_id | source_document_name | source_quality | period | entity_covered | data_supplied | limitation | downstream_use |
|---|---|---|---|---|---|---|---|
| S1 | 40-F_2025-12-31_ske-20251231x40f.htm.jsonl | Medium | Fiscal year 2025 | Skeena Resources Limited | Audit committee, internal control conclusion, exhibit list with consents of technical firms, shares outstanding at December 31, 2025 | Cover document only; annual information form, management's discussion and audited statements are not supplied | Governance and technical-support evidence |
| S2 | 6-K-EX-99.1_2026-03-24_exh_991.htm.jsonl | Low | Annual 2025 release | Skeena Resources Limited | Company description and management's timing statement | Management language; no results in the text | Company description |
| S3 | 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl | Low | Q1 2026 release | Skeena Resources Limited | Concentrate sales, smelter and export risk wording | Management language; no results in the text | Revenue drivers and sector forces |
| S4 | 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl | Low | Q2 2026 release | Skeena Resources Limited | Timetable, updated technical report, risk list | Management language; no results in the text | Downside scenario and outlook |
| S5 | 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl | Medium | Nine months to September 30, 2025 | Skeena Resources Limited, consolidated | Study history, February 2025 issue price, buy-down terms, title contingency | Unaudited; superseded by later periods for balances | Market access and company description |
| S6 | 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl | Medium | Three months to March 31, 2026 | Skeena Resources Limited, consolidated | Gold Stream covenants and security as last printed, royalty terms | Unaudited; covenants not restated after the buy-down | Liquidity, claims and monitoring triggers |
| S7 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | Medium | Six months to June 30, 2026 | Skeena Resources Limited, consolidated | Balance sheet, cash flows, notes, Gold Stream, royalties, liquidity table, valuation inputs | Unaudited; no subsequent events note; no budget or reserve balance | All findings and calculations |
| S8 | Source readiness (CP-0) | Medium | Run as of 2026-11-05 | Skeena Resources Ltd | Source authority and gap list | Reports annual exhibits and legal documents as not supplied | Source gate |
| S9 | Financial foundation (CP-1) | Medium | Periods to June 30, 2026 | Skeena Resources Ltd | Statement tables, net debt, derived EBITDA, claims outside Total Debt, post-balance-sheet row | No positive EBITDA; no full-year 2025 statements | Financial inputs |
| S10 | Business & governance (CP-1A) | Medium | Periods to June 30, 2026 | Skeena Resources Ltd | Operating model, transactions, governance and sponsor findings | No holder list, board detail or legal documents | Ownership and governance inputs |

### T2.10 Materiality filter

| Rank | Driver | Evidence | Risk Mechanic | Credit Implication | Direction | Confidence |
|---|---|---|---|---|---|---|
| 1 | Completion and commissioning of one project | No revenue in any period and derived EBITDA of CAD -121,007 thousand for the six months to June 30, 2026 (Financial foundation (CP-1)); initial production targeted for Q2 2027 with delays, overruns and commissioning failure named as risks (Business & governance (CP-1A)) | No operating cash flow until commissioning, so each month of delay adds spending from a finite fund | Dominant driver of default probability; leverage cannot rank the credit and timing decides the outcome | Negative | High |
| 2 | Prefunded construction and three coupons | Total cash of CAD 635,661 thousand against obligations due within a year of CAD 316,513 thousand, or 2.01x; interest reserve of CAD 130,228 thousand for three semi-annual payments (calculations C1, C3) | Removes dependence on market access over the next year and decouples early coupons from operations | Lowers near-term default probability if release of funds holds | Positive | Medium |
| 3 | Release of restricted funds with no committed facility | Restricted cash is 78.79% of total cash; the US$350,000,000 term loan was terminated on April 10, 2026; the statements say further financing is needed if funds cannot be released (calculation C2) | Free cash is 0.43x obligations due within a year, so a release failure is a short-term liquidity event | Raises liquidity and refinancing risk; release terms are not seen | Negative | Medium |
| 4 | Claims on the same production | Gold Stream at 3.52% of payable gold at 10% of market price, pari passu with the notes; royalty liabilities of CAD 214,718 thousand; claims outside Total Debt of CAD 424,004 thousand, or 40.15% of the notes' carrying value (calculations C10, C18) | Revenue per ounce falls before debt service, and the stream percentage rises by up to 0.28 percentage points if the completion test is missed | Reduces cash for the coupon and recoveries; ranking of the royalties is not stated | Negative | Medium |
| 5 | Capital market access and equity cushion | US$750,000,000 of 8.50% notes placed; fair value 6.03% above carrying value; shares issued at CAD 14.70 in February 2025 and options struck at CAD 36.32 in June 2026, indicating equity value near CAD 4,545,061 thousand (calculations C12, C13, C14, C19) | Open debt and equity markets give a route to fund an overrun without adding senior claims | Lowers refinancing and overrun risk and supports recovery; price and yield are not printed | Positive | Medium |
| 6 | Gold price level | Gold input of USD 4,017 per ounce at June 30, 2026, down 6.75% from USD 4,308 at December 31, 2025 (calculation C15) | Price drives future revenue, the stream and royalty values and the equity cushion, while cost per ounce is not supplied | Supports project value if costs are as management describes; a fall pressures all three | Positive | Low |
| 7 | US dollar liabilities against a Canadian dollar functional currency | US dollar liabilities exceed US dollar assets by US$524,531,000; no hedging; a 1% move changes loss before tax by CAD 7,465 thousand (calculation C16) | The mismatch hits the reported loss now and the cost of the coupon only if revenue is not in US dollars | Modest before production and offset by US dollar gold prices after it | Negative | Medium |
| 8 | Dilution through share-based pay | Share-based payments are 49.96% of general and administration expenses; awards equal 6.15% of shares outstanding (calculation C22) | Non-cash cost with no cash leakage evidenced; control is not established | Low weight for creditors | Negative | Low |

### T2.12 Monitoring triggers

| Trigger | Threshold / Signal | Why It Matters | Credit Impact | Source / Limitation |
|---|---|---|---|---|
| Revenue decline | No revenue exists. Signal: initial production and cash flow not reported by the end of Q2 2027, management's target; once sales begin, quarterly gold and silver sold below plan, which is not supplied | Revenue is the first source of debt service that is not money raised | A slip beyond Q2 2027 uses the funds outside the reserve, which last 9.78 months to 12.06 months from June 30, 2026 on current pace | 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl, page 1; calculation C7; calculation C8 |
| EBITDA margin pressure | No positive EBITDA exists; derived EBITDA was CAD -22,065 thousand in Q2 2026. Quantitative threshold not available in provided materials. Signal: first positive quarterly EBITDA after commissioning, and any cost per ounce disclosed above management's low-cost description | Margin decides whether mine cash flow covers the 8.50% coupon | Negative margins after commissioning would extend reliance on new money | Financial foundation (CP-1) |
| FCF deterioration | Cash used in operations, additions, prepayments and lease payments above CAD 51,676.33 thousand a month without matching construction progress; first positive free cash flow after commissioning | Spending pace sets how long the funds last | Funds outside the reserve last 9.78 months at the Q2 2026 pace and 12.06 months at the first-half pace | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3; calculation C5; calculation C6 |
| Liquidity reduction | Unrestricted cash below CAD 134,808 thousand at the next balance sheet without a matching release of restricted cash; any restricted funds that cannot be released; Gold Stream minimum unrestricted cash of CAD 25,000 thousand, printed to March 31, 2026 and not restated | Free cash covers only 0.43x the obligations due within a year | A failed release turns a prefunded credit into a short-term liquidity problem | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 4, 10–11; 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, pages 10–11 |
| Leverage increase | No leverage multiple is calculable while EBITDA is negative. Signal: new debt, stream deposit or royalty financing beyond the notes; claims outside Total Debt above CAD 424,004 thousand | New claims compete for the same production cash flow | Dilutes recovery and the cash left for the coupon | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 14–15; Financial foundation (CP-1) |
| Refinancing delay | Statements or announcements of further financing needs; the notes' fair value falling below carrying value of CAD 1,055,969 thousand, against a fair value of CAD 1,119,655 thousand at June 30, 2026; fixed redemption prices from April 1, 2028 and maturity April 1, 2031 | Market pricing is the only external read on completion risk and the cost of new money | A fall below carrying value would signal higher refinancing cost before commissioning | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 12–13 |
| Sponsor/shareholder action | No sponsor is named. Signal: first dividend or distribution, a change of control, which requires an offer at 101% of principal, or share count rising well above 125,139,335 beyond option exercises | Distributions or control changes alter financial policy and creditor alignment | Cash leakage or a put of the notes would strain liquidity | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 2, 13 |
| Sector deterioration | Gold price below the USD 4,017 per ounce used in valuation at June 30, 2026, or a fall in the forward gold curve, where a 5% fall changes loss before tax by CAD 10,464 thousand; tighter smelter terms or export restrictions | Gold price drives project revenue and the stream and royalty claims | Lower price cuts project value and the equity cushion that supports funding | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 10; 6-K-EX-99.1_2026-05-15_ske-20260515xex99d1.htm.jsonl, page 3 |

### cp2.cp_model_strengths_weaknesses Ranked credit strengths and weaknesses

<!-- table-id: cp2.cp_model_strengths_weaknesses -->
| direction | rank | label | mechanism | evidence_ids | status | source_id | source_locator | as_of |
|---|---|---|---|---|---|---|---|---|
| STRENGTH | 1 | Prefunded construction and first three coupons | Restricted accounts and a reserve remove near-term dependence on market access, lowering near-term default risk while making release a condition | S7; C1; C3; C4 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 1, 4, 10–12 | 2026-06-30 |
| STRENGTH | 2 | Demonstrated debt and equity market access | Notes placed, equity raised in 2025 and a later share price indicator far above the issue price give a route to fund an overrun without adding senior claims, supporting recovery | S5; S7; C12; C13; C14; C19 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 8, 12–13, 17 | 2026-06-30 |
| STRENGTH | 3 | Fully permitted project under construction | Removes permitting from the near-term path and narrows the downside to execution and funding | S4; S5 | READY | 6-K-EX-99.1_2026-08-13_ske-20260813xex99d1.htm.jsonl | page 1 | 2026-08-13 |
| WEAKNESS | 1 | No revenue on a single project | Completion is the only route to debt service, so delay extends spending from finite funds and leverage cannot be calculated | S7; S9; C6; C7; C8 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 1–3 | 2026-06-30 |
| WEAKNESS | 2 | Conditional liquidity | Restricted cash is most of total cash and no committed facility is named, so a release failure becomes a short-term liquidity event | S7; C2; C3 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 1, 4, 14 | 2026-06-30 |
| WEAKNESS | 3 | Claims on the same production | Stream and royalties take gold and revenue before note service, lowering cash for the coupon and recoveries | S7; S9; C10; C18 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 1, 14–15 | 2026-06-30 |
| WEAKNESS | 4 | US dollar and gold price exposure | Unhedged US dollar net liability and gold-linked stream and royalty values move the loss now and cash flow after production | S7; C15; C16 | READY | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl | pages 8, 10 | 2026-06-30 |

### Confidence inputs

| Input | Value |
|---|---|
| Directly Sourced | 31 |
| Calculated | 16 |
| Assumption-Based | 0 |
| Analyst Inference | 11 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 1 |
| Insufficient Information | 7 |
| Fields present | 15 |
| Fields total | 15 |
| Source gate | partial |
| CRITICAL | 0 |
| MATERIAL | 4 |
| MINOR | 4 |

### Map: credit-risk transmission

| From | Relationship | Edge type | To | Evidence |
|---|---|---|---|---|
| Eskay Creek construction and commissioning | Delay or overrun lengthens the period without revenue | Analyst Interpretation | Cash burn before first production | Release risk language names delays and cost overruns |
| Management timetable | Sets when first cash flow can start | Management Language | Cash flow available for note service | Initial production targeted for Q2 2027 |
| Cash burn before first production | Draws down cash and construction funds | Documentary Fact | Restricted funds and interest reserve | First half 2026 cash outflow CAD 251,500 thousand |
| Restricted funds and interest reserve | Release is a condition for spending | Documentary Fact | Liquidity runway | More financing if funds cannot be released |
| Liquidity runway | A shortfall leads to a need for new money | Analyst Interpretation | Need for additional financing | Funds last 9.78 months to 12.06 months on current pace |
| Need for additional financing | Equity route adds no senior claim | Analyst Interpretation | Noteholder recovery and default risk | Shares issued at CAD 14.70; options struck at CAD 36.32 |
| Gold Stream and royalty claims | Take gold and revenue before note service | Documentary Fact | Cash flow available for note service | Stream is 3.52% of payable gold at 10% of price |
| Cash flow available for note service | Needed once the interest reserve is used | Documentary Fact | Noteholder recovery and default risk | Reserve covers three semi-annual payments |
| Gold price and US dollar | Move stream and royalty values and US dollar debt | Documentary Fact | Gold Stream and royalty claims | Gold input USD 4,017 per ounce at June 30, 2026 |

## Calculations

Amounts are in thousands of Canadian dollars as printed unless a row says otherwise; each row works from the figures it lists, and months are counted from June 30, 2026.

| ID | Calculation | Inputs | Result | Source |
|---|---|---|---|---|
| C1 | Total cash at June 30, 2026 | Cash and cash equivalents 134,808 plus restricted cash 500,853 (current 453,925 plus non-current 46,928) | 635,661 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1 |
| C2 | Restricted share of total cash | 500,853 divided by 635,661 | 78.79% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1 |
| C3 | Cash against obligations due within one year | Obligations due within one year 316,513, made up of accounts payable 46,187, leases 25,142, long-term debt 88,581, NSR Royalty liability 15,589, reclamation and mine closure 72, other liabilities 2,833 and contractual commitments 138,109; total cash 635,661 divided by 316,513; unrestricted cash 134,808 divided by 316,513 | 316,513 as printed and as summed; 2.01x; 0.43x | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 10–11 |
| C4 | Cash outside the interest reserve | Total cash 635,661 less interest reserve 130,228 as deposited on April 10, 2026; the reserve balance at June 30, 2026 is not printed | 505,433 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 12 |
| C5 | Spending pace, second quarter 2026 | Cash used in operations 15,057 plus additions to mineral property, plant and equipment 131,352 plus construction prepayments and deposits 4,324 plus lease payments 4,296 is 155,029; divided by 3 months | 51,676.33 a month | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3 |
| C6 | Spending pace, first half 2026 | Cash used in operations 30,235 plus additions 203,600 plus construction prepayments and deposits 9,144 is 242,979; plus lease payments 8,521 is 251,500; divided by 6 months | 41,916.67 a month | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3 |
| C7 | Months of funding at the second quarter pace | 505,433 divided by 51,676.33; the second quarter of 2027 begins 9 months and ends 12 months after June 30, 2026 | 9.78 months, which is late April 2027 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3; calculation C4; calculation C5 |
| C8 | Months of funding at the first half pace | 505,433 divided by 41,916.67 | 12.06 months, which is early July 2027 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3; calculation C4; calculation C6 |
| C9 | Months of coupons covered by the interest reserve | Interest reserve 130,228 divided by long-term debt payments due within one year 88,581 is 1.47 years; times 12 months | 17.64 months, about eighteen months after the April 10, 2026 issue | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 10–12 |
| C10 | Gold Stream percentage step-ups if the completion test is missed | 3.57% less 3.52%; 3.62% less 3.52%; 3.67% less 3.52%; 3.80% less 3.52% | 0.05, 0.10, 0.15 and 0.28 percentage points | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 14 |
| C11 | Annual coupon on the buy-down portion | 8.50% times US$184,000,000 | US$15,640,000 a year | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 4, 12 |
| C12 | Equity value indicated by the option strike price | Shares outstanding 125,139,335 times CAD 36.32 (options granted on June 12, 2026) is CAD 4,545,060,647 | 4,545,061 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 2, 17 |
| C13 | Notes carrying value against indicated equity value | 1,055,969 divided by 4,545,061 | 23.23% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1; calculation C12 |
| C14 | Option strike against the February 2025 issue price | CAD 36.32 divided by CAD 14.70 | 2.47x | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 17; 6-K-EX-99.2_2025-11-13_ske-20251113xex99d2.htm.jsonl, page 12 |
| C15 | Change in the gold price input | USD 4,017 less USD 4,308 is USD -291; divided by USD 4,308 | -6.75% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 8 |
| C16 | US dollar net liability | US dollar liabilities of accounts payable 667,000, long-term debt 743,067,000 and Gold Stream derivative 147,271,000 are US$891,005,000; less cash 14,032,000 and restricted cash 352,442,000 which are US$366,474,000 | US$524,531,000 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 10 |
| C17 | Additions as a share of first half spending | 203,600 divided by 251,500 | 80.95% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 3; calculation C6 |
| C18 | Claims outside Total Debt | Royalty liabilities 214,718 plus Gold Stream derivative liability 209,286 is 424,004; divided by notes carrying value 1,055,969 | 424,004; 40.15% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 14–15 |
| C19 | Notes fair value above carrying value | Fair value 1,119,655 less carrying value 1,055,969 is 63,686; divided by 1,055,969 | 63,686; 6.03% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1, 8 |
| C20 | Net debt on unrestricted cash at June 30, 2026 | Total Debt 1,055,969 less cash and cash equivalents 134,808; the April 10, 2026 notes issuance is inside this balance sheet and Financial foundation states no pro forma figure for the earlier balance sheets | 921,161 | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1; Financial foundation (CP-1) |
| C21 | Share count change, December 31, 2025 to June 30, 2026 | 125,139,335 less 121,300,287 is 3,839,048, equal to option exercises 2,272,608 plus restricted share units 508,737 plus performance share units 1,057,703; divided by 121,300,287 | 3.16% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 2 |
| C22 | Share-based pay and awards | Share-based payments 21,690 divided by general and administration expenses 43,418; awards 5,231,846 options plus 266,425 restricted share units plus 1,853,200 performance share units plus 346,587 deferred share units is 7,698,058, divided by 125,139,335 | 49.96%; 6.15% | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 1–2, 17 |

## Gaps

Eight gaps limit this view; four are material and none is critical.

| Gap | Severity | What is missing and what it limits | Remediation | Source |
|---|---|---|---|---|
| Operating economics after commissioning | MATERIAL | No throughput, grade, recovery, operating cost or sustaining capital is supplied, so margin and free cash flow after commissioning and coverage of the coupon cannot be sized | Supply the mine plan, the updated technical report and cost guidance | Business & governance (CP-1A) |
| Construction budget and cost to complete | MATERIAL | Without a budget the months of funding rest on average spending pace, so whether the funds reach commercial production is not established | Supply the construction budget and the management discussion | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 4 |
| Release conditions and reserve balance | MATERIAL | The conditions for releasing the construction funds and the reserve balance at June 30, 2026 are not printed; restricted cash is shown only in total | Supply the indenture and the disbursement account terms | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 4, 12 |
| Gold Stream covenants after the buy-down | MATERIAL | A debt service coverage ratio of 1.25:1 and unrestricted cash of at least CAD 25,000 thousand were printed to March 31, 2026 and are not restated, so covenant headroom is not calculable | Supply the amended stream agreement | 6-K-EX-99.2_2026-05-15_ske-20260515xex99d2.htm.jsonl, pages 10–11; 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 14–15 |
| Cost of additional financing | MINOR | The Gold Stream is valued at a 15.77% credit spread against an 8.57% effective interest rate on the notes, with no price, yield or spread printed for the notes | Supply a dated price or yield for the notes | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, pages 8, 13 |
| Equity value proxy | MINOR | The share price is not supplied, so the equity value rests on the strike price of options granted on June 12, 2026 | Supply a dated share price | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 17 |
| Peer and sector benchmarks | MINOR | No peer set or sector data is supplied, so the comparison with producing gold issuers rests on structure | Supply peer data if a comparison is wanted | Source readiness (CP-0) |
| Position after June 30, 2026 | MINOR | The statements end on June 30, 2026, which is 128 days before the as-of date, so cash, release progress and spending since then are not established | Supply third-quarter 2026 statements if published by the as-of date | 6-K-EX-99.2_2026-08-13_ske-20260813xex99d2.htm.jsonl, page 1; Source readiness (CP-0) |

## Next module

The orchestrator selects the next module.
