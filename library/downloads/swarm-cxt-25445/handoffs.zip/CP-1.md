---
module_id: CP-1
module_name: FinancialFoundation
run_id: cxt-25445-2026-11-18-credit_snapshot-host
issuer_name: Crane NXT, Co.
issuer_id: cxt-25445
reporting_period: Q3 2026
analysis_date: 2026-11-18
---

## Request
Prepare a source-traced financial foundation for Crane NXT, Co. as of 2026-11-18 under the credit_snapshot pathway. The reporting perimeter is the issuer and its consolidated subsidiaries; use FY2025 and Q3 2026 as the prior and current periods, with reported comparatives where available.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 10-K_2024-12-31_cxt.htm.jsonl | Annual report on Form 10-K for the year ended December 31, 2024 | 2025-02-20 | a40c2da1e312c80059c7a702d6e8ead07a70bf3c60b776e12edea1a2fd778eac | FY2024 financial statements, lease and financing disclosures |
| 10-K_2025-12-31_cxt.htm.jsonl | Annual report on Form 10-K for the year ended December 31, 2025 | 2026-02-26 | 01187d5c69747fdd7576e6df20b86f97ae44d4962226c99fc0083d69999c404b | Audited FY2025/FY2024 statements, debt, facilities, ratings as of year-end, working capital and lease notes |
| 10-Q_2026-03-31_cxt.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended March 31, 2026 | 2026-05-06 | a8e9fbb164be7cd86f650fbb5d3eb4fc3dbc5a3297e893af12b5b216cc151d4a | Q1 2026 interim statements and financing/acquisition activity |
| 10-Q_2026-06-30_cxt.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended June 30, 2026 | 2026-08-05 | 26065b334699985449b07e01e37f38843cee7dcbabfea858a70e5cf21c9b3917 | Q2 2026 interim statements and Sixth Amendment reference |
| 10-Q_2026-09-30_cxt.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended September 30, 2026 | 2026-11-04 | 55422b5e495513ada133cd913a2e17251021745f2ce0eee3fa1e4e8436a4d411 | Q3 and nine-month statements, debt, liquidity, pension and subsequent events |
| EX99.1_2026-03-31_cxt_exhibit991-pressreleasexq1-htm.htm.jsonl | First-quarter 2026 earnings release | 2026-05-06 | 08a8feef76d82c6540a59447f57579038d57c84af3731630fd0b026945ea3dd1 | Q1 non-GAAP measures and segment results |
| EX99.1_2026-06-30_cxt_exhibit991-pressreleasexq2-htm.htm.jsonl | Second-quarter 2026 earnings release | 2026-08-05 | c8c9342ab29cb1624423def3fb7ee109bbbda3e7d7723b40a5611b23c2b55aab | Q2 non-GAAP measures, segment results and guidance |
| EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl | Third-quarter 2026 earnings release | 2026-11-04 | 67f82d3885906de865063f3f40fbf1da0d9b57013fb7f261abf4484b67df59a9 | Q3 and nine-month reconciliations, issuer net leverage and updated guidance |

### Supplied handoffs

| Module | sha256 | Use |
|---|---|---|
| Source readiness (CP-0) | 0f3e5e7f12d07ffbdbeddd8fae567facffd7996b6f24c425e64e6429fee44f2c | Source inventory, perimeter and stated limitations |

## Findings

### Bottom line
Crane NXT’s reported cash flow supports ongoing debt service, but acquisition funding pushed carrying-value net debt higher and leaves reported LTM leverage at 3.03x. Creditors should distinguish issuer-adjusted leverage from carrying-value leverage and treat the current maturity ladder as incomplete.
Basis: calculation C5; calculation C6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–9

The cash flow statement records USD 184.5 million of operating cash flow and USD 139.5 million of free cash flow for 9M 2026, while acquisition and financing activity left carrying-value net debt at USD 1,131.4 million at September 30, 2026. Management reports 2.5x net leverage using net debt before deferred financing costs and TTM Adjusted EBITDA; the comparable ratio using balance-sheet carrying debt and reported LTM EBITDA is 3.03x. Missing instrument-level principal schedules limit exact maturity-wall and secured-debt calculations.
Basis: calculation C4; calculation C5; calculation C6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–9

### Key credit drivers

Leverage rose between FY2025 and September 2026 because carrying debt increased faster than cash and reported LTM EBITDA. The primary cause disclosed is acquisition financing: 9M 2026 included USD 225.4 million of acquisition cash outflow, USD 424.5 million of Term Loan B proceeds and USD 277.3 million of Term Loan A repayments. A stronger counterpoint is that 9M 2026 operating cash flow exceeded the prior-year period and free cash flow was positive; it would carry more weight if the acquired businesses sustain cash generation and management directs it to debt reduction rather than further acquisitions or distributions.
Basis: calculation C5; calculation C7; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4, 20–21; 10-K_2025-12-31_cxt.htm.jsonl, page 83

Reported interest coverage remains positive, but FFO-to-debt is not calculable because the issuer does not report FFO or enough components to define it consistently. The adjusted measures exclude special items and include Antares Vision for periods before acquisition; they are useful as management’s supplemental view, not a substitute for GAAP cash flow or carrying-value debt.
Basis: calculation C6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–10

### T4.1 Source register

| Source File Name | Document Type | Period Coverage | Currency | Unit | Perimeter | Accounting Basis | Evidence Quality Tier | Analytical Use | Limitations |
|---|---|---|---|---|---|---|---|---|---|
| 10-K_2024-12-31_cxt.htm.jsonl | Annual report, audited | FY2024 and FY2023 | USD | millions | Crane NXT, Co. and subsidiaries | U.S. GAAP; pre-Separation periods may be combined carve-out | Tier 1 | Historical financial statements, debt, lease, liquidity and segment data | FY2023 predates the Separation and is not used in current ratios |
| 10-K_2025-12-31_cxt.htm.jsonl | Annual report, audited | FY2025, FY2024 and FY2023 | USD | millions | Crane NXT, Co. and subsidiaries | U.S. GAAP | Tier 1 | Audited statements, financing, commitments, lease, working-capital and segment notes | No annual issuer-adjusted EBITDA for FY2025 is supplied in the sources read |
| 10-Q_2026-03-31_cxt.htm.jsonl | Quarterly report, unaudited | Q1 2026 and Q1 2025; balance sheet at March 31, 2026 | USD | millions | Crane NXT, Co. and subsidiaries | U.S. GAAP | Tier 2b | Q1 statement comparatives and acquisition funding | Interim statements; no full current agreement text |
| 10-Q_2026-06-30_cxt.htm.jsonl | Quarterly report, unaudited | Q2 and H1 2026; comparative Q2 and H1 2025 | USD | millions | Crane NXT, Co. and subsidiaries | U.S. GAAP | Tier 2b | H1 statements, debt and amendment reference | Interim statements; no full current agreement text |
| 10-Q_2026-09-30_cxt.htm.jsonl | Quarterly report, unaudited | Q3 and 9M 2026; comparative Q3 and 9M 2025 | USD | millions | Crane NXT, Co. and subsidiaries | U.S. GAAP | Tier 2b | Current statements, debt and subsequent-event review | Interim statements; instrument-level current principal schedule is absent |
| EX99.1_2026-03-31_cxt_exhibit991-pressreleasexq1-htm.htm.jsonl | Earnings release | Q1 2026 and Q1 2025 | USD | millions | Crane NXT, Co. and segments | GAAP and issuer-defined non-GAAP | Tier 2c | Adjusted results and segment context | Management measures are supplemental and unaudited |
| EX99.1_2026-06-30_cxt_exhibit991-pressreleasexq2-htm.htm.jsonl | Earnings release | Q2 and H1 2026; comparative periods 2025 | USD | millions | Crane NXT, Co. and segments | GAAP and issuer-defined non-GAAP | Tier 2c | Adjusted results, segment context and guidance | Management measures are supplemental and unaudited |
| EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl | Earnings release | Q3 and 9M 2026; comparative periods 2025 | USD | millions | Crane NXT, Co. and segments | GAAP and issuer-defined non-GAAP | Tier 2c | Adjusted EBITDA, free cash flow, reported net leverage and guidance | TTM adjusted measure includes Antares Vision for periods before acquisition |

### T4.2 Entity period key

| Entity Name | Entity Role | Fiscal Year End | Reporting Currency | Reporting Unit | Consolidation Perimeter | Accounting Basis | Available Periods |
|---|---|---|---|---|---|---|---|
| Crane NXT, Co. and subsidiaries | Issuer and consolidated reporting entity | December 31 | USD | millions | Consolidated issuer and controlled subsidiaries | U.S. GAAP; FY2024/FY2025 audited, 2026 interim unaudited | FY2024; FY2025; Q1 2026; H1 2026; Q3 2026; 9M 2026, with 2025 comparatives |
| Crane NXT, Co. | Credit Agreement borrower | December 31 | USD; some facilities denominated in EUR or GBP | USD millions for consolidated statements | Separate borrower-only financial statements not supplied | U.S. GAAP consolidated statements only | Borrower-only periods not supplied |
| Credit Agreement loan parties | Guarantor / collateral group | Not supplied | Not supplied | Not supplied | Current restricted-group and guarantor perimeter not established from the supplied filings | Not supplied | Not supplied |

### T4.3 Normalization register

| Adjustment Description | Source File | Adjustment Type | Before Value | After Value | Rationale | Affected Periods |
|---|---|---|---|---|---|---|
| Present consolidated statement amounts in USD millions; no FX translation performed | 10-K_2025-12-31_cxt.htm.jsonl; 10-Q_2026-09-30_cxt.htm.jsonl | Unit/perimeter convention | As reported in USD millions | USD millions | Filing statements are already in USD millions and consolidated Crane NXT perimeter; instrument principal disclosed in EUR or GBP is kept in its stated currency | All periods below |

### T4.4 Income statement

| Line item | FY2024 | FY2025 | 9M 2025 | 9M 2026 | Q3 2025 | Q3 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---:|---:|---|---|---|
| Net sales | 1486.8 | 1656.7 | 1179.8 | 1378.0 | 445.1 | 497.1 | USD millions | Reported GAAP revenue | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Cost of sales | 821.7 | 952.9 | 678.2 | 815.6 | 252.5 | 299.2 | USD millions | Reported GAAP expense | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Selling, general and administrative | 386.2 | 440.3 | 323.7 | 393.0 | 107.2 | 126.1 | USD millions | Reported GAAP expense | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Restructuring charges | 10.1 | 16.8 | 10.8 | 12.6 | 3.5 | 6.1 | USD millions | Reported GAAP expense | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Operating profit | 268.8 | 246.7 | 167.1 | 156.8 | 81.9 | 65.7 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Interest income | 1.6 | 1.0 | Not supplied: no separate line in interim statements | Not supplied: no separate line in interim statements | Not supplied: no separate line in interim statements | Not supplied: no separate line in interim statements | USD millions | Annual GAAP line; interim statements combine or omit it | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Interest expense | -47.8 | -60.3 | -44.1 | -58.7 | -16.2 | -19.9 | USD millions | Reported P&L expense; distinct from cash interest paid | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Related-party interest expense | — | — | Not supplied: no separate interim line | Not supplied: no separate interim line | Not supplied: no separate interim line | Not supplied: no separate interim line | USD millions | The annual filing prints a dash for FY2024/FY2025; interim statements do not present a separate line | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Equity investment income (loss) | 0.8 | -11.5 | 0.5 | 4.9 | 0.1 | 0.1 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Miscellaneous income, net | 3.0 | 5.1 | 4.0 | 3.3 | 0.8 | 3.3 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Total other expense, net | -42.4 | -65.7 | -39.6 | -50.5 | -15.3 | -16.5 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Income before income taxes | 226.4 | 181.0 | 127.5 | 106.3 | 66.6 | 49.2 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Provision for income taxes | 42.3 | 35.9 | 29.9 | 24.2 | 15.7 | 10.1 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Net income before allocation to noncontrolling interest | 184.1 | 145.1 | 97.6 | 82.1 | 50.9 | 39.1 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Noncontrolling interest in subsidiaries’ earnings | — | — | 0.5 | 1.9 | 0.4 | 0.7 | USD millions | Annual filing prints a dash; interim amount reported | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Net income attributable to common shareholders | 184.1 | 145.1 | 97.1 | 80.2 | 50.5 | 38.4 | USD millions | Reported GAAP | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| Depreciation and amortization | 86.8 | 106.6 | 77.7 | 108.1 | 29.0 | 39.6 | USD millions | Reported in cash flow statement; Q3 is 9M less H1 | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4; 10-Q_2026-06-30_cxt.htm.jsonl, page 4 |
| EBITDA (Reported) | 355.6 | 353.3 | 244.8 | 264.9 | 110.9 | 105.3 | USD millions | Calculated as GAAP operating profit plus D&A; see C1 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; 10-Q_2026-06-30_cxt.htm.jsonl, page 4 |
| EBITDA (Adjusted) | Not supplied: annual issuer-adjusted EBITDA not in the sources read | Not supplied: annual issuer-adjusted EBITDA not in the sources read | 281.4 | 317.4 | 122.4 | 127.2 | USD millions | Issuer-adjusted EBITDA as reported in release reconciliations | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–8 |

### T4.5 Cash flow statement

| Line item | FY2024 | FY2025 | 9M 2025 | 9M 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---|---|---|
| Net income before allocation to noncontrolling interest | 184.1 | 145.1 | 97.6 | 82.1 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–4 |
| Loss (income) from equity investments | -0.8 | 11.5 | -0.5 | -4.9 | USD millions | Reported; annual and interim labels retained | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Depreciation and amortization | 86.8 | 106.6 | 77.7 | 108.1 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Stock-based compensation expense | 10.6 | 12.7 | 9.3 | 23.1 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| (Gain) loss on forward contracts | 3.0 | -4.7 | Not supplied: not a separate YTD operating cash-flow line | Not supplied: not a separate YTD operating cash-flow line | USD millions | Reported when presented | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Defined benefit plans and postretirement credit | -2.1 | -0.8 | Not supplied: not a separate YTD operating cash-flow line | Not supplied: not a separate YTD operating cash-flow line | USD millions | Reported when presented | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Deferred income taxes | -17.6 | -14.8 | -11.7 | -11.8 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Cash used for operating working capital | -50.6 | -17.0 | -41.9 | -16.4 | USD millions | Reported signed cash effect | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Operating cash flow before working capital | 264.7 | 258.5 | 177.6 | 200.9 | USD millions | Calculated as reported OCF less signed working-capital cash effect | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Long-term contract liabilities | Not supplied: no separate FY line | Not supplied: no separate FY line | 4.3 | 8.7 | USD millions | Reported | 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Other operating adjustments | 0.7 | 2.9 | 0.9 | -4.4 | USD millions | Reported; annual cash-flow statement label “Other” | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Net Cash from Operating Activities | 214.1 | 241.5 | 135.7 | 184.5 | USD millions | Reported; YTD values are 9M | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Payment for acquisitions, net of cash acquired | -269.9 | -391.1 | -391.1 | -225.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Purchase of investments | — | -116.5 | Not supplied: no separate YTD line | Not supplied: no separate YTD line | USD millions | Annual source prints purchase in FY2025 only | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Proceeds from equity investments | Not supplied: no separate FY line | Not supplied: no separate FY line | — | 4.5 | USD millions | Reported interim item | 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Capital expenditures | -45.4 | -43.2 | -33.4 | -45.0 | USD millions | Reported cash outflow | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Maintenance capital expenditures | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | USD millions | Issuer does not classify capex as maintenance versus growth in the supplied filings | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Growth capital expenditures | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | Not supplied: no maintenance/growth split | USD millions | Issuer does not classify capex as maintenance versus growth in the supplied filings | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Issuer-defined free cash flow (operating cash flow less total capex) | 168.7 | 198.3 | 102.3 | 139.5 | USD millions | Calculated as OCF less total capex; includes working capital and cash interest paid within operating activities; issuer release reports these FCF totals | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–8 |
| Unlevered free cash flow | Not calculable: no unlevered cash-flow bridge or consistent tax/interest allocation | Not calculable: no unlevered cash-flow bridge or consistent tax/interest allocation | Not calculable: no unlevered cash-flow bridge or consistent tax/interest allocation | Not calculable: no unlevered cash-flow bridge or consistent tax/interest allocation | USD millions | Not calculable from the supplied statement presentation | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Settlement of forward contracts, investing | -2.7 | 1.7 | 1.8 | -0.5 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Proceeds from disposition of assets | — | 0.1 | — | 8.4 | USD millions | Source dashes retained as — | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Net Cash from Investing Activities | -318.0 | -549.0 | -422.7 | -258.0 | USD millions | Reported signed cash effect | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Dividends paid | -36.6 | -39.0 | -29.2 | -31.1 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Proceeds from share subscriptions | — | 21.4 | Not supplied: no separate YTD line | Not supplied: no separate YTD line | USD millions | FY2024 statement prints no amount; FY2025 reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54 |
| Share repurchases | Not supplied: no separate cash-flow line | Not supplied: no separate cash-flow line | Not supplied: no separate cash-flow line | Not supplied: no separate cash-flow line | USD millions | No separate share repurchase amount is presented in the cash-flow statements read | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Proceeds from stock options exercised | 3.3 | 2.6 | 2.2 | 0.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Payment of tax withholding on equity awards vested | -6.9 | -6.2 | -5.9 | -3.1 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Debt issuance costs | -2.7 | -22.3 | -4.3 | -3.5 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Proceeds from revolving credit facility | 448.5 | 406.5 | 384.5 | 316.3 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Repayment of revolving credit facility | -238.5 | -490.5 | -413.5 | -209.0 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Proceeds from term loans | — | 532.0 | 400.4 | 424.5 | USD millions | Reported; FY2024 source prints a dash | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Repayment of term loan | -105.0 | -40.9 | -40.9 | -277.3 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Repayment of finance leases | Not supplied: no separate FY line | Not supplied: no separate FY line | — | -1.9 | USD millions | Reported Q3 YTD line | 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Purchase of noncontrolling interest | Not supplied: no separate FY line | Not supplied: no separate FY line | — | -0.2 | USD millions | Reported interim item | 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Net Cash from Financing Activities | 62.1 | 363.6 | 293.3 | 92.3 | USD millions | Reported signed cash effect | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| FX Effect on Cash | -12.0 | 16.7 | 15.1 | -3.8 | USD millions | Reported; source label includes cash equivalents and restricted cash | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Net Cash Change | -53.8 | 72.8 | 21.4 | 15.0 | USD millions | Reported; operating plus investing plus financing plus FX | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Opening Cash | 227.2 | 173.4 | 173.4 | 246.2 | USD millions | Reported; includes cash equivalents and restricted cash | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Closing Cash | 173.4 | 246.2 | 194.8 | 261.2 | USD millions | Reported; includes cash equivalents and restricted cash | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| Cash Interest Paid | 44.1 | 55.6 | 40.6 | 51.4 | USD millions | Reported cash interest, not P&L interest expense | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 5 |
| Cash taxes paid, net | 63.8 | 50.9 | 48.1 | 51.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |

### T4.6 Balance sheet

| Line item | FY2024 | FY2025 | Q3 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---|---|---|
| Cash & Equivalents | 165.8 | 233.8 | 251.1 | USD millions | Reported cash and cash equivalents; excludes restricted cash | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Restricted cash | 7.6 | 12.5 | 10.1 | USD millions | Calculated from disclosed current and noncurrent restricted cash; FY2025 components sum to 12.5 while reported cash-flow reconciliation differs by 0.1 due to rounding | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 4 |
| Short-term investments | Not supplied: no separate balance-sheet line | Not supplied: no separate balance-sheet line | Not supplied: no separate balance-sheet line | USD millions | No separate amount in the balance sheets read | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Trade receivables | 265.9 | 351.8 | 374.5 | USD millions | Reported net accounts receivable | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| U.S. and foreign taxes on income, current | 8.6 | 12.7 | 23.7 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Inventories | 144.8 | 169.5 | 216.8 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Other current assets | 57.4 | 85.1 | 105.6 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total current assets | 642.5 | 852.9 | 971.7 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Property, plant and equipment, net | 272.3 | 303.8 | 327.9 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Long-term deferred tax assets | 2.2 | 2.5 | 18.3 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Investment in equity affiliates and joint ventures | 1.3 | 139.4 | 4.6 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Intangible assets, net | 419.3 | 557.2 | 724.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Goodwill | 956.6 | 1164.0 | 1420.0 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Other assets | 92.3 | 96.6 | 94.7 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total Assets | 2386.5 | 3116.4 | 3561.6 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Short-term borrowings | 210.0 | 135.1 | 231.1 | USD millions | Reported; includes facility borrowings and other debt | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Current portion of long-term debt | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | USD millions | Current borrowing is presented in aggregate, not split between revolving and term debt | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Accounts payable | 116.6 | 132.3 | 114.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Contract liabilities | 71.4 | 87.3 | 158.4 | USD millions | Customer advance payments; current balance | 10-K_2025-12-31_cxt.htm.jsonl, page 103; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Accrued liabilities | 211.2 | 273.0 | 218.9 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| U.S. and foreign taxes on income, current liability | 24.6 | 28.7 | 20.9 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total current liabilities | 562.4 | 569.1 | 743.7 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Long-term debt | 540.6 | 1004.4 | 1151.4 | USD millions | Carrying value reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Accrued pension and postretirement benefits | 19.4 | 19.1 | 27.8 | USD millions | Reported separately from financial debt | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Long-term deferred tax liability | 119.0 | 151.0 | 200.8 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Other liabilities | 80.2 | 116.0 | 124.6 | USD millions | Includes lease and other liabilities; Q3 lease amount is not split | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total Liabilities | 1321.6 | 1859.6 | 2248.3 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Temporary Equity | Not supplied: source prints a dash | 6.9 | 20.6 | USD millions | Reported as redeemable noncontrolling interests | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total shareholders’ equity | 1064.9 | 1253.0 | 1292.3 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Nonredeemable noncontrolling interests | — | -3.1 | 0.4 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total Equity | 1064.9 | 1249.9 | 1292.7 | USD millions | Reported | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| Total Debt | 750.6 | 1139.5 | 1382.5 | USD millions | Carrying value: short-term borrowings plus long-term debt | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |

### T4.18 Debt instruments

| Instrument | Type | Carrying Value | Principal | Drawn | Commitment | Security | Ranking | Currency | Reporting Currency Amount | FX Rate | Coupon or Margin | Rate Type | Reference Rate | Spread (bps) | Floor (bps) | Maturity | Annual Amortisation | Source |
|---|---|---:|---:|---:|---:|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| Term Loan A | Senior secured term loan | 81.2 | Not supplied: current face amount in GBP not stated | 81.2 carrying value, principal not supplied | GBP 300.0m original facility | Yes, Credit Agreement | Not supplied: exact legal relative rank not stated | GBP | 81.2 USD millions carrying value as reported | Not applicable; amount reported in USD statements | SONIA + 1.50%–2.25% or base rate + 0.50%–1.25%; current margin not stated | Floating | SONIA or base rate | 50–225 | Not supplied | 2030-12-15 | Not supplied | 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, page 106 |
| Revolving Facility | Senior secured multicurrency revolver | 229.9 | Not supplied: exact current principal by currency not stated | 229.9 carrying value | USD 800.0m | Yes, Credit Agreement | Not supplied: exact legal relative rank not stated | Not supplied: current drawn mix by currency not stated | 229.9 USD millions carrying value as reported | Not applicable; amount reported in USD statements | SOFR/EURIBOR/SONIA + 1.50%–2.25% or base rate + 0.50%–1.25%; current margin not stated | Floating | SOFR, EURIBOR, SONIA or base rate, depending on elected currency | 50–225 | Not supplied | 2030-12-15 | Not supplied: scheduled annual amortisation not stated | 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, page 106 |
| Term Loan B | Senior secured delayed-draw term loan | 531.4 | Not supplied: current face amount not stated; facility size is not principal | 531.4 carrying value | EUR 480.0m | Yes, Credit Agreement | Not supplied: exact legal relative rank not stated | EUR | 531.4 USD millions carrying value as reported | Not applicable; amount reported in USD statements | Adjusted EURIBOR + 2.00%–2.25% | Floating | Adjusted EURIBOR | 200–225 | Not supplied | 2032-12-15 | Not supplied | 10-Q_2026-09-30_cxt.htm.jsonl, page 21 |
| 6.55% notes due November 2036 | Senior notes | 198.9 | 200.0 | 200.0 | Not applicable | Secured, as stated in 2024 filing | Not supplied: exact legal relative rank not stated | USD | 198.9 USD millions carrying value | Not applicable | 6.55% | Fixed | Not applicable | Not applicable | Not applicable | 2036-11-15 | 0; no sinking fund requirement | 10-Q_2026-09-30_cxt.htm.jsonl, page 20; 10-K_2024-12-31_cxt.htm.jsonl, page 98 |
| 4.20% senior notes due March 2048 | Senior notes | 347.0 | 350.0 | 350.0 | Not applicable | Not supplied: the cited filing does not state security | Senior; relative lien rank not stated | USD | 347.0 USD millions carrying value | Not applicable | 4.20% | Fixed | Not applicable | Not applicable | Not applicable | 2048-03-15 | 0; no sinking fund requirement stated | 10-Q_2026-09-30_cxt.htm.jsonl, page 20; 10-K_2025-12-31_cxt.htm.jsonl, page 108 |
| Other debt, including finance lease liabilities | Other debt / finance leases | 5.5 | Not supplied: components and principal not stated | Not supplied | Not supplied | Not supplied | Not supplied | Not supplied | 5.5 USD millions carrying value | Not applicable; reported USD statement amount | Not supplied | Not supplied | Not supplied | Not supplied | Not supplied | Not supplied | Not supplied | 10-Q_2026-09-30_cxt.htm.jsonl, page 20 |
| Other deferred financing costs | Contra-debt line in financing note | -11.4 | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | USD | -11.4 USD millions | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | 10-Q_2026-09-30_cxt.htm.jsonl, page 20 |

### T4.8 Constructed period register

| Metric Name | Derived Period Type | Full-Year Component | Current Stub | Prior-Year Stub | Derived Value | Calculation Status | Source Files | Limitations |
|---|---|---:|---:|---:|---:|---|---|---|
| Revenue | LTM to 2026-09-30 | USD 1,656.7m FY2025 | USD 1,378.0m 9M 2026 | USD 1,179.8m 9M 2025 | USD 1,854.9m | Calculated | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 | FY2025 + 9M2026 − 9M2025 |
| EBITDA (Reported) | LTM to 2026-09-30 | USD 353.3m FY2025 | USD 264.9m 9M 2026 | USD 244.8m 9M 2025 | USD 373.4m | Calculated | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4 | Reported EBITDA is operating profit plus D&A; see C1 and C2 |
| EBITDA (Adjusted) | Issuer-reported TTM | Not applicable: issuer directly reports a TTM amount | Not applicable: component not supplied | Not applicable: component not supplied | USD 460.3m | Reported | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9 | Includes Antares Vision for periods before the acquisition; not comparable with reported EBITDA |
| Cash interest paid | LTM to 2026-09-30 | USD 55.6m FY2025 | USD 51.4m 9M 2026 | USD 40.6m 9M 2025 | USD 66.4m | Calculated | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 5 | FY2025 + 9M2026 − 9M2025 |

### T4.9 Calculation register

| Metric Name | Formula | Numerator Value | Numerator Source | Denominator Value | Denominator Source | Period | Currency | Unit | Calculated Value | Calculation Status | Evidence Quality Tier | Limitations |
|---|---|---:|---|---:|---|---|---|---|---:|---|---|---|
| Total debt / EBITDA | Carrying debt ÷ reported EBITDA | 1139.5 | 10-K_2025-12-31_cxt.htm.jsonl, page 53 | 353.3 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; calculation C1 | FY2025 / 2025-12-31 | USD | US$m | 3.23 | Calculated | Tier 1 | FY2025 reported EBITDA |
| Net debt / EBITDA | Net debt ÷ reported EBITDA | 905.7 | 10-K_2025-12-31_cxt.htm.jsonl, page 53; calculation C5 | 353.3 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; calculation C1 | FY2025 / 2025-12-31 | USD | US$m | 2.56 | Calculated | Tier 1 | FY2025 cash and EBITDA |
| EBITDA / cash interest | Reported EBITDA ÷ cash interest paid | 353.3 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; calculation C1 | 55.6 | 10-K_2025-12-31_cxt.htm.jsonl, page 54 | FY2025 / 2025-12-31 | USD | US$m | 6.35 | Calculated | Tier 1 | Full-year cash paid denominator |
| Total debt / EBITDA | Carrying debt ÷ reported LTM EBITDA | 1382.5 | 10-Q_2026-09-30_cxt.htm.jsonl, page 3 | 373.4 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; calculation C2 | 2026-09-30 | USD | US$m | 3.70 | Calculated | Tier 1 / Tier 2b | LTM construction; reported EBITDA |
| Net debt / EBITDA | Net debt ÷ reported LTM EBITDA | 1131.4 | 10-Q_2026-09-30_cxt.htm.jsonl, page 3; calculation C5 | 373.4 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; calculation C2 | 2026-09-30 | USD | US$m | 3.03 | Calculated | Tier 1 / Tier 2b | LTM construction; carrying debt basis |
| EBITDA / cash interest | Reported LTM EBITDA ÷ LTM cash interest | 373.4 | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; calculation C2 | 66.4 | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 5; calculation C4 | 2026-09-30 | USD | US$m | 5.62 | Calculated | Tier 1 / Tier 2b | Cash-interest denominator |
| Total debt / adjusted EBITDA | Carrying debt ÷ issuer-adjusted LTM EBITDA | 1382.5 | 10-Q_2026-09-30_cxt.htm.jsonl, page 3 | 460.3 | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9 | 2026-09-30 | USD | US$m | 3.00 | Calculated | Tier 2c | Issuer-adjusted denominator; not the canonical reported EBITDA ratio |
| Net debt / adjusted EBITDA | Carrying-value net debt ÷ issuer-adjusted LTM EBITDA | 1131.4 | 10-Q_2026-09-30_cxt.htm.jsonl, page 3; calculation C5 | 460.3 | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9 | 2026-09-30 | USD | US$m | 2.46 | Calculated | Tier 2c | Different debt basis from issuer's 2.5x leverage |
| Adjusted EBITDA / cash interest | Issuer-adjusted LTM EBITDA ÷ LTM cash interest | 460.3 | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9 | 66.4 | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 5; calculation C4 | 2026-09-30 | USD | US$m | 6.93 | Calculated | Tier 2c / Tier 2b | Adjusted measure and cash-paid denominator |
| FFO / debt | FFO ÷ carrying debt | Not supplied: FFO is not defined or reported | Not supplied | 1382.5 | 10-Q_2026-09-30_cxt.htm.jsonl, page 3 | 2026-09-30 | USD | US$m | Not calculable: FFO is not supplied | Not Calculable | Tier 2b | FFO definition and numerator are absent |

### T4.10 KPI dashboard

| KPI Category | Metric Name | Q3 2025 | Q3 2026 | 2025-09-30 | 2026-09-30 | Trend Direction | Analyst Note |
|---|---|---:|---:|---:|---:|---|---|
| Margin | Adjusted EBITDA margin | 27.5% | 25.6% | Not supplied: annualized comparison not reported | Not supplied: annualized comparison not reported | Lower in the reported quarter | Issuer-adjusted measure; current-quarter margin is not a GAAP margin |
| Backlog | Order backlog, USD millions | Not applicable | Not applicable | 557.0 | 715.5 | Higher | September 2026 backlog includes approximately USD 125 million associated with Antares Vision |
| Organic growth | Total organic sales growth | Not supplied: not in the Q3 comparative table | 1.1% | Not applicable | Not applicable | Not comparable | Acquisition contribution is separate from organic sales |
| Segment growth | SAT organic sales growth | Not supplied: not in the Q3 comparative table | 7.2% | Not applicable | Not applicable | Not comparable | Q3 2026 issuer-reported organic growth |
| Segment growth | DTT organic sales growth | Not supplied: not in the Q3 comparative table | -5.3% | Not applicable | Not applicable | Not comparable | Q3 2026 issuer-reported organic decline; acquisition contribution is separate |

### T4.11 Definition conflict register

| Metric Name | Canonical Definition | Issuer-Reported Definition | Source of Conflict | Periods Affected | Materiality | Modules Affected | Resolution / Recommendation |
|---|---|---|---|---|---|---|---|
| Debt and leverage | Total debt is balance-sheet carrying value; net debt is carrying debt less cash and equivalents | Issuer leverage uses debt excluding USD 30.1m deferred financing costs, less USD 251.1m cash, divided by USD 460.3m TTM Adjusted EBITDA; published ratio is 2.5x | 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9 | 2026-09-30 | Material: reported ratio is not the carrying-value/reporting-EBITDA ratio | Leverage, debt and coverage | Use USD 1,382.5m carrying debt and USD 1,131.4m carrying-value net debt for canonical ratios; retain the issuer’s 2.5x as an adjusted gross-principal / adjusted-EBITDA measure |
| EBITDA | Reported EBITDA is GAAP operating profit plus depreciation and amortization | Issuer Adjusted EBITDA adds acquired intangible amortization, restructuring, transaction and acquisition items and uses management's defined adjusted measure | 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–10 | Q3 2026, 9M 2026 and LTM to 2026-09-30 | Material: changes ratio denominator | Earnings, leverage and coverage | Keep reported and adjusted values in separately labelled rows; do not infer annual adjusted EBITDA |
| Cash | Net debt uses cash and cash equivalents; cash-flow ending cash includes restricted cash | At 2026-09-30, balance-sheet cash is USD 251.1m while cash, equivalents and restricted cash in cash flow is USD 261.2m | 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5 | 2026-09-30 | Medium: USD 10.1m is not available cash for net debt | Net debt and liquidity | Use USD 251.1m in net debt and label cash-flow close as including restricted cash |

### T4.13 Readiness

| Requested Use | Readiness Status | Gaps or Limitations | Recommended Actions |
|---|---|---|---|
| Historical financial statements, LTM construction, carrying debt/net debt, reported leverage and cash flow for the credit snapshot | Ready with Limitations | Full instrument-level current principal schedule, exact principal by currency, RCF LC utilization, FFO definition, current guarantor perimeter and current long-term lease balance are not established; issuer-adjusted EBITDA is not comparable with reported EBITDA | Retain carrying-value calculations and source periods as labelled; obtain current credit agreement and amendments, debt maturity schedule, current LC schedule, and lease/guarantor disclosures before covenant capacity or a full refinancing analysis |

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2025 / 2025-12-31 | 3.23 | 2.56 | x | USD 1,139.5m and USD 905.7m carrying debt/net debt divided by USD 353.3m reported EBITDA; calculation C6 |
| 2026-09-30 | 3.70 | 3.03 | x | Carrying debt and net debt divided by LTM reported EBITDA of USD 373.4m; calculation C6; unaudited latest balance sheet |

Qualification: interim leverage uses LTM reported EBITDA, while FY2025 uses a full audited year.

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
|---|---:|---|---|
| FY2025 / 2025-12-31 | 6.35 | x | Reported EBITDA USD 353.3m divided by cash interest paid USD 55.6m; calculation C6 |
| 2026-09-30 | 5.62 | x | LTM reported EBITDA USD 373.4m divided by LTM cash interest USD 66.4m; calculation C6 |

Qualification: the denominator is cash interest paid, not P&L interest expense.

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2025 / 2025-12-31 | 233.8 | 674.0 | US$m | USD 800.0m revolving commitment less USD 126.0m drawn; no LC amount is stated against this committed facility at year-end |
| 2026-09-30 | 251.1 | 570.1 | US$m | USD 800.0m revolving commitment less USD 229.9m drawn; the current source set does not state RCF LC utilization, so this is before any unreported facility usage |

Qualification: undrawn capacity is before any current LC use not stated in the filings.

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Loan and other debt, maturity not allocated | 862.6 | US$m | Calculated as USD 1,412.6m total debt principal less USD 200.0m and USD 350.0m note principal; includes loan and other debt with stated facility maturities in 2030 and 2032, but the current principal schedule does not allocate amounts by year; calculation C8 |
| 2036 | 200.0 | US$m | Principal of 6.55% notes, due 2036-11-15; 10-K_2024-12-31_cxt.htm.jsonl, page 98 |
| 2048 | 350.0 | US$m | Principal of 4.20% notes, due 2048-03-15; 10-K_2025-12-31_cxt.htm.jsonl, page 108 |

Qualification: reported maturity dates are shown, but the source does not provide complete principal amounts for every loan and other-debt line.


### Financials and credit metrics

| Metric | FY2024 | FY2025 | 9M 2025 | 9M 2026 | Q3 2025 | Q3 2026 | LTM to 2026-09-30 | Basis |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| Revenue, USD millions | 1486.8 | 1656.7 | 1179.8 | 1378.0 | 445.1 | 497.1 | 1854.9 | Reported annual/interim revenue; LTM calculated, C3 |
| Reported EBITDA, USD millions | 355.6 | 353.3 | 244.8 | 264.9 | 110.9 | 105.3 | 373.4 | Operating profit plus D&A; LTM calculated, C1–C2 |
| Issuer Adjusted EBITDA, USD millions | Not supplied | Not supplied | 281.4 | 317.4 | 122.4 | 127.2 | 460.3 | Issuer-reported non-GAAP measures; LTM includes Antares Vision before acquisition |
| Operating cash flow, USD millions | 214.1 | 241.5 | 135.7 | 184.5 | 92.0 | 111.8 | Not applicable | Quarterly release for Q3; interim statement for YTD |
| Capital expenditures, USD millions | 45.4 | 43.2 | 33.4 | 45.0 | 13.3 | 21.6 | Not applicable | Reported cash outflow, shown positive as spending |
| Free cash flow, USD millions | 168.7 | 198.3 | 102.3 | 139.5 | 78.7 | 90.2 | Not applicable | Operating cash flow less capital expenditures; issuer release independently reports Q3/9M values |
| Cash and equivalents, USD millions | 165.8 | 233.8 | Not applicable | 251.1 | Not applicable | Not applicable | Not applicable | Balance-sheet dates only |
| Carrying debt, USD millions | 750.6 | 1139.5 | Not applicable | 1382.5 | Not applicable | Not applicable | Not applicable | Balance-sheet carrying value |
| Carrying-value net debt, USD millions | 584.8 | 905.7 | Not applicable | 1131.4 | Not applicable | Not applicable | Not applicable | Carrying debt less cash and equivalents; calculation C5 |
| Cash interest paid, USD millions | 44.1 | 55.6 | 40.6 | 51.4 | Not supplied | Not supplied | 66.4 | LTM calculated; quarterly paid interest not separately disclosed |
| Cash used for operating working capital, USD millions | -50.6 | -17.0 | -41.9 | -16.4 | Not applicable | Not applicable | Not applicable | Reported signed cash effect |

### Net debt data

| Period | Gross debt | Cash | Net debt | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| FY2025 / 2025-12-31 | 1139.5 | 233.8 | 905.7 | US$m | Carrying debt is short-term borrowings plus long-term debt; USD 1,170.2m principal less USD 30.7m debt costs/discounts reconciles to carrying value; separately presented lease liabilities are not added |
| 2026-09-30 | 1382.5 | 251.1 | 1131.4 | US$m | Carrying debt includes debt lines and finance-lease liabilities included in “Other”; disclosed principal before USD 30.1m financing costs is USD 1,412.6m; cash excludes USD 10.1m restricted cash |

### Debt principal to carrying value

| Period | Contractual principal | Reconciling items | Carrying value | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| 2026-09-30 | 1412.6 | -30.1 | 1382.5 | US$m | Gross principal is issuer-reported total debt excluding deferred financing costs; net financing costs/discounts reconcile to the balance-sheet carrying value. The principal by individual maturity remains incomplete; calculation C8. |

### Post-balance-sheet adjustments

| Event | Date | Amount | Pro forma net debt | Pro forma net leverage | Reporting unit | Basis and limitation |
|---|---|---:|---:|---:|---|---|
| None found in the sources read | — | — | — | — | US$m | Read the Q3 2026 Form 10-Q and November 4, 2026 earnings release through the 2026-11-18 cutoff; the declared fourth-quarter dividend is scheduled for December 9, 2026 and is unpaid as of cutoff |

### Chart data: revenue and EBITDA

| Period | Revenue | Adjusted EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| 9M 2025 | 1179.8 | 281.4 | US$m | Issuer Adjusted EBITDA; nine months ended September 30, unaudited |
| 9M 2026 | 1378.0 | 317.4 | US$m | Issuer Adjusted EBITDA; nine months ended September 30, unaudited; includes the issuer's disclosed adjustment set |

Qualification: both rows use the same nine-month duration; Adjusted EBITDA is issuer-defined.

### Chart data: debt stack

| Facility | Ranking | Secured | Amount | Cumulative leverage | Reporting unit | Basis and limitation |
|---|---:|---|---:|---:|---|---|
| Not supplied: no facility has a source-stated legal relative ranking | Not supplied: relative lien rank is not stated | Not supplied: secured-debt ranking cannot be determined | Not supplied: no amount can be assigned through a source-stated legal ranking | Not supplied: cumulative leverage by legal ranking is not calculable | US$m | The filings identify secured Credit Agreement facilities and a secured notes series but do not establish their legal relative rank; borrower and current guarantor scope is also not supplied |

Qualification: legal relative ranking is not stated, so the secured-debt stack and cumulative leverage by rank are not established.

6.55% notes are described as secured senior obligations, but their relative lien rank is not stated; the 4.20% note's security is not stated. They are excluded from the legal-rank stack pending governing indentures.

### Chart data: EBITDA bridge

| Step | Amount | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Net income attributable to common shareholders (reported) | 38.4 | US$m | Q3 2026 GAAP opening amount; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 8 |
| Income tax expense | 10.1 | US$m | Issuer-stated adjustment |
| Intangible asset amortization | 26.2 | US$m | Issuer-stated adjustment |
| Interest expense, net | 19.6 | US$m | Issuer-stated adjustment |
| Depreciation | 11.7 | US$m | Issuer-stated adjustment |
| Transaction related expenses | 5.1 | US$m | Issuer-stated adjustment |
| Acquisition related adjustments | 9.9 | US$m | Issuer-stated adjustment |
| Restructuring and related costs | 6.2 | US$m | Issuer-stated adjustment |
| Adjusted EBITDA (issuer-adjusted closing amount) | 127.2 | US$m | Sum of opening amount and stated adjustments; reconciles to release |

Qualification: the bridge is for Q3 2026 and follows the issuer’s non-GAAP reconciliation.

### Period table

| Period | Start | End |
|---|---|---|
| FY2024 | 2024-01-01 | 2024-12-31 |
| FY2025 | 2025-01-01 | 2025-12-31 |
| 9M 2025 | 2025-01-01 | 2025-09-30 |
| 9M 2026 | 2026-01-01 | 2026-09-30 |
| Q3 2025 | 2025-07-01 | 2025-09-30 |
| Q3 2026 | 2026-07-01 | 2026-09-30 |

### Post-period events and cash-flow quality

The company completed the Antares Vision acquisition on March 31, 2026 and funded it in part with the new Term Loan B. The acquisition added revenue and a new business to DTT, but its separate contribution to post-close reported cash flow and EBITDA is not isolated in these statements. At September 30, carrying debt was USD 1,382.5 million, while unrestricted cash was USD 251.1 million; restricted cash of USD 10.1 million remains outside net debt. The reported cash flow statement’s USD 261.2 million closing balance includes that restricted cash.
Basis: calculation C5; calculation C11; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5, 9, 20–21

Operating cash flow increased from USD 135.7 million in 9M 2025 to USD 184.5 million in 9M 2026 as the reported working-capital cash use narrowed from USD 41.9 million to USD 16.4 million. The same period included USD 45.0 million of capital spending and USD 225.4 million of acquisition payments, leaving USD 139.5 million of free cash flow before acquisition spending. Positive free cash flow supports debt service, but acquisition cash outflow and recurring dividends constrain the amount available for deleveraging.
Basis: calculation C7; 10-Q_2026-09-30_cxt.htm.jsonl, page 4

Contract liabilities are advance payments from customers and increased from USD 87.3 million at FY2025 to USD 158.4 million at September 2026. This liability funds operations before the related performance obligation is fulfilled; delivery, cancellation or other settlement requirements can reverse that float into working-capital cash use. The filings do not quantify refunds or customer-specific delivery timing, so the size and timing of any reversal are not established.
Basis: 10-K_2025-12-31_cxt.htm.jsonl, pages 91, 103; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 17

Reported LTM EBITDA divided by cash interest paid is 5.62x at September 2026 versus 6.35x for FY2025. This is a cash-paid coverage measure; P&L interest expense was USD 58.7 million for 9M 2026 and cannot be substituted for the USD 51.4 million of cash interest paid in that period. FFO is not reported, so FFO-to-debt and a separate FFO-interest trajectory are not calculable.
Basis: calculation C4; calculation C6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 5; 10-K_2025-12-31_cxt.htm.jsonl, page 54

The quarter-end release states that its USD 460.3 million TTM Adjusted EBITDA includes Antares Vision for periods before acquisition and that its USD 1,161.5 million net debt is calculated before deferred financing costs. Those definitions produce management’s 2.5x rounded ratio. Using the balance-sheet debt carrying value and the reported LTM EBITDA gives 3.03x; the two ratios differ in both numerator basis and EBITDA definition. Carrying value is retained for the credit metric; the issuer ratio is preserved as a supplemental management view.
Basis: calculation C5; calculation C6; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10; 10-Q_2026-09-30_cxt.htm.jsonl, page 20

The 6.55% notes are due in November 2036 and the 4.20% notes are due in March 2048. The Term Loan A and Revolving Facility are scheduled to mature December 15, 2030; Term Loan B is scheduled to mature December 15, 2032. The company reports a USD 800.0 million revolving commitment and USD 229.9 million outstanding at September 2026. It does not give current principal by loan maturity or a current letter-of-credit amount against the revolver, so the date ladder cannot quantify all principal due or net committed availability exactly. No facility expiry within twelve months is identified in the stated maturity terms.
Basis: calculation C8; 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, pages 105–109

The November 4 release revised FY2026 guidance to approximately 14% sales growth, adjusted EBITDA margin of approximately 24%, and adjusted EPS of USD 4.32 to USD 4.42. It also declared a fourth-quarter dividend payable December 9, 2026. The dividend was scheduled but not paid by the November 18 cutoff and therefore is not included in pro forma net debt. The updated guidance is management’s forward-looking view, not a realized financial result.
Basis: EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 2–3

### Events: Sources

| Event date | Date precision | Published | Event | Status | Source | Credit relevance |
|---|---|---|---|---|---|---|
| 2025-05-01 | day | 2026-02-26 | Crane NXT acquired De La Rue Authentication Solutions for final purchase price USD 391.1m net of cash and working-capital adjustments | Historical — acquired De La Rue Authentication Solutions | 10-K_2025-12-31_cxt.htm.jsonl, page 83 | Acquisition funded with Term Loan A; contributed to FY2025 debt and acquired operating results |
| 2025-12-15 | day | 2026-11-04 | Fifth Amendment established EUR 430m Term Loan B, extended Term Loan A and revolving maturities to 2030-12-15 and increased the RCF to USD 800m | Historical — Fifth Amendment | 10-Q_2026-09-30_cxt.htm.jsonl, page 21 | Added acquisition debt and moved facility maturities |
| 2026-03-31 | day | 2026-05-06 | Crane NXT completed the multi-phase acquisition of Antares Vision, resulting in 100% ownership | Historical — completed acquisition | EX99.1_2026-03-31_cxt_exhibit991-pressreleasexq1-htm.htm.jsonl, page 1 | The acquisition changed the DTT perimeter and was funded through Term Loan B |
| 2026-07-02 | day | 2026-11-04 | Sixth Amendment repriced and increased Term Loan B from EUR 430m to EUR 480m; incremental EUR 50m proceeds and cash were used primarily to repay Term Loan A | Historical — Sixth Amendment | 10-Q_2026-09-30_cxt.htm.jsonl, page 21 | Alters floating spread range and facility balance; exact current face amount by instrument remains limited |
| 2026-11-04 | day | 2026-11-04 | FY2026 sales outlook revised to approximately 14% growth and adjusted EPS guidance revised to USD 4.32–4.42 | Historical — updated guidance | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 2 | Guidance changes the near-term earnings and deleveraging outlook |
| 2026-11-04 | day | 2026-11-04 | Fourth-quarter dividend of USD 0.18 per share declared, payable December 9, 2026 to holders of record November 30, 2026 | Scheduled — payable December 9, 2026 | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 2 | Future cash distribution after the analysis cutoff; not included in September debt/cash figures |

### Confidence inputs

| Input | Value |
|---|---|
| Directly Sourced | 32 |
| Calculated | 18 |
| Assumption-Based | 0 |
| Analyst Inference | 6 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 2 |
| Insufficient Information | 8 |
| Fields present | 11 |
| Fields total | 12 |
| Source gate | partial |
| CRITICAL | 0 |
| MATERIAL | 3 |
| MINOR | 1 |

## Calculations

| ID | Calculation | Inputs and formula | Result | Unit | Source |
|---|---|---|---|---|---|
| C1 | Reported EBITDA by period | Operating profit + D&A: FY2024 268.8 + 86.8; FY2025 246.7 + 106.6; 9M 2025 167.1 + 77.7; 9M 2026 156.8 + 108.1; Q3 2025 81.9 + (77.7 − 48.7); Q3 2026 65.7 + (108.1 − 68.5) | 355.6; 353.3; 244.8; 264.9; 110.9; 105.3 | USD millions, in the listed period order | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; 10-Q_2026-06-30_cxt.htm.jsonl, page 4 |
| C2 | LTM reported EBITDA to 2026-09-30 | FY2025 353.3 + 9M 2026 264.9 − 9M 2025 244.8 | 373.4 | USD millions | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4 |
| C3 | LTM revenue to 2026-09-30 | FY2025 1,656.7 + 9M 2026 1,378.0 − 9M 2025 1,179.8 | 1,854.9 | USD millions | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| C4 | LTM cash interest paid to 2026-09-30 | FY2025 55.6 + 9M 2026 51.4 − 9M 2025 40.6 | 66.4 | USD millions | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, page 5 |
| C5 | Carrying-value net debt | Total debt less cash: FY2024 750.6 − 165.8; FY2025 1,139.5 − 233.8; 2026-09-30 1,382.5 − 251.1 | 584.8; 905.7; 1,131.4 | USD millions, in the listed period order | 10-K_2025-12-31_cxt.htm.jsonl, page 53; 10-Q_2026-09-30_cxt.htm.jsonl, page 3 |
| C6 | Carrying-debt leverage and cash-interest cover | FY2025: 1,139.5 ÷ 353.3 = 3.23x; 905.7 ÷ 353.3 = 2.56x; 353.3 ÷ 55.6 = 6.35x. 2026-09-30: 1,382.5 ÷ 373.4 = 3.70x; 1,131.4 ÷ 373.4 = 3.03x; 373.4 ÷ 66.4 = 5.62x. Adjusted latest: 1,382.5 ÷ 460.3 = 3.00x; 1,131.4 ÷ 460.3 = 2.46x; 460.3 ÷ 66.4 = 6.93x | FY2025 and 2026-09-30 ratios in formula order | times | 10-K_2025-12-31_cxt.htm.jsonl, pages 52–54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–10 |
| C7 | Operating cash flow before working capital and free cash flow | OCF before working capital: FY2024 214.1 − (−50.6); FY2025 241.5 − (−17.0); 9M 2025 135.7 − (−41.9); 9M 2026 184.5 − (−16.4). Free cash flow: FY2024 214.1 − 45.4; FY2025 241.5 − 43.2; 9M 2025 135.7 − 33.4; 9M 2026 184.5 − 45.0 | OCF before working capital 264.7; 258.5; 177.6; 200.9. FCF 168.7; 198.3; 102.3; 139.5 | USD millions, in the listed period order | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| C8 | Debt principal and carrying-value reconciliation; unallocated loan/other maturity principal | Total principal 1,412.6 − financing costs/discounts 30.1 = carrying value 1,382.5. Instrument carrying rows 81.2 + 229.9 + 531.4 + 198.9 + 347.0 + 5.5 − other deferred financing costs 11.4 = 1,382.5. Unallocated loan/other principal 1,412.6 − note principal 200.0 − 350.0 = 862.6 | Principal 1,412.6; reconciling items −30.1; carrying value 1,382.5; loan/other principal not allocated by year 862.6 | USD millions | 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 9; 10-K_2024-12-31_cxt.htm.jsonl, page 98; 10-K_2025-12-31_cxt.htm.jsonl, page 108 |
| C9 | Restricted cash | Current restricted cash 3.2 + noncurrent restricted cash 6.9 | 10.1 | USD millions at 2026-09-30 | 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–4 |
| C10 | Cash roll-forward | Opening cash including restricted cash + net cash change: FY2024 227.2 − 53.8; FY2025 173.4 + 72.8; 9M 2025 173.4 + 21.4; 9M 2026 246.2 + 15.0 | 173.4; 246.2; 194.8; 261.2 | USD millions closing cash including restricted cash, in the listed period order | 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5 |
| C11 | Issuer leverage cross-check | Principal before financing costs 1,412.6 − cash 251.1 = net debt 1,161.5; 1,161.5 ÷ TTM Adjusted EBITDA 460.3 = 2.52x, which rounds to 2.5x as reported | USD 1,161.5m net debt; 2.5x reported issuer ratio | USD millions and times | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10 |

## Gaps

High severity: current face principal by facility, currency and maturity year is not supplied for Term Loan A, the Revolving Facility, Term Loan B or other debt. This leaves the aggregate principal residual unallocated across known facility dates and prevents a complete principal wall or instrument-level carrying reconciliation; obtain the current balance and amortisation schedule.
Basis: calculation C8; 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, pages 105–109

Medium severity: current letters-of-credit usage against the USD 800.0 million revolving commitment is not stated. The USD 570.1 million drawn-capacity difference is before any unreported LC usage, so net committed availability is not established; obtain the current LC schedule.
Basis: 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, pages 105–109

High severity: the executed Credit Agreement, current amendments, collateral agreement and guarantor schedule are not included as stand-alone sources. Covenant definitions, lien ranking, guarantor scope, baskets and exact current pricing are not established, which prevents covenant headroom and recovery analysis; obtain the governing documents.
Basis: 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; Source readiness (CP-0)

Medium severity: FFO is neither defined nor reported, maintenance and growth capex are not split, and the filings give no unlevered cash-flow bridge. FFO/debt, FFO interest cover, maintenance-only coverage and unlevered free cash flow are not calculable; obtain an issuer cash-flow bridge with those definitions.
Basis: 10-K_2025-12-31_cxt.htm.jsonl, page 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5

Low severity: interim interest income is not a separate income-statement line, short-term investments are not separately presented, and current portion of long-term debt is not separated from short-term borrowings. This restricts net-interest analysis and current-debt classification; obtain a disaggregated balance sheet and income statement if available.
Basis: 10-K_2025-12-31_cxt.htm.jsonl, pages 52–53; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2–3

Medium severity: September 2026 long-term operating lease liabilities are not separately disclosed, while some finance-lease debt is included in “Other.” Total current-date lease obligations are not established; obtain the updated lease maturity table.
Basis: 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 17, 20

Medium severity: Antares Vision’s post-acquisition contribution to revenue, EBITDA and cash flow is not separately stated in the consolidated period. Its standalone debt-service contribution cannot be isolated; obtain acquisition pro forma or segment data.
Basis: EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–10

Low severity: restricted cash is included in cash-flow closing cash but excluded from cash and equivalents. The USD 10.1 million balance is not counted as available net-debt cash without release terms.
Basis: calculation C9; calculation C10; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5

Medium severity: FY2025 and FY2024 issuer-adjusted EBITDA are not supplied, so adjusted annual leverage and coverage cannot be compared with the reported annual measures.
Basis: 10-K_2025-12-31_cxt.htm.jsonl, pages 52–54; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 7–9

Medium severity: current agency ratings and market quotations are not confirmed in the supplied sources; the FY2025 rating table is not a current rating confirmation. Current spread or market-value analysis is unsupported by this financial foundation.
Basis: 10-K_2025-12-31_cxt.htm.jsonl, pages 105–109; Source readiness (CP-0)

Positive operating cash flow and free cash flow in 9M 2026 reduce near-term reliance on new borrowing if sustained. Acquisition-driven debt growth, unallocated principal maturities and uncertainty about net liquidity after LC usage limit the amount and timing of potential deleveraging. This is a financial foundation, not a covenant-capacity, market-value or portfolio-sizing conclusion.
Basis: calculation C5; calculation C7; calculation C8; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4, 20–21; Source readiness (CP-0)

## Next module
The orchestrator selects the next module.
