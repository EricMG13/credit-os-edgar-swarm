---
module_id: CP-2
module_name: FundamentalCreditSynthesizer
issuer_id: cxt-25445
issuer_name: Crane NXT, Co.
reporting_period: Q3 2026
analysis_date: 2026-11-18
pathway: credit_snapshot
run_id: cxt-25445-2026-11-18-credit_snapshot-host
committee_status: Requires More Work
---

## Request
Assess Crane NXT, Co. as of 2026-11-18 under the credit_snapshot pathway. This is a consolidated fundamental credit synthesis using FY2025 and Q3 2026 filings, the current earnings release, and the supplied issuer analyses.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 10-K_2025-12-31_cxt.htm.jsonl | Annual report on Form 10-K for the year ended December 31, 2025 | 2026-02-26 | 01187d5c69747fdd7576e6df20b86f97ae44d4962226c99fc0083d69999c404b | Audited operating, financial, customer concentration, acquisition and debt disclosures |
| 10-Q_2026-09-30_cxt.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended September 30, 2026 | 2026-11-04 | 55422b5e495513ada133cd913a2e17251021745f2ce0eee3fa1e4e8436a4d411 | Latest interim cash flow, leverage, debt, Antares and segment disclosures |
| EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl | Third-quarter 2026 earnings release | 2026-11-04 | 67f82d3885906de865063f3f40fbf1da0d9b57013fb7f261abf4484b67df59a9 | Latest segment results, backlog, issuer-adjusted leverage and management outlook |

### Supplied handoffs

| Module | sha256 | Use |
|---|---|---|
| Source readiness (CP-0) | 0f3e5e7f12d07ffbdbeddd8fae567facffd7996b6f24c425e64e6429fee44f2c | Source coverage and readiness boundary |
| Financial foundation (CP-1) | 166274092d989564d2be888406f1a5fb1965230d405fbb01dc4b629b81ff220e | Period construction, carrying debt, cash flow and leverage reconciliation |
| Business & governance (CP-1A) | e081de8f9c8fda18aefdb766c099834b221f3873a678b9aed0ad30bea8ada544 | Business model, customer concentration, acquisition and segment context |

## Findings

### Bottom line
Crane NXT’s positive cash generation and stated long-dated facility maturities support debt service, but acquisition-funded leverage and weak acquired-segment profitability leave creditors exposed to integration and refinancing execution.
Basis: Financial foundation (CP-1); Business & governance (CP-1A); 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21

### Key findings
Reported revenue growth overstates underlying momentum: acquisitions, including Antares Vision, supplied most of the latest reported increase while DTT organic sales declined. DTT’s Q3 margin is below the former CPI-only perimeter, but segment reorganization and acquired-intangible amortization make this comparison non-like-for-like. Integration remains a near-term cash-flow test rather than a proven source of deleveraging.
Basis: EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15

Positive free cash flow supports debt service, but does not yet demonstrate a reduction in creditor risk: carrying-value net debt increased and reported LTM leverage is higher than at FY2025. The issuer’s lower adjusted leverage uses a different debt and EBITDA definition, so the two ratios should not be blended.
Basis: Financial foundation (CP-1); calculation C2-03; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10

Customer concentration is material within SAT: one unnamed customer accounted for a substantial share of sales, leaving that segment exposed to customer order, renewal and product decisions that cannot be monitored through named-customer disclosures.
Basis: Business & governance (CP-1A); 10-K_2025-12-31_cxt.htm.jsonl, page 91; calculation C2-05

### Contrary evidence and what would change the view
The strongest counterweight is cash generation alongside higher reported order backlog. The latest release also gives FY2026 sales-growth and adjusted EBITDA margin guidance, though this remains management’s forward-looking view rather than a realized result. Those indicators could support faster deleveraging if backlog converts, acquired businesses move toward operating profitability and cash is retained for debt reduction. The view would improve with successive periods of organic growth, DTT margin recovery and lower carrying net debt; it would weaken if acquired sales mask continued organic contraction, Antares operating losses persist or distributions and further acquisitions consume cash generation.
Basis: EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 2, 6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15; calculation C2-04

### Limitations
- The downside case is qualitative because the latest release gives broad annual sales and adjusted-margin guidance but no integrated quarterly cash forecast or volume, price, working-capital and cost sensitivities; this prevents a defensible estimate of stressed debt-service capacity and liquidity runway.
  Basis: 10-Q_2026-09-30_cxt.htm.jsonl, pages 2–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 2–3
- This fundamental view does not establish the relative value of any specific Crane NXT bond or loan because no instrument-level market price is assessed; it should not be used as a security selection or position-size conclusion.
  Basis: Source readiness (CP-0)

### Credit view
Crane NXT combines authentication, payment-verification, product-security and traceability activities, with cash generation that has covered capital spending and cash interest in the latest reported period. The creditor case is constrained by a sharp increase in carrying debt following acquisitions, carrying-value leverage above the issuer-adjusted presentation, SAT customer concentration and the acquired Antares business’s operating loss. A larger backlog and positive free cash flow provide support, but backlog is not cash and the segment reorganization limits annual comparability. The primary downside path is delayed integration or customer/order weakness reducing margins and cash conversion, slowing debt reduction and increasing dependence on future refinancing. Stated loan maturities are several years away, although principal allocations by maturity are incomplete.
Basis: Financial foundation (CP-1); Business & governance (CP-1A); 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6, 9

### Key credit metrics
The following metrics show improving current-period cash generation alongside higher leverage and acquisition-related operating volatility.

| Metric | Latest observation | Comparison | Credit implication | Source |
|---|---|---|---|---|
| Revenue | 9M 2026: USD 1,378.0 million | 9M 2025: USD 1,179.8 million; latest Q3 organic increase was USD 4.9 million, or 1.1%, against USD 50.0 million of acquired sales | Most reported growth reflects acquired contribution, not organic acceleration | 10-Q_2026-09-30_cxt.htm.jsonl, page 2; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1 |
| DTT segment | Q3 2026 sales USD 253.6 million; operating profit USD 35.7 million; margin 14.1% | Q3 2025 former CPI-only perimeter margin 28.1%; Antares reported an operating loss of USD 24.2 million in 9M 2026 following consolidation | Integration and amortization depress reported profitability; the reorganization makes the margin comparison non-like-for-like and standalone cash return is not isolated | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1; 10-Q_2026-09-30_cxt.htm.jsonl, page 13 |
| SAT segment | Q3 2026 sales USD 243.5 million; operating profit USD 46.1 million | Organic sales increased USD 16.4 million, or 7.2%, year over year | SAT currently offsets DTT weakness, but customer concentration limits the protection | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1; 10-K_2025-12-31_cxt.htm.jsonl, page 91 |
| Large SAT customer | FY2025 sales USD 210.7 million, 12.7% of company sales and 26.0% of SAT sales | FY2024 sales USD 209.2 million; FY2023 USD 213.1 million | Persistent exposure could transmit customer-specific order losses to revenue and cash flow | 10-K_2025-12-31_cxt.htm.jsonl, page 91; calculation C2-05 |
| Order backlog | USD 715.5 million at September 2026 | USD 492.8 million at December 2025; includes about USD 125 million from Antares | Supports revenue visibility, subject to conversion and acquired-order delivery | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 6 |
| Free cash flow | 9M 2026: USD 139.5 million | 9M 2025: USD 102.3 million | Positive post-capex cash flow supports interest and debt service before acquisition spending and distributions | 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5; calculation C2-04 |
| Carrying debt and net debt | September 2026: USD 1,382.5 million gross carrying debt; USD 1,131.4 million net debt | FY2025 net debt: USD 905.7 million; no subsequent event adjustment was found through the as-of date | Acquisition financing has absorbed the cash-flow benefit; no pro forma event amount is applicable | 10-Q_2026-09-30_cxt.htm.jsonl, page 3; Financial foundation (CP-1) |
| Carrying net leverage | 3.03x LTM reported EBITDA at September 2026 | 2.56x at FY2025; issuer reports 2.5x using gross principal before deferred financing costs and adjusted EBITDA | Definitions differ; carrying-value leverage better reflects reported balance-sheet debt against reported EBITDA | Financial foundation (CP-1); EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10; calculation C2-03 |

### Operating model and business risk synthesis
Crane NXT sells equipment, software and services used to verify currency and payments, protect physical products, and authenticate or trace products through supply chains. SAT’s banknote and product-security activity provides a current profit offset to DTT; DTT combines the former CPI business with Antares Vision. This addition broadens the product and end-market set but creates integration risk and makes pre- and post-acquisition segment comparisons non-like-for-like. The filings identify a persistent individually significant SAT customer, but do not name it or disclose its contract duration. Those facts constrain conclusions about customer switching costs and renewal resilience.
Basis: Business & governance (CP-1A); 10-K_2025-12-31_cxt.htm.jsonl, pages 7–8, 89–91; 10-Q_2026-09-30_cxt.htm.jsonl, pages 8, 14–15

The source evidence supports a limited competitive assessment: proprietary authentication solutions and customer use in banknotes, consumer goods and government tax stamps create differentiated product applications, while the significant SAT customer and lower DTT organic sales demonstrate concentrated demand and exposure to order timing. The documents do not quantify market share, switching costs, supplier dependence or competitor pricing, so those factors do not support a stronger competitive-position conclusion. The annual report identifies macroeconomic, trade-policy, inflation, foreign-exchange and geopolitical risks that could weaken customer demand, raise sourcing costs or make refinancing less favorable. It also reports FY2025 interest-rate and currency sensitivities, but neither those disclosures nor the subsequent interim filing quantify current demand, input-cost or refinancing sensitivities. In credit-translated SWOT terms, backlog and SAT profitability are supports; acquired-business losses, customer concentration, rising debt and non-comparable segment history are constraints; Antares’s life-science and food traceability applications are a potential growth avenue, while delayed integration or order conversion is the principal threat.
Basis: Business & governance (CP-1A); 10-K_2025-12-31_cxt.htm.jsonl, pages 4, 13, 47; 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15, 34; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6

### Cost structure, cash conversion and financing
Operating cash flow of USD 184.5 million and free cash flow of USD 139.5 million in 9M 2026 exceed the prior-year period. The improvement supports debt service, but cash flow was not fully available for principal reduction: acquisition payments and dividends competed with deleveraging, and the Antares contribution has not been separately reconciled to post-close EBITDA and cash generation. Reported LTM cash-interest cover remains positive, but carrying-value net debt and leverage increased since year-end. The company’s 2.5x figure uses adjusted EBITDA and principal before financing costs; it is not directly comparable with the 3.03x carrying-value net leverage calculation.
Basis: Financial foundation (CP-1); 10-Q_2026-09-30_cxt.htm.jsonl, pages 3–5, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10; calculation C2-03; calculation C2-04

The Credit Agreement facilities have stated maturities several years beyond the latest reporting date. The latest filing does not allocate all current loan principal by maturity year, so the stated dates identify refinancing windows but not a complete maturity wall. A revolving commitment is disclosed, but current letter-of-credit use is not reported; the FY2025 filing reported USD 97.5 million of standby letters, so current undrawn liquidity cannot be inferred from that older balance. This leaves the near-term liquidity conclusion supported by positive cash and operating cash flow, while exact committed availability and facility headroom remain unestablished.
Basis: Financial foundation (CP-1); 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21; 10-K_2025-12-31_cxt.htm.jsonl, pages 105–109

### Outlook and downside
Over the next year, the main upside is conversion of the reported backlog and realization of management’s stated FY2026 sales-growth and adjusted-margin outlook. Over a longer horizon, Antares may expand traceability exposure in life sciences and food and beverage, but the filings do not establish standalone acquired-business returns. The principal downside is a delayed integration or weaker customer and order demand: DTT’s acquired contribution would fail to cover its lower organic sales, group operating profit would weaken, and working-capital absorption could reduce free cash flow. Lower cash generation would slow debt reduction and increase reliance on refinancing, although stated facility maturities are not immediate. Cost alignment and cash retention are management levers, but the supplied evidence does not quantify savings, fixed-cost flexibility or downside runway.
Basis: Business & governance (CP-1A); Financial foundation (CP-1); 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15, 21–22; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 2, 6


The latest management outlook is forward-looking and should not be treated as achieved performance.
Basis: EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 2–3

| Outlook measure | FY2026 guidance | Credit use | Source |
|---|---|---|---|
| Sales growth | Approximately 14% | Sets management’s sales expectation, not a realized base case | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 2 |
| Adjusted EBITDA margin | Approximately 24% | Management-defined profitability goal; cash conversion remains to be observed | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.jsonl, page 2 |



### Strengths and weaknesses
The principal strengths are demonstrated post-capex cash generation, a larger backlog, SAT’s current profit contribution and debt facilities with stated maturities several years beyond the latest reporting date. Each provides time or cash-flow capacity to service debt if backlog converts and acquired activities improve.
Basis: Financial foundation (CP-1); EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6; 10-Q_2026-09-30_cxt.htm.jsonl, pages 20–21

The principal weaknesses are the increase in carrying-value net debt, the acquisition-related operating loss and lower DTT margin, persistent SAT customer concentration, and incomplete loan maturity allocation. Together they reduce visibility into the pace of deleveraging, concentration resilience and the amount of debt requiring refinancing at each stated date.
Basis: Financial foundation (CP-1); Business & governance (CP-1A); 10-K_2025-12-31_cxt.htm.jsonl, page 91; 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15, 20–21


### Overall credit view
Crane NXT’s disclosed product applications, backlog and positive free cash flow support debt service, while acquisition-funded leverage, Antares losses and customer concentration constrain the credit profile. The business cannot be ranked against typical leveraged-credit issuers from these issuer-only materials. Financial capacity weakened on a carrying-value basis since FY2025, although positive cash flow moderates the pressure. Refinancing depends on organic demand, acquired-margin repair, cash retention and execution ahead of stated facility dates; the principal downside is weaker orders or delayed integration reducing margins and cash conversion. A more definitive view needs a current loan-principal schedule by maturity and an integrated cash forecast that tests customer, margin and working-capital shocks.
Basis: Financial foundation (CP-1); Business & governance (CP-1A); Source readiness (CP-0); 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.jsonl, page 6

### Confidence inputs

| Input | Value |
|---|---|
| Directly Sourced | 9 |
| Calculated | 5 |
| Assumption-Based | 0 |
| Analyst Inference | 6 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 0 |
| Insufficient Information | 4 |
| Fields present | 30 |
| Fields total | 30 |
| Source gate | partial |
| CRITICAL | 0 |
| MATERIAL | 0 |
| MINOR | 0 |

### Map: credit-risk transmission

| From | Relationship | Edge type | To | Evidence |
|---|---|---|---|---|
| SAT customer concentration | Customer-specific orders can reduce SAT revenue if demand or renewal weakens. | Analyst Interpretation | SAT revenue exposure | One customer generated USD 210.7 million of FY2025 sales; 10-K_2025-12-31_cxt.htm.jsonl, page 91. |
| SAT revenue exposure | Lower sales would reduce segment earnings and cash available for debt service. | Analyst Interpretation | Cash generation | Concentrated sales are exposed to a customer decision; 10-K_2025-12-31_cxt.htm.jsonl, page 91. |
| Antares integration | Acquisition amortization and transaction costs contributed to an operating loss. | Documentary Fact | DTT profitability | Antares reported an operating loss of USD 24.2 million in the 9M 2026 consolidated reporting period following the acquisition date; 10-Q_2026-09-30_cxt.htm.jsonl, page 13. |
| DTT profitability | Persistent losses or margin compression would reduce group operating cash generation. | Analyst Interpretation | Debt reduction capacity | DTT operating margin was 14.1% in Q3 2026 versus 28.1% in Q3 2025; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1. |
| Backlog conversion | Firm orders may provide revenue visibility when delivered and recognized. | Analyst Interpretation | Near-term revenue visibility | Reported backlog was USD 715.5 million at September 2026; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 6. |
| Near-term revenue visibility | Successful delivery supports utilization and cash receipts, subject to cost and collection. | Analyst Interpretation | Debt service capacity | Backlog increased; conversion timing remains dependent on delivery; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 6. |
| Acquisition-funded debt | Higher carrying debt raises the earnings and cash flow needed for deleveraging. | Analyst Interpretation | Carrying net leverage | Net debt was USD 1,131.4 million and reported LTM net leverage was 3.03x; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 20–21. |
| Carrying net leverage | Reduced cash conversion would slow deleveraging and increase refinancing dependence. | Analyst Interpretation | Refinancing exposure | Financial foundation reconciles carrying debt and reported EBITDA; Financial foundation (CP-1). |

### Analytical appendix — complete canonical registers

### T2.1 Source register

| source_document_id | source_document_name | source_quality | period | entity_covered | data_supplied | limitation | downstream_use |
|---|---|---|---|---|---|---|---|
| S1 | 10-K_2025-12-31_cxt.htm.jsonl | Tier 1, audited SEC annual filing | FY2025 and FY2024 comparative data | Crane NXT, Co. and subsidiaries | Audited statements, segments, customer concentration, acquisition and debt disclosures | Year-end statements precede the Antares control date; acquired standalone post-close cash returns are not separately stated | Historical baseline and concentration context for the fundamental analysis |
| S2 | 10-Q_2026-09-30_cxt.htm.jsonl | Tier 2b, unaudited SEC quarterly filing | Q3 and 9M 2026, with 2025 comparatives | Crane NXT, Co. and subsidiaries | Current interim statements, debt, financing activity, acquisition and segment disclosures | Interim information; current loan principal by maturity and standalone Antares cash flow are not fully allocated | Current cash-flow, leverage, operating and financing evidence |
| S3 | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl | Tier 2c, issuer earnings release | Q3 and 9M 2026, with 2025 comparatives | Crane NXT, Co. and reportable segments | Adjusted measures, organic and acquired sales bridges, backlog and management outlook | Management-defined non-GAAP measures and forward-looking guidance are supplemental | Latest operating trend and issuer-defined adjusted measure context |

### T2.10 Materiality filter

| Rank | Driver | Evidence | Risk Mechanic | Credit Implication | Direction | Confidence |
|---:|---|---|---|---|---|---|
| 1 | Acquisition-related carrying leverage | Carrying net debt USD 1,131.4 million; carrying net leverage 3.03x at September 2026; issuer reports adjusted 2.5x on a different basis; 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10 | Debt increased faster than cash flow capacity; lower reported EBITDA leaves less room for debt service and deleveraging | Cash retention and EBITDA conversion must improve to reduce refinancing dependence | Negative | High |
| 2 | Acquired-segment operating performance | Antares operating loss USD 24.2 million in the 9M 2026 consolidated reporting period; DTT Q3 operating margin 14.1% versus 28.1% for the former CPI-only perimeter; 10-Q_2026-09-30_cxt.htm.jsonl, pages 13–15; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1 | Acquisition-related amortization, transaction costs and lower DTT organic sales reduce current profitability | A prolonged margin gap would slow debt reduction and weaken forecast reliability | Negative | High |
| 3 | SAT customer concentration | One customer accounted for USD 210.7 million, 12.7% of company sales and 26.0% of SAT in FY2025; 10-K_2025-12-31_cxt.htm.jsonl, page 91; calculation C2-05 | Loss or reduced orders from one customer would flow disproportionately into SAT sales | Monitor renewal and order continuity; customer-specific loss could weaken group cash generation | Negative | High |
| 4 | Free cash flow and order backlog | 9M 2026 free cash flow USD 139.5 million; backlog USD 715.5 million at September 2026; 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 6 | Cash generation and firm orders can support debt service, but conversion and acquisition cash needs determine cash retained | Provides a current buffer for interest and debt reduction if delivery and collection continue | Positive | Medium |
| 5 | Stated facility maturity dates with incomplete principal allocation | Term Loan A and revolver mature in 2030; Term Loan B in 2032; USD 862.6 million of loan and other debt principal is not allocated by maturity year in the current schedule; 10-Q_2026-09-30_cxt.htm.jsonl, page 21; Financial foundation (CP-1) | Aggregated dates do not show debt due in each year or exact refinancing needs | Refinancing timing remains uncertain despite no stated near-term facility expiry | Negative | Medium |

### T2.12 Monitoring triggers

| Trigger | Threshold / Signal | Why It Matters | Credit Impact | Source / Limitation |
|---|---|---|---|---|
| Revenue decline | Track comparable organic sales by DTT and SAT; investigate consecutive reported-period declines or backlog conversion below current trajectory. | Acquisition growth can mask contraction in the existing businesses. | Sustained organic contraction would reduce cash generation and weaken the deleveraging case. | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6; no issuer threshold stated. |
| EBITDA margin pressure | Compare DTT with its Q3 2026 operating-margin baseline of 14.1%; investigate further compression, treating the former CPI-only prior-year margin as contextual rather than like-for-like evidence. | Lower segment margin transmits directly into earnings and acquired-business cash return. | Persistent pressure would reduce consolidated interest coverage and debt-reduction capacity. | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1; Q3 2025 comparison uses the former segment perimeter. |
| FCF deterioration | Monitor whether operating cash flow continues to cover capital spending and cash interest, and whether conversion weakens from the 9M 2026 baseline. | Free cash flow is the available internally generated source for debt service, integration and deleveraging. | Lower conversion would increase reliance on revolver drawings or refinancing; no issuer-defined threshold is supplied. | 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5; Financial foundation (CP-1). |
| Liquidity reduction | Cash below the September 2026 balance of USD 251.1 million, rising revolver drawings or increased letter-of-credit use. | Cash and committed undrawn capacity absorb working-capital swings and integration costs. | A declining liquidity buffer would reduce execution flexibility; exact net revolver availability is not established. | 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 20–21; 10-K_2025-12-31_cxt.htm.jsonl, page 109 (USD 97.5 million of standby letters at FY2025; no current update); Financial foundation (CP-1). |
| Leverage increase | Track carrying-value net debt to reported LTM EBITDA against the September 2026 baseline of 3.03x. | A rising ratio can reflect additional debt, lower earnings or both. | Further increase would slow deleveraging and make refinancing more sensitive to operating results. | Financial foundation (CP-1); calculation C2-03. |
| Refinancing delay | Track extension, repayment or refinancing progress ahead of stated 2030 Term Loan A/revolver and 2032 Term Loan B maturities. | Long-dated facility maturities still require a funding path; principal by maturity is incomplete. | Delay would concentrate funding risk around contractual dates; no exact principal wall is established. | 10-Q_2026-09-30_cxt.htm.jsonl, page 21; 10-K_2025-12-31_cxt.htm.jsonl, pages 105–108; Financial foundation (CP-1). |
| Sponsor/shareholder action | Monitor any new debt-funded acquisition, dividend increase or other distribution, particularly if carrying net debt is not declining. | M&A and distributions compete with debt reduction for free cash flow. | Cash leakage could delay deleveraging; no sponsor or controlling shareholder is identified in the supplied evidence. | 10-Q_2026-09-30_cxt.htm.jsonl, pages 8–10; Business & governance (CP-1A). |
| Sector deterioration | Monitor customer order trends, backlog cancellation or slippage, and SAT/DTT organic demand indicators disclosed in later filings. | Demand weakening in end markets can reduce equipment orders and product-security volumes. | Broad order weakness would reduce earnings and may add working-capital pressure; no industry threshold is supplied. | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 1, 6; independent sector series not supplied. |

### CP-MODEL strengths and weaknesses

<!-- table-id: cp2.cp_model_strengths_weaknesses -->
| direction | rank | label | mechanism | evidence_ids | status | source_id | source_locator | as_of |
|---|---:|---|---|---|---|---|---|---|
| STRENGTH | 1 | Positive free cash flow | Post-capex cash supports interest and debt service when acquired-business cash needs are contained. | S2 | READY | S2 | pages 4–5 | 2026-11-18 |
| STRENGTH | 2 | Growing order backlog | Firm orders can support revenue conversion and operating cash generation as delivery proceeds. | S3 | READY | S3 | page 6 | 2026-11-18 |
| STRENGTH | 3 | SAT profitability | Current SAT operating profit offsets pressure in DTT and supports group earnings. | S3 | READY | S3 | page 1 | 2026-11-18 |
| WEAKNESS | 1 | Acquisition-funded leverage | Higher carrying net debt raises cash flow required for deleveraging and future refinancing. | S2 | READY | S2 | pages 3, 20–21 | 2026-11-18 |
| WEAKNESS | 2 | Antares operating loss | Acquisition costs and weaker DTT margin reduce current earnings and obscure acquired cash returns. | S2; S3 | READY | S2 | pages 13–15 | 2026-11-18 |
| WEAKNESS | 3 | Significant SAT customer | Concentrated customer sales expose a material portion of SAT revenue to one buyer’s order and renewal choices. | S1 | READY | S1 | page 91 | 2026-11-18 |

## Calculations

| ID | Calculation | Inputs and formula | Result | Unit | Source |
|---|---|---|---|---|---|
| C2-01 | LTM revenue to September 30, 2026 | FY2025 1,656.7 + 9M 2026 1,378.0 − 9M 2025 1,179.8 | 1,854.9 | USD millions | 10-K_2025-12-31_cxt.htm.jsonl, page 52; 10-Q_2026-09-30_cxt.htm.jsonl, page 2 |
| C2-02 | LTM reported EBITDA to September 30, 2026 | FY2025 353.3 + 9M 2026 264.9 − 9M 2025 244.8 | 373.4 | USD millions | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 54; 10-Q_2026-09-30_cxt.htm.jsonl, pages 2, 4; Financial foundation (CP-1) |
| C2-03 | Carrying-value net leverage | September 2026 carrying debt 1,382.5 − cash 251.1 = net debt 1,131.4; net debt 1,131.4 ÷ LTM reported EBITDA 373.4 = 3.03x. Issuer adjusted basis: gross principal 1,412.6 − cash 251.1 = 1,161.5; ÷ TTM Adjusted EBITDA 460.3 = 2.52x, reported as 2.5x. | Net debt 1,131.4; carrying net leverage 3.03x; issuer adjusted leverage 2.5x reported | USD millions; times | 10-Q_2026-09-30_cxt.htm.jsonl, pages 3, 20–21; EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, pages 9–10; Financial foundation (CP-1) |
| C2-04 | Free cash flow comparison | 9M 2026 operating cash flow 184.5 − capital spending 45.0 = 139.5; 9M 2025 operating cash flow 135.7 − capital spending 33.4 = 102.3 | 139.5 and 102.3 | USD millions, respectively | 10-Q_2026-09-30_cxt.htm.jsonl, pages 4–5; Financial foundation (CP-1) |
| C2-05 | FY2025 significant SAT customer share | Customer sales 210.7 ÷ company sales 1,656.7 = 12.7%; customer sales 210.7 ÷ SAT sales 810.1 = 26.0% | 12.7% of company sales; 26.0% of SAT sales | Percent | 10-K_2025-12-31_cxt.htm.jsonl, pages 52, 89, 91; Business & governance (CP-1A) |
| C2-06 | DTT Q3 2026 operating margin | Q3 operating profit 35.7 ÷ segment sales 253.6 = 14.1%; reported Q3 2025 margin 28.1% | 14.1% | Percent | EX99.1_2026-09-30_cxt_exhibit991-pressreleasexq3-htm.htm.jsonl, page 1 |

## Gaps
No additional evidence gap changes the conclusions beyond the conclusion-changing limitations stated above.

## Next module
The orchestrator selects the next module.
