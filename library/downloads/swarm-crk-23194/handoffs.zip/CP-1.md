---
issuer_id: crk-23194
module_id: CP-1
analysis_date: 2026-11-18
run_id: crk-23194-2026-11-18-credit_snapshot-host
---

## Request

Comstock Resources Inc, as of 2026-11-18, for the credit_snapshot pathway. Scope: consolidated financial statements, debt and liquidity through 2026-09-30, with subsequent financing and asset-sale developments through the cutoff.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 10-K_2024-12-31_crk.htm.jsonl | Annual report on Form 10-K for FY2024 | 2025-02-21, signature date | 573187cc759c1ddea7c19cbed85103f9de784b84068ad1f069616d53b3e50b5d | FY2024 statements, cash spending, debt and commitments |
| 10-K_2025-12-31_crk.htm.jsonl | Annual report on Form 10-K for FY2025 | 2026-02-19, signature date | 12ac885c29363474639ac322947a020de6bb51304e642efc61d014faf9dc6c42 | FY2025 audited statements, debt, leases, commitments and transaction history |
| 10-Q_2026-03-31_crk.htm.jsonl | Quarterly report on Form 10-Q for Q1 2026 | 2026-05-06, signature date | 0ab54d7a64d72e20c298d655c35f6bf913d9d4292578a3cf7c1d924042c6f0d1 | Interim results and comparative source coverage |
| 10-Q_2026-06-30_crk.htm.jsonl | Quarterly report on Form 10-Q for Q2 2026 | 2026-07-30, signature date | b32ec30d3a928a0c7e848a82cfe993544f549cf4d36b65127a3d8ded2384f633 | Interim results and financing activity |
| 10-Q_2026-09-30_crk.htm.jsonl | Quarterly report on Form 10-Q for Q3 2026 | 2026-11-05, signature date | ac2df52d79abc76f06043e3b129bdcf68705d2e5a4044e8b86abd40d62a5351a | Latest statements, debt, liquidity, operating commitments and subsequent events |
| EX99.1_2026-03-31_crk_crk-ex99-1-htm.htm.jsonl | First-quarter 2026 financial and operating results release | 2026-05-05, release date stated | 07421ce1120c7d1aa01229881aa6226301661e78bad274f77f20b9315c629392 | Management's Q1 operating measures and commentary |
| EX99.1_2026-06-30_crk_crk-ex99-1-htm.htm.jsonl | Second-quarter 2026 financial and operating results release | 2026-07-29, release date stated | 6e7daf261ae302c5c1acf6af33c14648ece4908285b4f9b8d17c9eaf1b1b92d6 | Management's Q2 operating measures and commentary |
| EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl | Third-quarter 2026 financial and operating results release | 2026-11-04, release date stated | 713c0c09d0c85716b5e5e1f5fa9c725fe47ad70dbe28a00e48d93cc02a70032e | Q3 and nine-month non-GAAP reconciliations and operating results |

Supplied handoff: Source readiness (CP-0), sha256 b25fbdcf8aa44f26c4bdad6e5bfae003c479d5ee736aae25e44c693a7549ffb4.

## Findings

### Bottom line

Comstock's latest balance sheet shows 2.68x carrying debt to house-calculated LTM EBITDA, while cash capital spending left LTM free cash flow materially negative; creditors therefore remain exposed to continued drilling funding needs and the 2028–2030 debt wall. The announced SOCAR sale could change that profile, but it had not closed by the cutoff.

Latest reported liquidity is USD 868.6 million, including USD 150 million restricted to PGS midstream activity. The sale agreement states a USD 1.65 billion cash price but gives no pro forma debt or net leverage; none is inferred here.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–21 and 27–30; calculation C2; calculation C4; calculation C7

### Financials and credit metrics

| Period | Revenue | House-calculated EBITDA | Carrying debt | Cash | Net debt | Debt / EBITDA | Net debt / EBITDA | Cash interest paid | Cash FCF | Liquidity | Basis and limitation | Source |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FY2024 | 1,254.455 | 626.782 | 2,952.090 | 6.799 | 2,945.291 | 4.71x | 4.70x | 190.016 | (465.153) | Not supplied: comparable year-end liquidity is not stated | USD millions; EBITDA is operating income plus DD&A; FCF is CFO less cash capital expenditures | 10-K_2025-12-31_crk.htm.jsonl, pages 81–83 and 98–100; calculations C1, C3, C4 |
| FY2025 | 2,220.289 | 1,287.015 | 2,809.066 | 23.930 | 2,785.136 | 2.18x | 2.16x | 210.820 | (444.671) | Not supplied: comparable year-end liquidity is not stated | USD millions; FY2025 EBITDA includes the reported gain on asset sale; FCF is CFO less cash capital expenditures | 10-K_2025-12-31_crk.htm.jsonl, pages 81–83 and 98–100; calculations C1, C3, C4 |
| LTM ended 2026-09-30 | 2,114.813 | 1,252.549 | 3,356.968 | 18.633 | 3,338.335 | 2.68x | 2.67x | 210.047 | (810.364) | 868.633 | USD millions; LTM is FY2025 plus 9M2026 less 9M2025; LTM debt and cash are at 2026-09-30 | 10-Q_2026-09-30_crk.htm.jsonl, pages 2–4, 18–20 and 27–30; 10-K_2025-12-31_crk.htm.jsonl, pages 62, 81–83 and 98–100; calculations C1–C4, C7 |

The FY2025 comparison is not a clean recurring-growth signal: reported revenue includes a large asset-sale gain, while the company's non-GAAP adjusted EBITDAX separately removes specified items including unrealized hedge gains and exploration expense. The FY2025 annual report does not report adjusted EBITDAX for FY2025, so that series is not extended to a full-year or LTM amount.
Basis: 10-K_2025-12-31_crk.htm.jsonl, pages 82 and 99; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, pages 6–7; calculation C1; calculation C2

Nine-month operating EBITDA and issuer-reported adjusted EBITDAX were both lower than their comparable 2025 periods, while Q3 production rose year over year. Creditors should not extrapolate the stronger quarter without the full-year cash and commodity-price outcome.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 3; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, pages 2, 5–7; calculation C1

Capital spending remains the binding cash-flow pressure: nine-month cash capital expenditures substantially exceeded operating cash flow, leaving cash FCF negative before financing. Financing included a large PGS noncontrolling-interest contribution and a redemption; neither is recurring operating cash flow or issuer debt repayment.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 4–5 and 27; calculation C4

The latest debt measure is balance-sheet carrying value, not principal. At 2026-09-30, contractual principal exceeds carrying debt because note discounts and bank debt issuance costs reduce the reported balance. This keeps the debt denominator consistent with the statements and avoids overstating it by using face value.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 19; calculation C3; calculation C5

Comstock's USD 1.5 billion facility had USD 800 million drawn at 2026-09-30 and USD 700 million of unused commitment; PGS had no drawing on its USD 150 million facility, whose availability is restricted to midstream activity. The combined unused amount and reported cash reconcile to reported liquidity of USD 868.6 million. Neither the parent availability nor the PGS availability is a substitute for actual cash, and the PGS portion is not freely fungible for upstream debt service.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20 and 27–29; calculation C7

The SOCAR agreement is the strongest potential deleveraging counterweight: it provides for USD 1.65 billion of cash consideration for specified upstream and PGS interests, effective 2026-07-01, with closing expected by year-end subject to customary conditions. Management says it plans to repay the bank facility and retire part of the 2029 notes. No sale proceeds had been received and no repayment split or pro forma debt was stated at the cutoff, so the reported LTM leverage above remains pre-transaction.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 21 and 30; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 1

The strongest contrary evidence is the Q3 production increase and management's disclosed USD 868.6 million liquidity, alongside the pending asset sale. Those factors could ease refinancing pressure if sustained production funds a larger share of drilling and SOCAR closes on the stated terms. The concern remains because cash capital spending exceeded operating cash flow through 9M2026 and the sale's proceeds have not been translated into a completed debt reduction.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 27–30; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 1; calculation C4

### Period table

| Period | Start | End |
|---|---|---|
| FY2024 | 2024-01-01 | 2024-12-31 |
| FY2025 | 2025-01-01 | 2025-12-31 |
| Q3 2025 | 2025-07-01 | 2025-09-30 |
| Q3 2026 | 2026-07-01 | 2026-09-30 |
| 9M 2025 | 2025-01-01 | 2025-09-30 |
| 9M 2026 | 2026-01-01 | 2026-09-30 |

### T4.1 Source register

| Source File Name | Document Type | Period Coverage | Currency | Unit | Perimeter | Accounting Basis | Evidence Quality Tier | Analytical Use | Limitations |
|---|---|---|---|---|---|---|---|---|---|
| 10-K_2024-12-31_crk.htm.jsonl | Audited annual report | FY2024 and comparative years | USD | thousands | Comstock Resources Inc and subsidiaries | US GAAP | Tier 1 | Annual financial and debt baseline | Annual periods; historical balance-sheet and commitment data |
| 10-K_2025-12-31_crk.htm.jsonl | Audited annual report | FY2025 and comparative years | USD | thousands | Comstock Resources Inc and subsidiaries | US GAAP | Tier 1 | Latest audited financial, debt and lease baseline | Contains nonrecurring asset-sale gain in revenue |
| 10-Q_2026-03-31_crk.htm.jsonl | Unaudited quarterly report | Q1 2026 and comparative period | USD | thousands | Comstock Resources Inc and subsidiaries | US GAAP | Tier 2b | Interim statements and note updates | Unaudited |
| 10-Q_2026-06-30_crk.htm.jsonl | Unaudited quarterly report | Q2 2026, H1 2026 and comparative periods | USD | thousands | Comstock Resources Inc and subsidiaries | US GAAP | Tier 2b | Interim statements and transaction changes | Unaudited |
| 10-Q_2026-09-30_crk.htm.jsonl | Unaudited quarterly report | Q3 2026, 9M 2026 and comparative periods | USD | thousands | Comstock Resources Inc and consolidated subsidiaries including PGS | US GAAP | Tier 2b | Latest financial statements, debt and liquidity | Unaudited; subsequent sale and credit amendment were pending |
| EX99.1_2026-03-31_crk_crk-ex99-1-htm.htm.jsonl | Issuer earnings release | Q1 2026 | USD | thousands unless per-unit | Comstock Resources Inc | Non-GAAP and operating measures alongside reported statements | Tier 2b | Operating measures and management commentary | Issuer-defined measures |
| EX99.1_2026-06-30_crk_crk-ex99-1-htm.htm.jsonl | Issuer earnings release | Q2 2026 and H1 2026 | USD | thousands unless per-unit | Comstock Resources Inc | Non-GAAP and operating measures alongside reported statements | Tier 2b | Operating measures and management commentary | Issuer-defined measures |
| EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl | Issuer earnings release | Q3 2026 and 9M 2026 | USD | thousands unless per-unit | Comstock Resources Inc | Non-GAAP and operating measures alongside reported statements | Tier 2b | Adjusted EBITDAX, working-capital bridge and operating data | Issuer-defined measures |
| Source readiness (CP-0) | Accepted source-readiness handoff | As of 2026-11-18 | — | — | crk-23194 | Source readiness | Tier 1 for source lineage | Source identity and period coverage | No financial conclusion carried forward |

### T4.2 Entity period key

| Entity Name | Entity Role | Fiscal Year End | Reporting Currency | Reporting Unit | Consolidation Perimeter | Accounting Basis | Available Periods |
|---|---|---|---|---|---|---|---|
| Comstock Resources Inc | Public issuer and parent | December 31 | USD | thousands in statements; millions in financial summary | Issuer and consolidated subsidiaries; PGS is consolidated | US GAAP | FY2024, FY2025, Q1–Q3 2026, 9M 2026, and 9M comparative data |
| Pinnacle Gas Services LLC (PGS) | Consolidated midstream subsidiary with noncontrolling investors | December 31 | USD | thousands in statements | Consolidated by Comstock; its USD 150 million revolver is for PGS midstream activity | US GAAP | Facility status at 2026-09-30 |

### T4.3 Normalization register

| Adjustment Description | Source File | Adjustment Type | Before Value | After Value | Rationale | Affected Periods |
|---|---|---|---|---|---|---|
| Currency, scale, perimeter and accounting basis | 10-K_2025-12-31_crk.htm.jsonl; 10-Q_2026-09-30_crk.htm.jsonl | Presentation normalization | USD thousands as printed | USD thousands in statements; USD millions only where expressly labelled in summary | Statements already share USD, consolidated Comstock perimeter and US GAAP; source amounts are retained without FX conversion or financial normalization | All periods |

### T4.4 Income statement

| Line item | FY2024 | FY2025 | Q3 2025 | Q3 2026 | 9M 2025 | 9M 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---:|---:|---|---|---|
| Total revenues and other operating income | 1254455 | 2220289 | 447359 | 384363 | 1430475 | 1324999 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Natural gas and oil sales | 1047483 | 1428149 | 308587 | 319881 | 1061541 | 1027135 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Gas services revenue | 206097 | 500202 | 141265 | 64482 | 371427 | 294464 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Gain (loss) on sale of assets | 875 | 291938 | -2493 | Not supplied: source shows a dash | -2493 | 3400 | USD thousands | Reported; dash retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Cost of goods sold | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | USD thousands | Not separately presented for this producer | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Gross profit | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | USD thousands | Not separately presented | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Production and ad valorem taxes | 57437 | 40453 | 11216 | 11032 | 32950 | 28653 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Gathering and transportation | 194890 | 166108 | 39969 | 50012 | 124345 | 135147 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Lease operating | 130504 | 122662 | 28778 | 28457 | 94887 | 84888 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Exploration | Not supplied: no separate line | 10071 | 6600 | 10745 | 8750 | 24515 | USD thousands | Reported; missing where line is not shown | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Depreciation, depletion and amortization | 795397 | 641163 | 157395 | 185655 | 483665 | 494619 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Gas services expense | 205407 | 516224 | 141684 | 59423 | 385167 | 285293 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| General and administrative, net | 39435 | 48685 | 11504 | 16104 | 34884 | 51477 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Impairment of natural gas and oil properties | Not supplied: no separate line | 29071 | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | USD thousands | Reported; missing where line is not shown | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Total operating expenses | 1423070 | 1574437 | 397146 | 361428 | 1164648 | 1104592 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Operating income (loss) | -168615 | 645852 | 50213 | 22935 | 265827 | 220407 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| EBITDA (Reported) | 626782 | 1287015 | 207608 | 208590 | 749492 | 715026 | USD thousands | Calculated as operating income plus DD&A; issuer does not label this as EBITDA | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3; calculation C1 |
| Gain from derivative financial instruments | 10196 | 82537 | 142822 | 74529 | 48330 | 121290 | USD thousands | Reported, non-operating line | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Other income | 1211 | 3144 | 409 | 208 | 2848 | 730 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Interest expense | -210621 | -222797 | -56722 | -58333 | -166737 | -166436 | USD thousands | Reported accrual expense | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Interest income | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | USD thousands | Not separately presented | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Total other income (expenses) | -199214 | -137116 | 86509 | 16404 | -115559 | -44416 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Income (loss) before income taxes | -367829 | 508736 | 136722 | 39339 | 150268 | 175991 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Provision for (benefit from) income taxes | 149075 | -88533 | -18623 | -13973 | -16834 | -23126 | USD thousands | Reported signed expense/(benefit) | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Net income (loss) | -218754 | 420203 | 118099 | 25366 | 133434 | 152865 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Net income attributable to noncontrolling interest | -10897 | -24592 | -6971 | -3096 | -18742 | -14379 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Net income (loss) available to Comstock | -229651 | 395611 | 111128 | 22270 | 114692 | 138486 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 |
| Stock-based compensation | 15261 | 21222 | 5624 | 7477 | 15595 | 23280 | USD thousands | Reported in cash flow/non-GAAP reconciliation; not a separate income-statement row | 10-K_2025-12-31_crk.htm.jsonl, page 83; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |

The 2025 annual sales and EBITDA figures include gains on asset disposals. The calculated EBITDA row is operating income plus DD&A; it is not the issuer's adjusted EBITDAX and includes the asset-sale line carried in reported operating income.
Basis: 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3

### T4.5 Cash flow statement

| Line item | FY2024 | FY2025 | 9M 2025 | 9M 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---|---|---|
| Net income (loss) | -218754 | 420203 | 133434 | 152865 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Deferred income taxes | -124919 | 91982 | 20485 | 23763 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Impairment of natural gas and oil properties | Not supplied: no separate line | 29071 | Not supplied: no separate line | Not supplied: no separate line | USD thousands | Reported where separately stated | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Dry hole costs and abandonments | Not supplied: no separate line | Not supplied: no separate line | Not supplied: no separate line | 6746 | USD thousands | Reported | 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Gain on sale of assets, cash-flow adjustment | -875 | -291938 | 2493 | -3400 | USD thousands | Reported sign as reconciliation adjustment | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Depreciation, depletion and amortization | 795397 | 641163 | 483665 | 494619 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Gain from derivative financial instruments | -10196 | -82537 | -48330 | -121290 | USD thousands | Reported, reversed in CFO reconciliation | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Cash settlements of derivative instruments | 207803 | 20135 | 22708 | 2407 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Amortization of debt discounts and issuance costs | 11476 | 11976 | 8925 | 9398 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Stock-based compensation | 15261 | 21222 | 15595 | 23280 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Change in accounts receivable | 56584 | -60496 | 1900 | 18745 | USD thousands | Reported cash-flow sign | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Change in other current assets | -22893 | 17518 | 24152 | -2978 | USD thousands | Reported cash-flow sign | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Change in accounts payable and accrued expenses | -88547 | 81308 | 10376 | 18224 | USD thousands | Reported cash-flow sign | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Net Cash from Operating Activities | 620337 | 899607 | 675403 | 622379 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Operating cash flow before changes in working capital | Not supplied: source release does not provide FY measure | Not supplied: source release does not provide FY measure | 638975 | 588388 | USD thousands | Issuer-defined non-GAAP; not actual cash generation | EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Capital expenditures and acquisitions | -1097478 | -1349280 | -983828 | -1299936 | USD thousands | Reported outflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Prepaid drilling costs | 11988 | 5002 | 5438 | 8877 | USD thousands | Reported cash-flow sign | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Proceeds from sales of assets | 1214 | 428868 | 15166 | 18415 | USD thousands | Reported inflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Total cash capital expenditures | -1085490 | -1344278 | -978390 | -1291059 | USD thousands | Reported outflow, sign normalized negative | 10-K_2025-12-31_crk.htm.jsonl, page 62; 10-Q_2026-09-30_crk.htm.jsonl, page 27 |
| Net Cash from Investing Activities | -1084276 | -915410 | -963224 | -1272644 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Borrowings on bank credit facilities | 645000 | 750000 | 540000 | 1047000 | USD thousands | Reported inflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Repayments on bank credit facilities | -710000 | -905000 | -375000 | -507000 | USD thousands | Reported outflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Senior notes issuance | 372000 | Not supplied: no separate line | Not supplied: source shows a dash | Not supplied: source shows a dash | USD thousands | Reported; dashes retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Proceeds from common stock issuance | 100450 | Not supplied: no separate line | Not supplied: source shows a dash | Not supplied: source shows a dash | USD thousands | Reported; dashes retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Debt issuance costs | -6855 | -36 | -36 | -1496 | USD thousands | Reported outflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Common stock dividends paid | Not supplied: source shows a dash | Not supplied: source shows a dash | Not supplied: no separate line | Not supplied: no separate line | USD thousands | Source dashes retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Income-tax withholding on equity awards | -3373 | -11010 | -11010 | -5514 | USD thousands | Reported outflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Redemption of noncontrolling interest | Not supplied: no separate line | Not supplied: no separate line | Not supplied: source shows a dash | -445000 | USD thousands | Reported; dashes retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Contributions from noncontrolling interest | 60500 | 215500 | 156500 | 600126 | USD thousands | Reported inflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Distributions to noncontrolling interest | -3653 | -16520 | -10217 | -24589 | USD thousands | Reported outflow | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Noncontrolling-interest transaction costs | Not supplied: no separate line | Not supplied: no separate line | Not supplied: source shows a dash | -18559 | USD thousands | Reported; dash retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Net Cash from Financing Activities | 454069 | 32934 | 300237 | 644968 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Net Cash Change | -9870 | 17131 | 12416 | -5297 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Opening Cash | 16669 | 6799 | 6799 | 23930 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Closing Cash | 6799 | 23930 | 19215 | 18633 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 |
| Cash Interest Paid | 190016 | 210820 | 199841 | 199068 | USD thousands | Cash interest; kept separate from interest expense | 10-K_2025-12-31_crk.htm.jsonl, page 98; 10-Q_2026-09-30_crk.htm.jsonl, page 18 |
| Cash income taxes paid (refunds) | 37 | -31000 | -31000 | Not supplied: source shows a dash | USD thousands | Cash-tax disclosure; refunds shown negative; dash retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 98; 10-Q_2026-09-30_crk.htm.jsonl, page 18 |

### T4.6 Balance sheet

| Line item | FY2024 | FY2025 | Q3 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---|---|---|
| Cash & Equivalents | 6799 | 23930 | 18633 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Accounts receivable, excluding separately listed derivatives | 174846 | 242545 | 223800 | USD thousands | Calculated as the sum of natural gas/oil sales and gas services, joint interest operations, and affiliate receivables | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Current derivative financial instruments | 4865 | 19206 | 108576 | USD thousands | Reported current asset | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Other current assets | 97524 | 75257 | 69250 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total current assets | 284034 | 360938 | 420259 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Net property and equipment | 5688389 | 6215494 | 6990777 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Goodwill | 335897 | 335897 | 335897 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Operating lease right-of-use assets | 73777 | 94733 | 96456 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Other noncurrent assets | Not supplied: no separate line | Not supplied: no separate line | 11571 | USD thousands | Q3 2026 noncurrent derivative asset; no separate prior-year line | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total Assets | 6382097 | 7007062 | 7854960 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Accounts payable | 421814 | 501695 | 547744 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Accrued expenses/costs | 146173 | 153248 | 116348 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Current operating lease liabilities | 35927 | 46937 | 37789 | USD thousands | Reported; outside financial debt | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Current derivative liabilities | 8940 | 27636 | Not supplied: source shows a dash | USD thousands | Dash not treated as zero | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total Current Liabilities | 612854 | 729516 | 701881 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Short-term debt | Not supplied: no current debt line | Not supplied: no current debt line | Not supplied: no current debt line | USD thousands | No current debt line is presented | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Long-term debt | 2952090 | 2809066 | 3356968 | USD thousands | Carrying value, net of discounts and issuance costs | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Deferred income taxes | 345116 | 437098 | 510039 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Noncurrent derivative liabilities | 66757 | Not supplied: source shows a dash | 9694 | USD thousands | Dash retained as missing | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Long-term operating lease liabilities | 37740 | 47692 | 58215 | USD thousands | Reported; outside financial debt | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Reserve for future abandonment costs | 33996 | 20787 | 21829 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total Liabilities | 4048553 | 4044159 | 4658626 | USD thousands | Reported | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Temporary equity | Not supplied: no temporary-equity line | Not supplied: no temporary-equity line | Not supplied: no temporary-equity line | USD thousands | No separate line presented | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total Equity | 2333544 | 2962903 | 3196334 | USD thousands | Includes noncontrolling interests | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Total Debt | 2952090 | 2809066 | 3356968 | USD thousands | Long-term debt carrying value; operating leases and ARO separately presented | 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |

### Net debt data

| Period | Gross debt | Cash | Net debt | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| FY2024 / 2024-12-31 | 2952.090 | 6.799 | 2945.291 | US$m | Carrying value; principal USD 3003.880 million; excludes operating lease liabilities shown separately; 10-K_2025-12-31_crk.htm.jsonl, pages 81 and 99 |
| FY2025 / 2025-12-31 | 2809.066 | 23.930 | 2785.136 | US$m | Carrying value; principal USD 2848.880 million; excludes operating lease liabilities shown separately; 10-K_2025-12-31_crk.htm.jsonl, pages 81 and 99 |
| 2026-09-30 | 3356.968 | 18.633 | 3338.335 | US$m | Carrying value; principal USD 3388.880 million; excludes operating leases shown separately; 10-Q_2026-09-30_crk.htm.jsonl, pages 2 and 19 |

### Covenant tests

| Facility | Maintenance test | Threshold | Issuer-reported status at 2026-09-30 | Reported test value | Headroom | Basis and Source |
|---|---|---:|---|---|---|---|
| Comstock bank credit facility | Leverage ratio | Less than 3.5x; no step-down stated | In compliance | Not supplied: covenant ratio not reported | Not calculable: covenant calculation and EBITDA definition are not supplied | 10-Q_2026-09-30_crk.htm.jsonl, page 19; the house LTM leverage ratio is not the covenant ratio |
| Comstock bank credit facility | Adjusted current ratio | At least 1.0x; no step-down stated | In compliance | Not supplied: covenant ratio not reported | Not calculable: adjusted current asset/liability definitions and actual ratio are not supplied | 10-Q_2026-09-30_crk.htm.jsonl, page 19 |
| PGS bank credit facility | Interest coverage ratio | At least 2.5x; no step-down stated | In compliance | Not supplied: covenant ratio not reported | Not calculable: covenant calculation and actual ratio are not supplied | 10-Q_2026-09-30_crk.htm.jsonl, page 20 |
| PGS bank credit facility | Consolidated net leverage ratio | Less than 4.0x; no step-down stated | In compliance | Not supplied: covenant ratio not reported | Not calculable: covenant calculation and actual ratio are not supplied | 10-Q_2026-09-30_crk.htm.jsonl, page 20 |

### Debt principal to carrying value

| Period | Contractual principal | Reconciling items | Carrying value | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| 2026-09-30 | 3388.880 | -31.912 | 3356.968 | US$m | USD 12.619 million unamortized note discount plus USD 19.293 million bank facility issuance costs, both reduce carrying value; 10-Q_2026-09-30_crk.htm.jsonl, page 19 |

### T4.18 Debt instruments

| Instrument | Type | Carrying Value | Principal | Drawn | Commitment | Security | Ranking | Currency | Reporting Currency Amount | FX Rate | Coupon or Margin | Rate Type | Reference Rate | Spread (bps) | Floor (bps) | Maturity | Annual Amortisation | Source |
|---|---|---:|---:|---:|---:|---|---|---|---:|---|---|---|---|---:|---|---|---|---|
| Comstock Resources Inc — bank credit facility | Revolving credit facility | 780707 | 800000 | 800000 | 1500000 | Substantially all Company and subsidiary assets except PGS | Not stated in supplied filing | USD | 780707 | Not applicable | Adjusted SOFR +2.25% to +3.25%, or alternate base rate +1.25% to +2.25%, depending on borrowing-base utilization; commitment fee 0.375% to 0.5% | Floating | Adjusted SOFR or alternate base rate | 225–325 (SOFR); 125–225 (base) | Not supplied: floor not stated | 2028-11-15; may extend to 2031-11-15 only after SOCAR closes and debt is repaid | Not supplied: schedule not stated | 10-Q_2026-09-30_crk.htm.jsonl, pages 19 and 21 |
| Pinnacle Gas Services LLC — bank credit facility | Revolving credit facility; no borrowing | 0 | 0 | 0 | 150000 | Not supplied: facility security not stated | Not supplied: ranking not stated | USD | 0 | Not applicable | SOFR +2.5% to +3.5%, or alternate base rate +1.5% to +2.5%, depending on leverage; commitment fee 0.375% to 0.5% | Floating | SOFR or alternate base rate | 250–350 (SOFR); 150–250 (base) | Not supplied: floor not stated | 2030-03-26 | Not supplied: schedule not stated | 10-Q_2026-09-30_crk.htm.jsonl, page 20 |
| Comstock Resources Inc — 6.75% Senior Notes due 2029 (one aggregate balance-sheet line; includes the 2024 additional issue) | Senior notes | 1611261 | 1623880 | 1623880 | Not applicable | Not supplied: collateral is not stated in the supplied filing | Senior; relative legal rank not stated | USD | 1611261 | Not applicable | 6.75% | Fixed | Not applicable | Not applicable | Not applicable | 2029-03-01 | Not supplied: schedule not stated | 10-Q_2026-09-30_crk.htm.jsonl, page 19; 10-K_2025-12-31_crk.htm.jsonl, page 100 |
| Comstock Resources Inc — 5.875% Senior Notes due 2030 | Senior notes | 965000 | 965000 | 965000 | Not applicable | Not supplied: collateral is not stated in the supplied filing | Senior; relative legal rank not stated | USD | 965000 | Not applicable | 5.875% | Fixed | Not applicable | Not applicable | Not applicable | 2030 (day not stated) | Not supplied: schedule not stated | 10-Q_2026-09-30_crk.htm.jsonl, page 19; 10-K_2025-12-31_crk.htm.jsonl, pages 76 and 99 |

The 2029 note disclosure aggregates principal in one balance-sheet line. The filing refers to indentures with named guarantor subsidiaries but the supplied filings do not enumerate those guarantors or identify any co-issuer; security for the two note issues is not stated in the debt note. The bank facility is expressly secured. Its November 2026 amendment reset the borrowing base and preserved the committed amount. These omissions prevent a complete legal ranking or collateral analysis.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20; 10-K_2025-12-31_crk.htm.jsonl, pages 76 and 100

### Claims outside financial debt

| Claim | Amount and period | Treatment versus financial debt | Terms and limitation | Source |
|---|---|---|---|---|
| Operating leases | USD 96.004 million at 2026-09-30; FY2025 schedule: USD 102.861 million payments less USD 8.232 million imputed interest, reported lease liability USD 94.629 million | Excluded from financial debt; shown on separate current and long-term lease lines | The latest quarter has no refreshed future-payment schedule; no finance-type lease liability is separately reported | 10-Q_2026-09-30_crk.htm.jsonl, pages 2 and 9; 10-K_2025-12-31_crk.htm.jsonl, page 93 |
| Drilling-rig commitments | USD 12.7 million remaining at 2026-09-30 | Operating commitment; not included in financial debt | Remaining commitment on pad-to-pad rig agreements | 10-Q_2026-09-30_crk.htm.jsonl, page 20 |
| Transportation and gathering commitments | USD 85.4 million in 2026; USD 84.2 million in 2027; USD 79.3 million in 2028; USD 67.6 million in 2029; USD 27.7 million in 2030; USD 58.9 million for 2031–2035 | Contractual operating commitments; not included in financial debt | Latest detailed schedule is at 2025 year-end and was not refreshed in Q3 2026 | 10-K_2025-12-31_crk.htm.jsonl, page 101 |
| Related-party farmout and development agreement | Estimated subject-well costs USD 450 million; partner funds 85% of 18 Western Haynesville wells and 80% of nine Legacy Haynesville wells; Comstock had incurred about USD 180 million by 2026-09-30; partnership receivable USD 51.5 million vs USD 3.6 million at 2025-12-31 | Non-debt third-party funding and a related-party receivable | Partnership receives a 15% return; after costs are recovered it receives net proceeds until that return is achieved, when 50% of subject-well interests revert to Comstock; costs expected to be recovered by end-2027 | 10-Q_2026-09-30_crk.htm.jsonl, page 21 |
| Pension and retiree medical | Not supplied: no separate liability identified in the statements reviewed | No separate debt or liability amount identified | No defined-benefit pension or retiree-medical obligation was separately disclosed in the reviewed filings | 10-K_2025-12-31_crk.htm.jsonl, pages 81 and 93; 10-Q_2026-09-30_crk.htm.jsonl, page 2 |
| Factoring, supply-chain finance and letters of credit | Not supplied: no arrangement or letter-of-credit draw identified in the reviewed filings | No amount added to debt or deducted from reported facility availability | Undisclosed obligations cannot be ruled out from silence in the filings | 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20; 10-K_2025-12-31_crk.htm.jsonl, pages 99–101 |
| Litigation and consent-decree funding | No material litigation amount accrued at 2026-09-30; no consent-decree funding identified | No separate debt amount identified | Normal-course litigation was not expected to materially affect financial position or cash flows; no material amount was accrued | 10-Q_2026-09-30_crk.htm.jsonl, page 20; 10-K_2025-12-31_crk.htm.jsonl, page 101 |

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 / 2024-12-31 | 4.71 | 4.70 | x | Carrying debt and cash at year-end; EBITDA is operating income plus DD&A; 10-K_2025-12-31_crk.htm.jsonl, pages 81–83 and 99 |
| FY2025 / 2025-12-31 | 2.18 | 2.16 | x | Carrying debt and cash at year-end; FY EBITDA includes asset-sale gain; 10-K_2025-12-31_crk.htm.jsonl, pages 81–83 and 99 |
| 2026-09-30 | 2.68 | 2.67 | x | Latest carrying debt and cash over LTM EBITDA through 2026-09-30; 10-Q_2026-09-30_crk.htm.jsonl, pages 2–3 and 19 |

Interim leverage uses LTM operating EBITDA, not nine-month EBITDA; FY2025's measure includes a large asset-sale gain and is not a recurring EBITDA proxy.
Basis: calculation C1; calculation C2; 10-K_2025-12-31_crk.htm.jsonl, page 99; 10-Q_2026-09-30_crk.htm.jsonl, page 19

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
|---|---:|---|---|
| FY2024 / 2024-12-31 | 3.30 | x | Operating EBITDA divided by cash interest paid; 10-K_2025-12-31_crk.htm.jsonl, pages 82 and 98 |
| FY2025 / 2025-12-31 | 6.10 | x | Operating EBITDA divided by cash interest paid; 10-K_2025-12-31_crk.htm.jsonl, pages 82 and 98 |
| 2026-09-30 | 5.96 | x | LTM operating EBITDA and LTM cash interest paid; 10-K_2025-12-31_crk.htm.jsonl, page 98; 10-Q_2026-09-30_crk.htm.jsonl, page 18 |

Cash interest paid is the cash flow disclosure, not income-statement interest expense; LTM uses FY2025 plus 9M2026 less 9M2025.
Basis: calculation C2; calculation C6; 10-K_2025-12-31_crk.htm.jsonl, page 98; 10-Q_2026-09-30_crk.htm.jsonl, page 18

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| 2026-09-30 | 18.633 | 850.000 | US$m | USD 700 million parent facility availability plus USD 150 million PGS availability; PGS availability restricted to midstream; reported aggregate liquidity USD 868.6 million; 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20 and 27–29 |

The filing does not identify any letter-of-credit draw or reduction, so the reported unused-capacity amount is retained as stated and no additional deduction is invented.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 20 and 27–29; calculation C7

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
|---|---:|---|---|
| 2028 | 800.000 | US$m | Parent bank facility maturity amended to 2028-11-15; conditional 2031 extension excluded; 10-Q_2026-09-30_crk.htm.jsonl, pages 19 and 29 |
| 2029 | 1623.880 | US$m | 6.75% Senior Notes principal; March 1 maturity; 10-K_2025-12-31_crk.htm.jsonl, page 100 |
| 2030 | 965.000 | US$m | 5.875% Senior Notes; exact day not stated; 10-K_2025-12-31_crk.htm.jsonl, pages 76 and 99–100 |

The maturity ladder uses principal outstanding at the latest reported balance sheet, with the bank facility's post-quarter amendment reflected in its contractual maturity; undrawn PGS capacity is excluded.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–21; 10-K_2025-12-31_crk.htm.jsonl, page 100

### Chart data: revenue and EBITDA

| Period | Revenue | Adjusted EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| 9M 2025 | 1430.475 | 801.886 | US$m | Revenue is reported; column carries issuer-labelled Adjusted EBITDAX for the matching nine-month period; 10-Q_2026-09-30_crk.htm.jsonl, page 3; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| 9M 2026 | 1324.999 | 762.558 | US$m | Revenue is reported; column carries issuer-labelled Adjusted EBITDAX for the matching nine-month period; 10-Q_2026-09-30_crk.htm.jsonl, page 3; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |

These figures use the issuer's adjusted EBITDAX definition, not the house-calculated operating EBITDA used in leverage.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 3; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, pages 5–7

### Chart data: debt stack

| Facility | Ranking | Secured | Amount | Cumulative leverage | Reporting unit | Basis and limitation |
|---|---|---|---|---|---|---|
| Not supplied: no complete debt rank order established | Not supplied: source does not state legal ranks | Not supplied: bank security is described but note security is not stated | Not supplied: no amount assigned to an unranked stack | Not supplied: no cumulative order can be calculated | US$m | The supplied filings do not establish a legal order for the instruments; see Gaps. |
Debt instruments and contractual principal are detailed separately; this chart is not established because filings do not provide note security or intercreditor ranking to order creditors.
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 19; 10-K_2025-12-31_crk.htm.jsonl, pages 76 and 100

### Chart data: EBITDA bridge

| Step | Amount | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Net income (reported starting measure) | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Interest expense | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Income taxes | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Depreciation, depletion and amortization | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Exploration | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Unrealized gain from derivative financial instruments | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Stock-based compensation | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Loss (gain) on sale of assets | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |
| Adjusted EBITDAX (issuer-adjusted closing measure) | Not supplied: source dash prevents a complete bridge | US$m | Source reports the named step, but the sale-of-assets row is a dash and cannot be treated as zero; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |

The issuer’s adjusted EBITDAX reconciliation cannot be drawn because its sale-of-assets line is a dash and that dash is not treated as zero.
Basis: EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6

### T4.8 Constructed period register

| Metric Name | Derived Period Type | Full-Year Component | Current Stub | Prior-Year Stub | Derived Value | Calculation Status | Source Files | Limitations |
|---|---|---:|---:|---:|---:|---|---|---|
| Revenue | LTM ended 2026-09-30 | USD 2220.289 million FY2025 | USD 1324.999 million 9M2026 | USD 1430.475 million 9M2025 | USD 2114.813 million | Calculated | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 | FY2025 includes sale gain; same 9M duration and reporting entity |
| EBITDA | LTM ended 2026-09-30 | USD 1287.015 million FY2025 | USD 715.026 million 9M2026 | USD 749.492 million 9M2025 | USD 1252.549 million | Calculated | 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 | Calculated as operating income plus DD&A for all components |
| Net cash from operating activities | LTM ended 2026-09-30 | USD 899.607 million FY2025 | USD 622.379 million 9M2026 | USD 675.403 million 9M2025 | USD 846.583 million | Calculated | 10-K_2025-12-31_crk.htm.jsonl, page 83; 10-Q_2026-09-30_crk.htm.jsonl, page 4 | Same consolidated cash-flow definition |
| Cash capital expenditures | LTM ended 2026-09-30 | USD 1344.278 million FY2025 | USD 1291.059 million 9M2026 | USD 978.390 million 9M2025 | USD 1656.947 million | Calculated | 10-K_2025-12-31_crk.htm.jsonl, page 62; 10-Q_2026-09-30_crk.htm.jsonl, page 27 | Company-reported total cash capital expenditure |
| Cash interest paid | LTM ended 2026-09-30 | USD 210.820 million FY2025 | USD 199.068 million 9M2026 | USD 199.841 million 9M2025 | USD 210.047 million | Calculated | 10-K_2025-12-31_crk.htm.jsonl, page 98; 10-Q_2026-09-30_crk.htm.jsonl, page 18 | Cash paid, not accrued interest expense |

### T4.9 Calculation register

| Metric Name | Formula | Numerator Value | Numerator Source | Denominator Value | Denominator Source | Period | Currency | Unit | Calculated Value | Calculation Status | Evidence Quality Tier | Limitations |
|---|---|---:|---|---:|---|---|---|---|---:|---|---|---|
| Total debt / EBITDA | Carrying debt / operating income plus DD&A | 2952.090 | 10-K_2025-12-31_crk.htm.jsonl, page 99 | 626.782 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2024 / 2024-12-31 | USD | US$m | 4.71 | Calculated | Tier 1 | House-calculated EBITDA; includes reported operating items |
| Net debt / EBITDA | Carrying debt less cash / operating income plus DD&A | 2945.291 | Calculation C3 | 626.782 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2024 / 2024-12-31 | USD | US$m | 4.70 | Calculated | Tier 1 | House-calculated EBITDA |
| EBITDA / cash interest | Operating income plus DD&A / cash interest paid | 626.782 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | 190.016 | 10-K_2025-12-31_crk.htm.jsonl, page 98 | FY2024 / 2024-12-31 | USD | US$m | 3.30 | Calculated | Tier 1 | Cash-paid interest denominator |
| Total debt / EBITDA | Carrying debt / operating income plus DD&A | 2809.066 | 10-K_2025-12-31_crk.htm.jsonl, page 99 | 1287.015 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2025 / 2025-12-31 | USD | US$m | 2.18 | Calculated | Tier 1 | House-calculated EBITDA includes asset-sale gain |
| Net debt / EBITDA | Carrying debt less cash / operating income plus DD&A | 2785.136 | Calculation C3 | 1287.015 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2025 / 2025-12-31 | USD | US$m | 2.16 | Calculated | Tier 1 | House-calculated EBITDA includes asset-sale gain |
| EBITDA / cash interest | Operating income plus DD&A / cash interest paid | 1287.015 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | 210.820 | 10-K_2025-12-31_crk.htm.jsonl, page 98 | FY2025 / 2025-12-31 | USD | US$m | 6.10 | Calculated | Tier 1 | Cash-paid interest denominator |
| Total debt / EBITDA | Carrying debt / LTM EBITDA | 3356.968 | 10-Q_2026-09-30_crk.htm.jsonl, page 19 | 1252.549 | Calculation C2 | 2026-09-30 | USD | US$m | 2.68 | Calculated | Tier 2b | LTM house-calculated EBITDA; latest balance-sheet debt |
| Net debt / EBITDA | Carrying debt less cash / LTM EBITDA | 3338.335 | Calculation C3 | 1252.549 | Calculation C2 | 2026-09-30 | USD | US$m | 2.67 | Calculated | Tier 2b | LTM house-calculated EBITDA |
| EBITDA / cash interest | LTM EBITDA / LTM cash interest paid | 1252.549 | Calculation C2 | 210.047 | Calculation C2 | 2026-09-30 | USD | US$m | 5.96 | Calculated | Tier 2b | Cash paid, not accrued interest expense |
| Senior secured debt / EBITDA | Secured bank facility carrying amount / operating EBITDA | 415.000 | 10-K_2025-12-31_crk.htm.jsonl, page 100 | 626.782 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2024 / 2024-12-31 | USD | US$m | 0.66 | Calculated | Tier 1 | Includes only facility expressly stated to be secured |
| Senior secured debt / EBITDA | Secured bank facility carrying amount / operating EBITDA | 260.000 | 10-K_2025-12-31_crk.htm.jsonl, page 100 | 1287.015 | 10-K_2025-12-31_crk.htm.jsonl, page 82 | FY2025 / 2025-12-31 | USD | US$m | 0.20 | Calculated | Tier 1 | Includes only facility expressly stated to be secured |
| Senior secured debt / EBITDA | Secured bank facility carrying amount / LTM EBITDA | 800.000 | 10-Q_2026-09-30_crk.htm.jsonl, page 19 | 1252.549 | Calculation C2 | 2026-09-30 | USD | US$m | 0.64 | Calculated | Tier 2b | Does not infer note security |
| EBITDA less cash capex / cash interest | (EBITDA minus cash capital expenditures) / cash interest paid | -458.708 | Calculation C9 | 190.016 | 10-K_2025-12-31_crk.htm.jsonl, page 98 | FY2024 / 2024-12-31 | USD | US$m | -2.41 | Calculated | Tier 1 | Cash capex is the issuer's total cash capex |
| EBITDA less cash capex / cash interest | (EBITDA minus cash capital expenditures) / cash interest paid | -57.263 | Calculation C9 | 210.820 | 10-K_2025-12-31_crk.htm.jsonl, page 98 | FY2025 / 2025-12-31 | USD | US$m | -0.27 | Calculated | Tier 1 | Cash capex is the issuer's total cash capex |
| EBITDA less cash capex / cash interest | (LTM EBITDA minus LTM cash capex) / LTM cash interest | -404.398 | Calculation C9 | 210.047 | Calculation C2 | 2026-09-30 | USD | US$m | -1.92 | Calculated | Tier 2b | Cash capex is the issuer's total cash capex |
| FFO / debt | FFO / carrying debt | Not supplied: issuer does not report FFO | 10-K_2025-12-31_crk.htm.jsonl, pages 82–83 | 2809.066 | 10-K_2025-12-31_crk.htm.jsonl, page 99 | FY2025 / 2025-12-31 | USD | US$m | Not calculable: FFO is not stated and no issuer definition is supplied | Not Calculable | Tier 1 | CFO and issuer operating cash flow before working capital are not substituted for FFO |

### T4.10 KPI dashboard

| KPI Category | Metric Name | Q3 2025 | Q3 2026 | 9M 2025 | 9M 2026 | Trend Direction | Analyst Note |
|---|---|---:|---:|---:|---:|---|---|
| Production | Total production (MMcfe) | 111837 | 122432 | 339166 | 333453 | Quarter higher; nine-month lower | Q3 release states Q3 growth; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, pages 1–2 and 5 |
| Production | Natural gas production (MMcf) | 111770 | 122392 | 338963 | 333316 | Quarter higher; nine-month lower | Reported; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 5 |
| Production | Oil production (Mbbls) | 11 | 7 | 34 | 23 | Lower | Reported; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 5 |
| Realized price | Average price including hedging (USD/Mcfe) | 3.00 | 2.94 | 3.20 | 3.09 | Lower year over year | Issuer-reported weighted realized price including hedge settlements; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 5 |
| Margin | Hedged operating margin (%) | 74 | 73 | 75 | 73 | Lower year over year | Issuer-defined operating margin; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 5 |
| Non-GAAP | Adjusted EBITDAX (USD thousands) | 249115 | 266482 | 801886 | 762558 | Q3 higher; nine-month lower | Issuer reconciliation includes stated adjustments; not house-calculated EBITDA; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 |

### T4.11 Definition conflict register

| Metric Name | Canonical Definition | Issuer-Reported Definition | Source of Conflict | Periods Affected | Materiality | Modules Affected | Resolution / Recommendation |
|---|---|---|---|---|---|---|---|
| EBITDA | Operating income plus DD&A for the house-calculated measure | Comstock reports Adjusted EBITDAX, adding exploration and stock compensation and excluding unrealized derivative gains and specified sale items | The issuer-adjusted metric differs from the house-calculated operating EBITDA; 10-Q_2026-09-30_crk.htm.jsonl, page 3; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 6 | Q3 and 9M 2026 and 2025 comparison | Material to leverage and trend | Financial foundation and later credit analysis | Keep both measures labelled; do not extend issuer EBITDAX to LTM without FY2025 reconciliation |
| Interest coverage | EBITDA divided by cash interest paid | Income-statement interest expense is accrued expense | Cash paid differs from expense, particularly across nine-month periods; 10-K_2025-12-31_crk.htm.jsonl, pages 82 and 98; 10-Q_2026-09-30_crk.htm.jsonl, pages 3 and 18 | FY2024, FY2025, 9M and LTM | Material to coverage | Financial foundation and later credit analysis | Use cash interest paid for cash coverage; show expense separately |
| Total debt | Balance-sheet carrying value, net of issue costs and discounts | Debt note also states contractual principal | Latest principal exceeds carrying value by discount and bank issuance costs; 10-Q_2026-09-30_crk.htm.jsonl, page 19 | All balance dates | Material to leverage and recovery | Financial foundation and later credit analysis | Use carrying value for debt leverage; preserve principal for maturity and recovery analysis |
| Free cash flow | Net cash from operations less issuer-reported total cash capital expenditures | No single FCF measure is reported in the financial statements | Issuer release reports operating cash flow before working-capital changes but says it is not actual liquidity or cash generation; EX99.1_2026-09-30_crk_crk-ex99-1-htm.htm.jsonl, page 7 | FY2024, FY2025, 9M and LTM | Material to liquidity | Financial foundation and later credit analysis | Label calculated cash FCF and keep it separate from issuer operating cash flow before working capital |
| FY2025 gain on sale of assets | Consolidated statements report USD 291.938 million; disposition note reports USD 292.3 million pre-tax gain on Shelby Trough | Reported revenue line vs. rounded disposition disclosure | 10-K_2025-12-31_crk.htm.jsonl, pages 82 and 99 | FY2025 | Difference not reconciled; one-off event is clear | Financial foundation and later credit analysis | Retain the statement amount for EBITDA and flag the difference; no adjustment inferred |

### T4.13 Readiness

| Requested Use | Readiness Status | Gaps or Limitations | Recommended Actions |
|---|---|---|---|
| Consolidated issuer financial foundation through 2026-09-30 | Ready with Limitations | Interim statements unaudited; no current pro forma debt after SOCAR agreement | Use reported balances and keep the announced sale outside period figures |
| Leverage, cash interest coverage and cash FCF | Ready with Limitations | House EBITDA includes reported one-off sale gain in FY2025/LTM; no full-year adjusted EBITDAX source | Present both issuer 9M EBITDAX and house EBITDA with definitions |
| Debt maturity and secured priority | Ready with Limitations | Complete note security and legal rank are not stated in the supplied filing text | Keep unknown rank/security explicit until indentures are available |
| Liquidity | Ready with Limitations | PGS availability restricted to midstream; no LC draw detail is stated | Retain issuer's reported unused-capacity figure and disclose restriction |

### Post-balance-sheet adjustments

| Event | Date | Amount | Pro forma net debt | Pro forma net leverage | Reporting unit | Basis and limitation |
|---|---|---|---|---|---|---|
| SOCAR asset sale agreement; not closed by cutoff | 2026-11-04 | 1650.000 | Not supplied: proceeds and repayment split had not been received or quantified | Not supplied: transaction is pending and pro forma EBITDA/debt are not stated | US$m; x | Agreed cash price is USD 1.65 billion subject to customary purchase-price adjustments; management expects a USD 150–250 million sale gain; no completed debt reduction at cutoff; 10-Q_2026-09-30_crk.htm.jsonl, pages 21 and 30 |

### Events: Sources

| Event date | Date precision | Published | Event | Status | Source | Credit relevance |
|---|---|---|---|---|---|---|
| 2025-09-02 | day | Not supplied: publication date not stated in the annual filing | Cotton Valley asset sale for USD 15.2 million net proceeds; USD 1.5 million pre-tax loss | Historical — asset sale completed | 10-K_2025-12-31_crk.htm.jsonl, page 99 | Disposition and reported gain/loss affect asset base |
| 2025-12-02 | day | Not supplied: publication date not stated in the annual filing | Shelby Trough asset sale for USD 417.2 million net proceeds; USD 292.3 million pre-tax gain | Historical — assets sold | 10-K_2025-12-31_crk.htm.jsonl, page 99 | One-off gain inflates FY2025 operating revenue and EBITDA |
| 2026-06-15 | day | 2026-11-05 | PGS redeemed Cactus' interest for USD 445 million and issued 27% ownership to Starville for USD 600 million | Historical — redeemed and issued | 10-Q_2026-09-30_crk.htm.jsonl, page 5 | Replaced a prior noncontrolling interest and created new NCI; not parent debt proceeds |
| 2026-08-31 | day | 2026-11-05 | Related-party farmout and development agreement for 18 Western and nine Legacy Haynesville wells | Historical — agreement entered | 10-Q_2026-09-30_crk.htm.jsonl, page 21 | Partnership funds most drilling/completion costs in return for a 15% return and subsequent interests |
| 2026-11-04 | day | 2026-11-05 | SOCAR purchase and sale agreement for specified upstream and PGS interests at USD 1.65 billion subject to adjustments | Scheduled — expected to close by end of 2026 subject to customary conditions | 10-Q_2026-09-30_crk.htm.jsonl, pages 21 and 30 | Potential cash for debt reduction; not reflected in reported debt |
| 2026-11-04 | day | 2026-11-05 | Comstock bank facility amended to mature 2028-11-15; USD 1.5 billion commitment and initial USD 1.6 billion borrowing base, with further extension to 2031-11-15 conditional on SOCAR close and debt repayment | Scheduled — later extension depends on transaction closing and repayment | 10-Q_2026-09-30_crk.htm.jsonl, pages 21 and 29 | Extends the near-term bank maturity but leaves the longer extension conditional; the amendment did not report new debt or a repayment |

### Confidence inputs

| Input | Value |
|---|---|
| Directly Sourced | 52 |
| Calculated | 31 |
| Assumption-Based | 0 |
| Analyst Inference | 4 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 4 |
| Insufficient Information | 7 |
| Fields present | 24 |
| Fields total | 24 |
| Source gate | partial |
| CRITICAL | 0 |
| MATERIAL | 2 |
| MINOR | 0 |

## Calculations

| ID | Calculation | Inputs and source locators | Result |
|---|---|---|---|
| C1 | House EBITDA = operating income + DD&A; calculate each period from reported components | FY2024: -168.615 + 795.397; FY2025: 645.852 + 641.163; Q3 2025: 50.213 + 157.395; Q3 2026: 22.935 + 185.655; 9M2025: 265.827 + 483.665; 9M2026: 220.407 + 494.619; all USD millions; 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3 | 626.782; 1287.015; 207.608; 208.590; 749.492; 715.026 USD millions |
| C2 | LTM ended 2026-09-30 = FY2025 + 9M2026 - 9M2025 | Revenue: 2220.289 + 1324.999 - 1430.475; EBITDA: 1287.015 + 715.026 - 749.492; CFO: 899.607 + 622.379 - 675.403; cash capex: 1344.278 + 1291.059 - 978.390; cash interest: 210.820 + 199.068 - 199.841; all USD millions; 10-K_2025-12-31_crk.htm.jsonl, pages 82–83 and 98; 10-Q_2026-09-30_crk.htm.jsonl, pages 3–4 and 18; 10-K_2025-12-31_crk.htm.jsonl, page 62; 10-Q_2026-09-30_crk.htm.jsonl, page 27 | Revenue 2114.813; EBITDA 1252.549; CFO 846.583; cash capex 1656.947; cash interest 210.047 USD millions |
| C3 | Net debt = carrying debt - cash | FY2024: 2952.090 - 6.799; FY2025: 2809.066 - 23.930; 2026-09-30: 3356.968 - 18.633; USD millions; debt from 10-K_2025-12-31_crk.htm.jsonl, page 99 and 10-Q_2026-09-30_crk.htm.jsonl, page 19; cash from 10-K_2025-12-31_crk.htm.jsonl, page 81 and 10-Q_2026-09-30_crk.htm.jsonl, page 2 | 2945.291; 2785.136; 3338.335 USD millions |
| C4 | Cash FCF = net cash from operating activities - total cash capital expenditures | FY2024: 620.337 - 1085.490; FY2025: 899.607 - 1344.278; 9M2025: 675.403 - 978.390; 9M2026: 622.379 - 1291.059; LTM: 846.583 - 1656.947; USD millions; CFO from 10-K_2025-12-31_crk.htm.jsonl, page 83 and 10-Q_2026-09-30_crk.htm.jsonl, page 4; cash capex from 10-K_2025-12-31_crk.htm.jsonl, page 62 and 10-Q_2026-09-30_crk.htm.jsonl, page 27 | FY2024 -465.153; FY2025 -444.671; 9M2025 -302.987; 9M2026 -668.680; LTM -810.364 USD millions |
| C5 | Debt principal to carrying value | Principal: 1623.880 + 965.000 + 800.000; reconciling items: -12.619 note discount -19.293 facility issuance costs; USD millions; 10-Q_2026-09-30_crk.htm.jsonl, page 19 | Principal 3388.880 - 31.912 = carrying value 3356.968 USD millions |
| C6 | Ratios use carrying debt, net debt or EBITDA divided by cash interest paid | FY2024 debt 2952.090 (10-K_2025-12-31_crk.htm.jsonl, page 99), cash 6.799 (page 81), EBITDA 626.782 (page 82), cash interest 190.016 (page 98); FY2025 debt 2809.066 (page 99), cash 23.930 (page 81), EBITDA 1287.015 (page 82), cash interest 210.820 (page 98); LTM debt 3356.968 (10-Q_2026-09-30_crk.htm.jsonl, page 19), cash 18.633 (page 2), EBITDA 1252.549 and cash interest 210.047 (calculation C2) | FY2024 4.71x, 4.70x, 3.30x; FY2025 2.18x, 2.16x, 6.10x; LTM 2.68x, 2.67x, 5.96x |
| C7 | Reported liquidity = cash + unused commitments by facility | Comstock commitment 1500.000 - drawn 800.000 = 700.000 unused (10-Q_2026-09-30_crk.htm.jsonl, page 19); PGS commitment 150.000 - drawn 0 = 150.000 unused (page 20); cash and equivalents 18.633 (page 2); USD millions; reported aggregate liquidity in 10-Q_2026-09-30_crk.htm.jsonl, page 27 | USD 850.000 million unused; USD 868.633 million gross liquidity; PGS portion restricted |
| C8 | Debt maturity principal aggregation | 2028 bank 800.000 + 2029 notes 1623.880 + 2030 notes 965.000; USD millions; 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20; 10-K_2025-12-31_crk.htm.jsonl, page 100 | USD 3388.880 million contractual principal |
| C9 | EBITDA less issuer-reported cash capital expenditures; compare with cash interest paid | FY2024: 626.782 - 1085.490; FY2025: 1287.015 - 1344.278; LTM: 1252.549 - 1656.947; cash capex from 10-K_2025-12-31_crk.htm.jsonl, page 62 and 10-Q_2026-09-30_crk.htm.jsonl, page 27; EBITDA from calculation C1/C2; interest from 10-K_2025-12-31_crk.htm.jsonl, page 98 and calculation C2 | FY2024 numerator -458.708, coverage -2.41x; FY2025 numerator -57.263, coverage -0.27x; LTM numerator -404.398, coverage -1.92x |
| C10 | Latest operating lease liabilities = current lease liabilities + noncurrent lease liabilities | USD 37.789 million current + USD 58.215 million noncurrent at 2026-09-30; 10-Q_2026-09-30_crk.htm.jsonl, page 2 | USD 96.004 million at 2026-09-30; leases are separately presented from financial debt |
| C11 | Trade and affiliate receivables excluding separately listed derivative instruments | FY2024: 145398 + 23956 + 5492; FY2025: 203549 + 35400 + 3596; Q3 2026: 139399 + 32918 + 51483; USD thousands; 10-K_2025-12-31_crk.htm.jsonl, page 81; 10-Q_2026-09-30_crk.htm.jsonl, page 2 | FY2024 174846; FY2025 242545; Q3 2026 223800 USD thousands |

LTM leverage uses LTM operating EBITDA. FCF includes working capital through net operating cash flow and deducts issuer-reported total cash capital expenditures. The LTM metric is constructed from same-perimeter periods; no pro forma sale adjustment is calculated.

## Gaps

- Comstock does not present separate cost of goods sold, gross profit or interest income lines. Gross margin and interest-income analysis are therefore not calculable from the supplied consolidated statements. This limits margin comparison with businesses that report a gross-profit subtotal.  
Basis: 10-K_2025-12-31_crk.htm.jsonl, page 82; 10-Q_2026-09-30_crk.htm.jsonl, page 3
- Comstock does not state an FFO definition or a complete covenant EBITDA calculation in the supplied filings. FFO/debt and covenant headroom cannot be calculated from the house EBITDA measure; the company only reports covenant compliance.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20 and 29
- Complete executed note and credit-agreement terms are not included in the supplied sources. The current filings identify a secured bank facility but do not state note collateral, complete legal ranking, the specific guarantor names or scheduled annual amortisation. The missing terms limit priority and recovery analysis.  
Basis: 10-K_2025-12-31_crk.htm.jsonl, pages 76 and 100; 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20
- The filing discloses USD 12.7 million of remaining drilling-rig commitments at 2026-09-30. The FY2025 annual report separately lists transportation and gathering commitments through 2035, including USD 85.4 million for 2026 and USD 84.2 million for 2027; the quarterly filing does not refresh that full schedule, so those annual amounts are not treated as a current forecast.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 20; 10-K_2025-12-31_crk.htm.jsonl, page 101
- Operating lease liabilities are outside financial debt, and no finance-type lease liability is separately reported. The latest quarter does not refresh the annual payment schedule. No separate pension or retiree-medical liability is identified in the statements reviewed.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 9; 10-K_2025-12-31_crk.htm.jsonl, pages 81 and 93
- The related-party farmout is expected to fund approximately USD 450 million of drilling/completion costs for the subject wells, after which the partnership has a 15% return and shares in well interests and proceeds under the contract. Comstock had incurred about USD 180 million by 2026-09-30 and expects to recover its costs by end-2027. The arrangement reduces near-term company-funded capex but redirects future cash and working interests; the full return and reversion waterfall is not quantified here.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, page 21
- The SOCAR sale remains pending. The USD 1.65 billion stated price is subject to adjustments, the planned bank repayment and note retirement amounts are not specified, and no pro forma leverage is stated. Reported debt and liquidity remain the 2026-09-30 values.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 21 and 30
- The supplied statements do not identify factoring, supply-chain finance or letter-of-credit draws. Availability beyond Comstock's stated unused commitments cannot be adjusted for undisclosed LC obligations. Normal-course litigation is described as not expected to have a material effect, with no material amounts accrued.  
Basis: 10-Q_2026-09-30_crk.htm.jsonl, pages 19–20

## Next module

The orchestrator selects the next module.

