---
issuer_id: dlx-27996
module_id: CP-1
analysis_date: 2026-11-18
run_id: dlx-27996-2026-11-18-credit_snapshot-host
---

## Request

Assess Deluxe Corp as of 2026-11-18 under the credit_snapshot pathway. Establish a normalized consolidated financial foundation using FY2024, FY2025, Q3 2025, Q3 2026, 9M 2025 and 9M 2026 where the statements provide those periods, and construct LTM data to September 30, 2026. Include the latest reported debt, liquidity, covenant and subsequent-event information.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 10-K_2024-12-31_dlx.htm.jsonl | Annual report on Form 10-K for the year ended December 31, 2024 | not stated | 67b837bad3689eb57ce7992f50b42dfca6328fb57096d791edfb119f64350c9b | Historical consolidated statements, liquidity, debt, leases and contract commitments |
| 10-K_2025-12-31_dlx.htm.jsonl | Annual report on Form 10-K for the year ended December 31, 2025 | not stated | ef88882c6698cca61424cd4266ad2d1415faefa761efc11835cff37bacdc604f | Audited statements, annual cash flows, debt and interest, segments, commitments and pension disclosures |
| 10-Q_2026-03-31_dlx.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended March 31, 2026 | not stated | c6188e96c3e25ebda32357958a20d50628042058c0369e7bab137dca4608900b | Interim-period cross-check and disclosed 2026 divestiture and debt activity |
| 10-Q_2026-06-30_dlx.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended June 30, 2026 | not stated | 6a449761454530caf50ba1d8051436ea4a62cc2fe61b463317de655ff7e9cacd | Interim-period and financing-event cross-check |
| 10-Q_2026-09-30_dlx.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended September 30, 2026 | not stated | 1a71979ca733787a8d7d440764f230a4c6087a6a46bd4d2a31266efdae557532 | Latest statements, maturity ladder, credit facilities, covenants, commitments and leases |
| EX99.1_2026-03-31_dlx_exhibit991050620268-k-htm.htm.jsonl | Exhibit 99.1, first-quarter 2026 earnings release | 2026-05-06 | 3217064ddd0f8be66f70bf58b3cfa43fb7f3bab05ab19f8cba13be318ddb127f | Dated operating, cash flow and outlook cross-check |
| EX99.1_2026-06-30_dlx_exhibit991080520268-k-htm.htm.jsonl | Exhibit 99.1, second-quarter 2026 earnings release | 2026-08-05 | a7e482691fc66cd72f252a397273479f8d1cf0baae2887ed394bca26096905f8 | Dated operating and outlook cross-check |
| EX99.1_2026-06-30_dlx_tm2621737d1-ex99-1-htm.htm.jsonl | Exhibit 99.1, Celero acquisition closing announcement | 2026-07-31 | 96c47ce241c8b97cc47962d6a8e9dc36a99d834425d3b9e5d0db820b9c76c8e7 | Dated acquisition closing and issuer rationale |
| EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | Exhibit 99.1, third-quarter 2026 earnings release | 2026-11-04 | e21b511b9fd3407ed636f1231d5c628d21b48ef3b99e88c5de6567c6c15ea9e2 | Q3 results, EBITDA bridge, segments, guidance and declared dividend |

| Handoff | Module | sha256 |
|---|---|---|
| CP-0 | Source readiness | 4a718de4c955c9cbf43e7af15baefb05eb671f90a3313557e26784696c65ffc6 |

## Findings

### Bottom line

Deluxe’s September 2026 credit profile reflects substantially higher debt following the Celero acquisition, while reported cash generation and adjusted EBITDA remain positive; creditors therefore face greater leverage and a concentrated 2029 refinancing wall despite meaningful committed revolver availability. Covenant compliance is stated, but actual covenant ratios and headroom are not disclosed.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–21; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4–7; calculation ND26; calculation LTM-EBITDA; calculation LTM-AEBITDA

### Key findings

The July acquisition and related amended financing took gross principal debt to USD 2025.5 million and carrying debt to USD 2004.1 million at September 30, 2026. Net debt was USD 1929.2 million after deducting only unrestricted cash; this basis excludes separately presented finance and operating lease liabilities and does not deduct restricted settlement cash. The acquisition therefore increased leverage even as issuer-adjusted LTM EBITDA reached USD 459.8 million.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 12, 19–20; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 5; calculation ND26; calculation LTM-AEBITDA

At September 30, 2026, cash of USD 74.9 million and undrawn committed revolving capacity of USD 189.8 million provide a USD 264.7 million liquidity pool before future operating needs. The facility availability is already net of USD 9.7 million of letters of credit. The debt ladder is weighted to 2029 and 2031, and the source does not provide the covenant-defined EBITDA needed to calculate headroom against the maintenance tests.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–21; calculation LIQ26; calculation MAT26

Nine-month operating cash flow and free cash flow were USD 215.9 million and USD 134.9 million, respectively, but they include working-capital movements and precede the USD 642.9 million acquisition outflow. Settlement processing obligations declined by USD 256.9 million in financing cash flow; this is a non-debt operating float movement and should not be read as debt repayment. Restricted cash was USD 19.3 million at September 30, 2026 and is unavailable for net-debt offset under the issuer’s stated definition.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 4–5, 10; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 5, 9; calculation FCF9M26; calculation WC9M26

### Contrary evidence and what would change the view

The company reported compliance with all debt covenants at September 30, 2026 and says cash generated from operations and revolver availability are expected to meet operational needs, contractual obligations and debt service over the next twelve months. That evidence moderates near-term liquidity concerns, but it does not quantify covenant cushion; disclosed thresholds step down over time, and the acquired debt remains exposed to refinancing well before the 2031 facility maturity. Actual agreement-defined ratios, permitted add-backs and lender calculations would be needed to show whether the reported compliance provides robust headroom.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 20–21, 33, 46; 10-K_2025-12-31_dlx.htm.jsonl, pages 107–108

The strongest operating counterweight is growth in the payments and data businesses and higher consolidated adjusted EBITDA, including Celero from its July closing date. The contrary pressure is continued Print weakness, acquisition-related amortization and financing costs, and non-recurring adjustment categories that may recur. Evidence that post-acquisition cash conversion and debt reduction persist after transaction costs and settlement-float movements would strengthen the operating case; lower growth, ongoing exceptional costs or weaker working capital would make the leverage increase more consequential.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 12–13, 42–43; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 2, 5–7; 10-K_2025-12-31_dlx.htm.jsonl, pages 45, 53–55

### Limitations

The issuer’s stated unadjusted EBITDA in the Q3 earnings release is derived from net income, non-controlling interest, depreciation and amortization, interest expense and income tax provision. I apply that issuer bridge consistently to annual periods; EBIT plus depreciation and amortization is a different operating measure and would produce lower leverage denominators. Adjusted EBITDA is a separate issuer non-GAAP measure with specified adjustments, not cash flow and not the covenant-defined figure.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, page 51; 10-Q_2026-09-30_dlx.htm.jsonl, page 39; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7

The acquisition purchase-price allocation remains preliminary. The public sources summarize, but do not include the complete operative amended credit agreement text, so clause-level definitions, exact floating spreads and floors, collateral exceptions and relative lien priority cannot be independently established here.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 12–13, 19–23, 51

The gross debt figure follows the balance-sheet debt lines and includes the receivables securitization financing; it excludes finance and operating leases shown separately. Restricted cash remains in settlement-processing assets or other assets and is not netted against debt. The cash-flow statement includes restricted cash in its cash roll-forward, while the net-debt definition uses cash and cash equivalents only.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 10, 18–20; 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 90, 110

### Events: Sources

| Event date | Date precision | Published | Event | Status | Source | Credit relevance |
|---|---|---|---|---|---|---|
| 2026-07-31 | day | 2026-07-31 | Celero acquisition closed; credit agreement amended and restated | Completed; transaction and financing are reflected in September 30 balances | 10-Q_2026-09-30_dlx.htm.jsonl, pages 12, 19; EX99.1_2026-06-30_dlx_tm2621737d1-ex99-1-htm.htm.jsonl, page 1 | Cash consideration was approximately USD 625.0 million plus seller expenses and adjustments; accounting consideration transferred was USD 664.6 million; additional term loan and revolver borrowing funded the transaction |
| 2026-07-31 | day | not stated | Amortizing interest-rate swaps executed | In effect; USD 600.0 million notional, maturing July 2030; weighted-average fixed rate 4.13% at September 30 | 10-Q_2026-09-30_dlx.htm.jsonl, pages 15, 19; 10-Q_2026-09-30_dlx.htm.jsonl, page 49 | Hedges a portion of floating-rate debt; it is a derivative, not principal debt |
| 2026-03 | month | not stated | Safeguard small business distributor channel sale closed | Completed; proceeds include an initial payment and equal annual installments over the following three years | 10-Q_2026-03-31_dlx.htm.jsonl, page 10; 10-Q_2026-09-30_dlx.htm.jsonl, page 45 | Net proceeds of USD 22.8 million; the sale and its earnings impact are reflected in 2026 cash flows and reported results |
| 2026-11-04 | day | 2026-11-04 | Q3 results and updated 2026 outlook released | Published before the analysis cutoff | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 1–2 | Outlook is forward-looking and contingent on stated business and macroeconomic factors |
| 2026-12-01 | day | 2026-11-04 | Quarterly dividend payable, record date November 17, 2026 | Announced after September 30; payment scheduled after the analysis cutoff | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 2 | The release states USD 0.30 per share but not the aggregate payment; the post-period net-debt effect is not established |

### Non-debt obligations

| Claim | FY2024 | FY2025 | At September 30, 2026 | Reporting unit | Basis and limitation | Source |
|---|---:|---:|---:|---|---|---|
| Finance lease liabilities, total | 27.4 | 28.2 | Not supplied: current portion is not separately stated; non-current line is 75.3 | US$m | Outside the reported long-term debt line; Q3 amount is at least the stated non-current balance | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 23 |
| Operating lease liabilities, total (memo) | 61.4 | 51.2 | 53.0 | US$m | Q3 calculated as 10.2 current accrued lease liability plus 42.8 non-current lease liability; outside reported debt | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 11 |
| New 16-year facility finance lease, liability at commencement | Not applicable | Not applicable | 49.6 | US$m | Began June 2026; undiscounted payments total 88.3, including 22.5 due through 2031; liability is part of lease balances, not debt | 10-Q_2026-09-30_dlx.htm.jsonl, pages 23–24, 45 |
| Retiree health plan asset | 107.5 | 129.5 | 136.5 | US$m | Plan asset, not operating cash; current benefit obligation is not updated in the Q3 filing | 10-K_2025-12-31_dlx.htm.jsonl, page 102; 10-Q_2026-09-30_dlx.htm.jsonl, pages 9, 18 |
| Pension plan obligation | 2.1 | 2.0 | Not supplied: current obligation not separately reported | US$m | FY amounts from funded-status schedule; separate from financial debt | 10-K_2025-12-31_dlx.htm.jsonl, page 102; 10-Q_2026-09-30_dlx.htm.jsonl, page 18 |
| Multi-year IT, outsourced operations, data procurement and payment acceptance commitments | 225.0 at December 31, 2024 | 210.0 at December 31, 2025 | Not supplied: updated remaining amount not stated | US$m | FY2024 report states approximately 70.0 due in 2025 and 60.0 in 2026; FY2025 report states approximately 70.0 due in 2026 and 60.0 in 2027, with balances through 2029/2030 respectively | 10-K_2024-12-31_dlx.htm.jsonl, page 63; 10-K_2025-12-31_dlx.htm.jsonl, page 57; 10-Q_2026-09-30_dlx.htm.jsonl, pages 23–24 |
| Outstanding letters of credit | 7.698 at December 31, 2024 | 7.4 at December 31, 2025 | 9.7 | US$m | Reduces available revolving commitment; supports self-insurance and environmental claims and is not debt drawn | 10-K_2024-12-31_dlx.htm.jsonl, page 116; 10-K_2025-12-31_dlx.htm.jsonl, page 108; 10-Q_2026-09-30_dlx.htm.jsonl, page 21 |
| Self-insurance liabilities | 8.2 at December 31, 2024 | 9.6 at December 31, 2025 | 5.6 | US$m | Workers’ compensation, active employee medical/dental and long-term disability claims; included in accrued and other non-current liabilities, not debt | 10-K_2024-12-31_dlx.htm.jsonl, page 120; 10-K_2025-12-31_dlx.htm.jsonl, page 112; 10-Q_2026-09-30_dlx.htm.jsonl, page 23 |
| Recorded litigation liabilities | Not supplied: not material as stated by issuer | Not supplied: not material as stated by issuer | Not supplied: not material as stated by issuer | US$m | Issuer states recorded legal liabilities were not material; individual reserve amount is not given | 10-Q_2026-09-30_dlx.htm.jsonl, pages 23, 51 |

Operating and finance lease liabilities sit outside the issuer’s total debt lines, while receivables financing is included in debt. The recent 16-year facility lease adds a long-dated fixed payment obligation, and the benefit-plan asset is not available to service debt. Outstanding letters of credit are already deducted from revolver availability, and litigation liabilities are described as not material but are not individually quantified.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, pages 102, 110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 9, 23–24, 45

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 / 2024-12-31 | 4.12 | 4.02 | x | Carrying debt and issuer-definition reported EBITDA; calculations LEV24-TD and LEV24-ND |
| FY2025 / 2025-12-31 | 3.77 | 3.68 | x | Carrying debt and issuer-definition reported EBITDA; calculations LEV25-TD and LEV25-ND |
| 2026-09-30 | 5.11 | 4.92 | x | Latest carrying debt and net debt over LTM reported EBITDA; current acquisition period is included from close in reported LTM results |

The FY2024 and FY2025 denominators are issuer-definition EBITDA reconstructed from the issuer’s bridge components; the LTM calculation combines comparable reported periods.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7; calculation FY24-EBITDA; calculation FY25-EBITDA; calculation LTM-EBITDA

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
|---|---:|---|---|
| FY2024 / 2024-12-31 | 3.10 | x | Reported EBITDA / cash interest paid, not accrued interest expense |
| FY2025 / 2025-12-31 | 3.40 | x | Reported EBITDA / cash interest paid, not covenant-defined interest expense |
| 2026-09-30 | 3.45 | x | LTM reported EBITDA / LTM cash interest paid |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 / 2024-12-31 | 34.4 | 374.302 | US$m | USD 400.000 million commitment less USD 18.000 million drawn and USD 7.698 million letters of credit |
| FY2025 / 2025-12-31 | 36.9 | 379.6 | US$m | USD 400.0 million commitment less USD 13.0 million drawn and USD 7.4 million letters of credit |
| 2026-09-30 | 74.9 | 189.8 | US$m | USD 400.0 million commitment less USD 200.5 million drawn and USD 9.7 million letters of credit |

The current and FY2025 facility amounts are already net of outstanding letters of credit; FY2024 availability is calculated from the reported commitment, draw and letter-of-credit amounts. Neither the USD 400.0 million revolving credit facility nor receivables financing expires within the next twelve months; their stated maturities are July 31, 2031 and December 2028, respectively.
Basis: 10-K_2024-12-31_dlx.htm.jsonl, page 116; 10-K_2025-12-31_dlx.htm.jsonl, page 108; 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–22

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Remainder 2026 | 15.0 | US$m | Contractual principal maturity ladder as of September 30, 2026 |
| 2027 | 60.0 | US$m | Contractual principal maturity ladder as of September 30, 2026 |
| 2028 | 160.0 | US$m | Contractual principal maturity ladder as of September 30, 2026 |
| 2029 | 985.0 | US$m | Includes both note maturities and other contractual principal |
| 2030 | 65.0 | US$m | Contractual principal maturity ladder as of September 30, 2026 |
| 2031 | 740.5 | US$m | Contractual principal maturity ladder as of September 30, 2026 |

The 2029 bucket is concentrated in the notes, including a secured-note acceleration provision if the 2021 unsecured notes remain outstanding at the specified date.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19, 21, 49

### Financials and credit metrics

| Metric | FY2024 | FY2025 | LTM to 2026-09-30 | Unit | Basis |
|---|---:|---:|---|---|---|
| Revenue | 2121.8 | 2133.2 | 2126.4 | US$m | Reported; LTM constructed |
| Reported EBITDA | 365.2 | 378.9 | 392.3 | US$m | Issuer bridge definition; LTM constructed |
| Adjusted EBITDA | 412.1 | 431.5 | 459.8 | US$m | Issuer-adjusted; LTM constructed |
| Net income | 52.9 | 82.2 | 80.0 | US$m | Reported; LTM constructed |
| Operating cash flow | 194.3 | 270.6 | 318.0 | US$m | Reported; LTM constructed |
| Capital expenditures | 94.3 | 95.3 | 103.7 | US$m | Cash purchases of capital assets; LTM constructed |
| Free cash flow | 100.0 | 175.3 | 214.3 | US$m | Operating cash flow less capital purchases; includes working capital |
| Cash interest paid | 117.8 | 111.6 | 113.8 | US$m | Cash paid; LTM constructed |
| Total debt, carrying value | 1503.1 | 1429.4 | 2004.1 | US$m | Balance-sheet debt, not principal |
| Cash and equivalents | 34.4 | 36.9 | 74.9 | US$m | Unrestricted cash and equivalents |
| Net debt | 1468.7 | 1392.5 | 1929.2 | US$m | Carrying debt less cash and equivalents |
| Total debt / reported EBITDA | 4.12 | 3.77 | 5.11 | x | Calculated |
| Net debt / reported EBITDA | 4.02 | 3.68 | 4.92 | x | Calculated |
| Reported EBITDA / cash interest | 3.10 | 3.40 | 3.45 | x | Calculated |

### Covenant terms

| Test | September 2026 requirement | Later step-down | Issuer-reported actual | Headroom |
|---|---|---|---|---|
| Consolidated total leverage | Maximum 4.75:1.00 through June 30, 2027 | 4.25:1.00 for September–December 2027; 4.00:1.00 from March 31, 2028 | Not supplied; issuer states compliant | Not supplied; agreement-defined indebtedness, excess-cash treatment and EBITDA are not fully provided |
| Consolidated secured leverage | Maximum 3.50:1.00 through December 31, 2027 | 3.25:1.00 from March 31, 2028 | Not supplied; issuer states compliant | Not supplied; agreement-defined secured indebtedness and EBITDA are not fully provided |
| Consolidated interest coverage | Minimum 3.00:1.00 throughout facility term | No step-down stated | Not supplied; issuer states compliant | Not supplied; agreement-defined EBITDA and interest expense are not provided |

The issuer reports covenant compliance as of September 30, 2026; the coverage ratios calculated in this report use cash interest paid and are not covenant ratios.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 20–21

### Net debt data

| Period | Gross debt | Cash | Net debt | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| FY2024 / 2024-12-31 | 1503.1 | 34.4 | 1468.7 | US$m | Carrying debt includes securitization obligations and excludes separately presented finance and operating leases; principal USD 1521.9 million |
| FY2025 / 2025-12-31 | 1429.4 | 36.9 | 1392.5 | US$m | Carrying debt includes securitization obligations and excludes separately presented finance and operating leases; principal USD 1444.4 million |
| 2026-09-30 | 2004.1 | 74.9 | 1929.2 | US$m | Carrying debt includes USD 100.0 million receivables securitization; excludes separately stated lease liabilities; principal USD 2025.5 million |

### Debt principal to carrying value

| Period | Contractual principal | Reconciling items | Carrying value | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| 2026-09-30 | 2025.5 | -21.4 | 2004.1 | US$m | Principal less unamortized discount and debt issuance costs of USD 21.4 million; ladder is the issuer’s September 30 contractual principal schedule |

### Post-balance-sheet adjustments

| Event | Date | Amount | Pro forma net debt | Pro forma net leverage | Reporting unit | Basis and limitation |
|---|---|---:|---:|---:|---|---|
| Quarterly dividend scheduled for payment | 2026-12-01 | Not supplied: aggregate dividend amount and payment-date share count not stated | Not supplied: total cash effect cannot be calculated | Not supplied: pro forma debt and EBITDA effect cannot be calculated | US$m | Q3 release states USD 0.30 per share, record date 2026-11-17 and payment date; no aggregate payment or pro forma debt figure is reported |

### Chart data: revenue and EBITDA

| Period | Revenue | Adjusted EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 | 2121.8 | 412.1 | US$m | Revenue reported; adjusted EBITDA issuer-defined non-GAAP measure |
| FY2025 | 2133.2 | 431.5 | US$m | Revenue reported; adjusted EBITDA issuer-defined non-GAAP measure |

The issuer-adjusted measure includes specified add-backs and excludes certain cash requirements; it is not a substitute for cash flow.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7

### Chart data: debt stack

| Facility | Ranking | Secured | Amount | Cumulative leverage | Reporting unit | Basis and limitation |
|---|---:|---|---:|---:|---|---|
| Senior secured first-lien term loan | 1 | Yes | 787.9 | 2.01 | US$m | Carrying value; first-lien collateral over substantially all issuer and subsidiary-guarantor assets, subject to exceptions; LTM reported EBITDA denominator |
| Senior secured first-lien revolving credit facility | 1 | Yes | 200.5 | 2.52 | US$m | Carrying value; first-lien collateral over substantially all issuer and subsidiary-guarantor assets, subject to exceptions; cumulative with term loan; LTM reported EBITDA denominator |

Only facilities with stated first-lien ranking are shown. The note and receivables facilities are omitted from legal-rank order because the source does not establish their relative lien priority.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–22, 49

### Chart data: EBITDA bridge

| Step | Amount | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Net income | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Opening amount; reported Q3 2026 consolidated net income; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Non-controlling interest | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | No numerical amount is shown for Q3 2026; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Depreciation and amortization | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Interest expense | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Income tax provision | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Acquisition transaction costs | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; classification: transaction costs; realization status not stated; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Restructuring and integration expense | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; classification: restructuring; realization status not stated; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Share-based compensation expense | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; classification: share-based compensation; realization status not stated; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Certain legal, environmental and other expense | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Reported add-back; classification: other stated; realization status not stated; complete numerical bridge withheld because source prints a dash for non-controlling interest |
| Adjusted EBITDA | Not supplied: full numeric bridge cannot be shown because the non-controlling-interest input is a source dash | US$m | Closing amount; issuer-adjusted non-GAAP measure; complete numerical bridge withheld because source prints a dash for non-controlling interest |

The Q3 release prints a dash for non-controlling interest in its adjusted EBITDA bridge. The full bridge is therefore not shown as a partial numeric series; the reported adjusted EBITDA is stated separately in the financial tables.
Basis: EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7

### Confidence inputs

| Input | Value |
|---|---:|
| Directly Sourced | 62 |
| Calculated | 28 |
| Assumption-Based | 0 |
| Analyst Inference | 8 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 0 |
| Insufficient Information | 8 |
| Fields present | 16 |
| Fields total | 16 |
| Source gate | pass |
| CRITICAL | 0 |
| MATERIAL | 0 |
| MINOR | 0 |

### Period table

| Period | Start | End |
|---|---|---|
| FY2024 | 2024-01-01 | 2024-12-31 |
| FY2025 | 2025-01-01 | 2025-12-31 |
| Q3 2025 | 2025-07-01 | 2025-09-30 |
| Q3 2026 | 2026-07-01 | 2026-09-30 |
| 9M 2025 | 2025-01-01 | 2025-09-30 |
| 9M 2026 | 2026-01-01 | 2026-09-30 |

### T4.1 Source register

| Source File Name | Document Type | Period Coverage | Currency | Unit | Perimeter | Accounting Basis | Evidence Quality Tier | Analytical Use | Limitations |
|---|---|---|---|---|---|---|---|---|---|
| 10-K_2024-12-31_dlx.htm.jsonl | Audited Form 10-K | FY2024 and FY2023 comparatives | USD | USD thousands, normalized here to USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP | Tier 1 | Historical financial statements and debt, lease and commitment disclosures | FY2024 filing reports many statements in thousands |
| 10-K_2025-12-31_dlx.htm.jsonl | Audited Form 10-K | FY2025, FY2024, FY2023 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP | Tier 1 | Annual statements, EBITDA reconciliation, cash flow, debt, segments, leases and benefits | Year-end report predates the Celero acquisition |
| 10-Q_2026-03-31_dlx.htm.jsonl | Unaudited Form 10-Q | Q1 and 3M 2026/2025 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP | Tier 2b | Interim cross-check and divestiture and debt events | Interim statements are not indicative of a full year |
| 10-Q_2026-06-30_dlx.htm.jsonl | Unaudited Form 10-Q | Q2 and H1 2026/2025 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP | Tier 2b | Interim and acquisition financing cross-check | Interim statements are not indicative of a full year |
| 10-Q_2026-09-30_dlx.htm.jsonl | Unaudited Form 10-Q | Q3 and 9M 2026/2025; balance sheet at September 30, 2026 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP | Tier 2b | Latest statements, debt, covenants, liquidity and non-debt obligations | Agreement-defined covenant inputs and some legal terms are not stated |
| EX99.1_2026-03-31_dlx_exhibit991050620268-k-htm.htm.jsonl | Issuer Q1 earnings release | Q1 2026 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP and issuer non-GAAP measures | Tier 2b | Dated results and outlook cross-check | Release measures are not all GAAP |
| EX99.1_2026-06-30_dlx_exhibit991080520268-k-htm.htm.jsonl | Issuer Q2 earnings release | Q2 and H1 2026 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP and issuer non-GAAP measures | Tier 2b | Dated results and outlook cross-check | Release measures are not all GAAP |
| EX99.1_2026-06-30_dlx_tm2621737d1-ex99-1-htm.htm.jsonl | Issuer acquisition announcement | 2026-07-31 closing | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | Transaction announcement | Tier 2b | Closing date and disclosed transaction facts | Not the operative purchase agreement |
| EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | Issuer Q3 earnings release | Q3 and 9M 2026/2025 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries | US GAAP and issuer non-GAAP measures | Tier 2b | EBITDA bridge, segment data, outlook and subsequent dividend | Non-GAAP measures contain adjustments |

### T4.2 Entity period key

| Entity Name | Entity Role | Fiscal Year End | Reporting Currency | Reporting Unit | Consolidation Perimeter | Accounting Basis | Available Periods |
|---|---|---|---|---|---|---|---|
| Deluxe Corporation | Public consolidated issuer and borrower | December 31 | USD | USD millions | Deluxe Corporation and consolidated subsidiaries, including Celero from July 31, 2026; includes Deluxe Receivables LLC | US GAAP | FY2024, FY2025, Q3 2025, Q3 2026, 9M 2025, 9M 2026; balance sheet at December 31, 2024, December 31, 2025 and September 30, 2026 |

### T4.3 Normalization register

| Adjustment Description | Source File | Adjustment Type | Before Value | After Value | Rationale | Affected Periods |
|---|---|---|---|---|---|---|
| Currency-scale normalization of FY2024 statements from USD thousands to USD millions | 10-K_2024-12-31_dlx.htm.jsonl | Unit scaling only | USD thousands | USD millions | Divided statement values by 1000; no currency conversion or economic adjustment | FY2024 |
| No normalization of issuer-reported adjusted EBITDA | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | None | Not applicable | Not applicable | Issuer adjustment measure is kept separate from reported EBITDA and not treated as cash flow | FY2024–LTM 2026-09-30 |

### T4.4 Income statement

| Line item | FY2024 | FY2025 | Q3 2025 | Q3 2026 | 9M 2025 | 9M 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---:|---:|---|---|---|
| Product revenue | 1205.4 | 1137.8 | 280.8 | 240.3 | 850.5 | 738.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Service revenue | 916.4 | 995.4 | 259.4 | 313.6 | 747.5 | 852.9 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Total revenue | 2121.8 | 2133.2 | 540.2 | 553.9 | 1598.0 | 1591.2 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Cost of products | -455.1 | -429.2 | -103.6 | -90.2 | -318.0 | -273.6 | USD millions | Reported; outflow/expense shown negative | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Cost of services | -540.2 | -573.3 | -145.5 | -176.1 | -428.6 | -491.0 | USD millions | Reported; outflow/expense shown negative | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Total cost of revenue | -995.3 | -1002.5 | -249.1 | -266.3 | -746.6 | -764.6 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Gross profit | 1126.5 | 1130.7 | 291.1 | 287.6 | 851.4 | 826.6 | USD millions | Calculated: total revenue less absolute total cost of revenue | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Selling, general and administrative expense | -909.2 | -873.3 | -212.4 | -226.2 | -652.1 | -637.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Restructuring and integration expense | -48.6 | -19.3 | -2.9 | -8.7 | -14.6 | -13.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Asset impairment charges | -7.7 | -5.7 | Not supplied: not separately presented in interim income statement | Not supplied: not separately presented in interim income statement | Not supplied: not separately presented in interim income statement | Not supplied: not separately presented in interim income statement | USD millions | Reported annual line; interim presentation does not separately state an amount | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Gain on sale of businesses and long-lived assets | 31.2 | Not supplied: source prints a dash | Not supplied: source prints a dash | Not supplied: source prints a dash | Not supplied: source prints a dash | 5.1 | USD millions | Reported; dashes are not converted to numerical amounts | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Operating income | 192.2 | 232.4 | 75.8 | 52.7 | 184.7 | 180.1 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Interest expense | -123.3 | -122.0 | -30.5 | -35.0 | -92.8 | -90.6 | USD millions | Reported expense | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Other income, net | 7.6 | 8.7 | 1.9 | 2.0 | 6.2 | 6.9 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Interest income | Not supplied: not separately presented | Not supplied: not separately presented | Not supplied: not separately presented | Not supplied: not separately presented | Not supplied: not separately presented | Not supplied: not separately presented | USD millions | No separate interest-income component is provided for aggregate other income, net | 10-K_2024-12-31_dlx.htm.jsonl, page 75; 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Income before income taxes | 76.5 | 119.1 | 47.2 | 19.7 | 98.1 | 96.4 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Income tax provision | -23.6 | -36.9 | -13.5 | -6.7 | -27.9 | -28.4 | USD millions | Reported expense | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Net income | 52.9 | 82.2 | 33.7 | 13.0 | 70.2 | 68.0 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Net income attributable to non-controlling interest | -0.1 | -0.1 | Not supplied: source prints a dash | Not supplied: source prints a dash | -0.1 | -0.1 | USD millions | Reported; Q3 dashes retained as gaps | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Net income attributable to Deluxe | 52.8 | 82.1 | 33.7 | 13.0 | 70.1 | 67.9 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Depreciation and amortization expense | 165.5 | 137.9 | 32.3 | 45.4 | 101.0 | 118.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 4 |
| EBITDA (Reported) | 365.2 | 378.9 | 110.0 | 100.1 | 291.8 | 305.2 | USD millions | Annual calculated to match issuer bridge definition; Q3 and 9M reported by issuer | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7 |
| EBITDA (Adjusted) | 412.1 | 431.5 | 118.9 | 127.1 | 325.5 | 353.8 | USD millions | Issuer-adjusted non-GAAP measure; adjustments vary by period | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7 |
| Share-based compensation expense (memo; non-cash adjustment) | 19.9 | 24.9 | 6.0 | 6.5 | 17.6 | 19.7 | USD millions | Separately disclosed non-cash expense; not a stand-alone income-statement line and not additive to operating expenses | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, pages 3–4; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7 |

### T4.5 Cash flow statement

| Line item | FY2024 | FY2025 | 9M 2025 | 9M 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---|---|---|
| Net income | 52.9 | 82.2 | 70.2 | 68.0 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Amortization of intangibles | 143.3 | 116.2 | 84.2 | 100.4 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Depreciation | 22.2 | 21.7 | 16.8 | 17.9 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Amortization of prepaid product discounts | 35.2 | 32.5 | 24.5 | 21.5 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Deferred income taxes | -20.4 | 26.5 | 16.1 | 24.3 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Employee share-based compensation expense | 19.9 | 24.9 | 17.6 | 19.7 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Amortization of cloud computing arrangement implementation costs | 16.5 | 15.4 | 11.8 | 7.1 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Operating lease expense | 18.3 | 14.5 | 10.9 | 10.7 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Asset impairment charges | 7.7 | 5.7 | Not supplied: source does not separately present the line | Not supplied: source does not separately present the line | USD millions | Annual values reported; no interim amount inserted | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Gain on sale of businesses and long-lived assets | -31.2 | Not supplied: source prints a dash | Not supplied: source prints a dash | -5.1 | USD millions | Reported non-cash adjustment; dashes retained as gaps | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Other non-cash items, net | 38.8 | 22.1 | 16.5 | 19.7 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 68; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Trade accounts receivable working-capital change | 3.5 | -19.9 | -20.7 | 1.1 | USD millions | Reported; positive is a source cash inflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Inventories and supplies working-capital change | 2.5 | 2.7 | 2.6 | -2.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Other current and non-current assets working-capital change | -35.2 | -20.5 | -19.5 | -32.5 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Accounts payable working-capital change | 10.5 | -3.9 | -8.7 | 3.4 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Prepaid product discount payments | -29.8 | -29.2 | -22.9 | -20.4 | USD millions | Reported cash outflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Other accrued and non-current liabilities working-capital change | -60.4 | -20.3 | -30.9 | -17.1 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Working-capital change, calculated | -108.9 | -91.1 | -100.1 | -68.3 | USD millions | Sum of six source working-capital rows | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Operating cash flow before working-capital changes, calculated | 303.2 | 361.7 | 268.6 | 284.2 | USD millions | Reported OCF less calculated working-capital change | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Net Cash from Operating Activities | 194.3 | 270.6 | 168.5 | 215.9 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Payments for acquisitions, net of cash acquired | Not supplied: source prints a dash | -12.1 | -12.1 | -642.9 | USD millions | Reported investing cash flow; dashes retained as gaps | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Residual commission buy-out | Not supplied: source prints a dash | -36.0 | Not supplied: source does not separately present the line | Not supplied: source does not separately present the line | USD millions | Reported investing cash flow where stated | 10-K_2025-12-31_dlx.htm.jsonl, page 69 |
| Maintenance capital expenditures | Not supplied: not separately disclosed | Not supplied: not separately disclosed | Not supplied: not separately disclosed | Not supplied: not separately disclosed | USD millions | Issuer reports total capital purchases without maintenance/growth split | 10-K_2025-12-31_dlx.htm.jsonl, pages 50, 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Growth capital expenditures | Not supplied: not separately disclosed | Not supplied: not separately disclosed | Not supplied: not separately disclosed | Not supplied: not separately disclosed | USD millions | Issuer reports total capital purchases without maintenance/growth split | 10-K_2025-12-31_dlx.htm.jsonl, pages 50, 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Purchases of capital assets (total capex) | -94.3 | -95.3 | -72.6 | -81.0 | USD millions | Reported cash outflow; maintenance/growth split not stated | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Proceeds from company-owned life insurance policies | 1.5 | 5.8 | 3.0 | 34.0 | USD millions | Reported investing inflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Proceeds from sale of businesses and long-lived assets | 23.3 | 2.0 | 2.0 | 10.8 | USD millions | Reported investing inflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Other investing cash flows | -0.3 | 3.9 | 3.7 | 3.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Net Cash from Investing Activities | -69.8 | -131.7 | -76.0 | -675.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Proceeds from issuing long-term debt and swingline loans | 1807.6 | 441.3 | 312.8 | 1168.7 | USD millions | Reported financing inflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Payments on long-term debt and swingline loans | -1889.9 | -518.8 | -368.9 | -587.6 | USD millions | Reported financing outflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Payments for debt issuance costs | -15.2 | -0.6 | Not supplied: source prints a dash | -12.6 | USD millions | Reported financing outflow; dash is not converted to numerical amount | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Cash dividends paid to shareholders | -54.2 | -55.2 | -41.6 | -43.0 | USD millions | Reported financing outflow | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Net change in settlement processing obligations | -108.0 | 2.2 | -236.0 | -256.9 | USD millions | Reported financing line; operating settlement float, not debt repayment | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Equity issuance and share buyback cash flows | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | Not supplied: not separately stated | USD millions | Cash proceeds and repurchases are not presented separately in the selected cash flow statements; issuer states no repurchases in the periods read | 10-K_2025-12-31_dlx.htm.jsonl, page 91; 10-Q_2026-09-30_dlx.htm.jsonl, page 51 |
| Holdback payments for acquired assets | Not supplied: source does not separately present the line | Not supplied: source does not separately present the line | -0.6 | -13.0 | USD millions | Reported interim financing outflow | 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Other financing cash flows | -7.5 | -5.7 | -5.0 | -13.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| Net Cash from Financing Activities | -267.2 | -136.8 | -339.3 | 242.3 | USD millions | Reported; interim comparative presentation conformed by issuer | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, pages 4, 6 |
| FX Effect on Cash | -6.1 | 1.7 | 1.2 | -1.2 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 5 |
| Net Cash Change | -148.8 | 3.8 | -245.6 | -218.8 | USD millions | Reported; operating plus investing plus financing plus FX | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 5 |
| Opening Cash | 458.0 | 309.2 | 309.2 | 313.0 | USD millions | Cash, cash equivalents, restricted cash and restricted cash equivalents | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 5 |
| Closing Cash | 309.2 | 313.0 | 63.6 | 94.2 | USD millions | Cash, cash equivalents, restricted cash and restricted cash equivalents | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 5 |
| Cash Interest Paid | 117.8 | 111.6 | 83.6 | 85.8 | USD millions | Cash interest paid, not interest expense | 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, page 44 |
| Cash income taxes paid, net of refunds | 46.4 | 30.9 | 30.6 | 2.7 | USD millions | Cash paid, not tax provision | 10-K_2025-12-31_dlx.htm.jsonl, page 56; 10-Q_2026-09-30_dlx.htm.jsonl, page 44 |
| Free cash flow | 100.0 | 175.3 | 95.9 | 134.9 | USD millions | Levered FCF: OCF less capex; includes working capital and cash interest; not all available for discretionary use | 10-K_2025-12-31_dlx.htm.jsonl, page 50; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 9 |

### T4.6 Balance sheet

| Line item | FY2024 | FY2025 | Q3 2026 | Unit | Basis | Source |
|---|---:|---:|---:|---|---|---|
| Cash and cash equivalents | 34.4 | 36.9 | 74.9 | USD millions | Reported unrestricted cash | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Restricted cash in settlement processing assets (memo subcomponent) | 271.9 | 273.6 | 16.6 | USD millions | Memo subcomponent of settlement processing assets; excluded from net debt cash offset and not additive to total assets | 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, page 10 |
| Non-current restricted cash (memo subcomponent) | 2.9 | 2.5 | 2.7 | USD millions | Memo subcomponent within other non-current assets | 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, page 10 |
| Total restricted cash (memo total) | 274.8 | 276.1 | 19.3 | USD millions | Calculated from restricted cash in settlement processing assets plus non-current restricted cash; excluded from net debt cash offset | 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, pages 10, 44 |
| Trade accounts receivable | 174.1 | 187.6 | 198.7 | USD millions | Reported net | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Inventories and supplies | 36.4 | 33.5 | 35.7 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Prepaid expenses | 32.7 | 33.3 | 35.1 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Revenue in excess of billings | 26.7 | 30.8 | 46.3 | USD millions | Reported contract asset | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Other current assets | 35.4 | 70.1 | 49.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Settlement processing assets | 271.9 | 273.6 | 16.6 | USD millions | Includes restricted settlement cash; see separate restricted cash row | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Total current assets | 611.6 | 665.8 | 456.6 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Property, plant and equipment, net | 111.6 | 101.0 | 149.4 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Goodwill | 1422.7 | 1422.8 | 1808.4 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Intangibles, net | 331.1 | 348.4 | 566.2 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Operating lease assets | 49.4 | 43.0 | 47.3 | USD millions | Reported asset | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Long-term investments | 61.0 | 26.4 | 7.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Deferred income tax assets | 7.0 | 1.8 | 1.8 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Postretirement benefit plan asset | 107.5 | 129.5 | 136.5 | USD millions | Reported plan asset; not unrestricted cash and not netted against debt | 10-K_2025-12-31_dlx.htm.jsonl, page 102; 10-Q_2026-09-30_dlx.htm.jsonl, page 9 |
| Pension plan obligations | 2.1 | 2.0 | Not supplied: current roll-forward not provided | USD millions | Pension liabilities are separate from debt; FY amounts include accrued and non-current obligations | 10-K_2025-12-31_dlx.htm.jsonl, page 102; 10-Q_2026-09-30_dlx.htm.jsonl, page 18 |
| Other non-current assets | 236.6 | 254.4 | 256.1 | USD millions | Q3 2026 includes postretirement plan assets; this aggregate includes other items | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 9 |
| Total Assets | 2831.0 | 2863.6 | 3293.6 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Accounts payable | 164.9 | 161.3 | 175.9 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Accrued liabilities | 149.6 | 190.6 | 173.3 | USD millions | Reported; includes current operating lease liabilities of 12.4, 11.4 and 10.2 respectively | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, page 11 |
| Settlement processing obligations | 273.9 | 275.0 | 18.1 | USD millions | Non-debt settlement float | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Current portion of long-term debt | 37.1 | 16.3 | 59.1 | USD millions | Carrying value net of issuance costs | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Total current liabilities | 625.5 | 643.2 | 426.4 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Long-term debt | 1466.0 | 1413.1 | 1945.0 | USD millions | Carrying value net of issuance costs | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Current finance lease liabilities (memo) | 1.9 | 2.4 | Not supplied: current portion is in accrued liabilities but not separately stated | USD millions | Separate from debt; Q3 current portion is not quantified separately | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, page 23 |
| Finance lease liabilities, non-current (memo) | 25.5 | 25.8 | 75.3 | USD millions | Reported non-current line | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Total finance lease liabilities (memo) | 27.4 | 28.2 | Not supplied: current portion not separately stated | USD millions | Separate from debt; Q3 total exceeds non-current line by an unquantified current portion | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 23 |
| Operating lease liabilities, total (memo) | 61.4 | 51.2 | 53.0 | USD millions | FY values from lease note; Q3 calculated from 10.2 current accrued plus 42.8 long-term line | 10-K_2025-12-31_dlx.htm.jsonl, page 110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 11 |
| Deferred income tax liabilities | 2.1 | 27.0 | 57.3 | USD millions | Reported | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Other non-current liabilities | 67.5 | 34.0 | 29.0 | USD millions | Reported; the 2025 balance sheet line was reclassified in Q3 presentation | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 6 |
| Total Liabilities | 2210.1 | 2182.9 | 2575.8 | USD millions | Calculated as total assets less total shareholders’ equity; reconciles to balance-sheet total | 10-K_2025-12-31_dlx.htm.jsonl, pages 66–67; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Total Equity | 620.9 | 680.7 | 717.8 | USD millions | Reported total shareholders’ equity including non-controlling interest | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| Total Debt | 1503.1 | 1429.4 | 2004.1 | USD millions | Current plus long-term carrying debt; includes securitization; excludes separately stated leases | 10-K_2025-12-31_dlx.htm.jsonl, page 107; 10-Q_2026-09-30_dlx.htm.jsonl, page 18 |
| Cash & Equivalents | 34.4 | 36.9 | 74.9 | USD millions | Unrestricted cash and equivalents only | 10-K_2025-12-31_dlx.htm.jsonl, page 66; 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |

### T4.8 Constructed period register

| Metric Name | Derived Period Type | Full-Year Component | Current Stub | Prior-Year Stub | Derived Value | Calculation Status | Source Files | Limitations |
|---|---|---:|---:|---:|---:|---|---|---|
| Revenue | LTM to September 30, 2026 | USD 2133.2m | USD 1591.2m | USD 1598.0m | USD 2126.4m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Comparable FY2025 and 9M periods |
| Reported EBITDA | LTM to September 30, 2026 | USD 378.9m | USD 305.2m | USD 291.8m | USD 392.3m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | Annual EBITDA derived using issuer bridge definition; Celero included from acquisition date in 9M 2026 |
| Adjusted EBITDA | LTM to September 30, 2026 | USD 431.5m | USD 353.8m | USD 325.5m | USD 459.8m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | Issuer non-GAAP adjustments vary by period |
| Operating income | LTM to September 30, 2026 | USD 232.4m | USD 180.1m | USD 184.7m | USD 227.8m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | GAAP operating income |
| Depreciation and amortization | LTM to September 30, 2026 | USD 137.9m | USD 118.3m | USD 101.0m | USD 155.2m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | As stated in issuer financial statements/releases |
| Interest expense | LTM to September 30, 2026 | USD 122.0m | USD 90.6m | USD 92.8m | USD 119.8m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Expense, not cash paid |
| Cash interest paid | LTM to September 30, 2026 | USD 111.6m | USD 85.8m | USD 83.6m | USD 113.8m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Cash paid, not accrued interest |
| Net income | LTM to September 30, 2026 | USD 82.2m | USD 68.0m | USD 70.2m | USD 80.0m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Consolidated net income |
| Operating cash flow | LTM to September 30, 2026 | USD 270.6m | USD 215.9m | USD 168.5m | USD 318.0m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Includes working-capital movements |
| Capital expenditures | LTM to September 30, 2026 | USD 95.3m | USD 81.0m | USD 72.6m | USD 103.7m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Capital purchases; maintenance/growth split not supplied |
| Free cash flow | LTM to September 30, 2026 | USD 175.3m | USD 134.9m | USD 95.9m | USD 214.3m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl | OCF less capex; cash interest and working capital included |
| Cash taxes paid | LTM to September 30, 2026 | USD 30.9m | USD 2.7m | USD 30.6m | USD 3.0m | Calculated | 10-K_2025-12-31_dlx.htm.jsonl; 10-Q_2026-09-30_dlx.htm.jsonl | Cash taxes net of refunds |

### T4.9 Calculation register

| Metric Name | Formula | Numerator Value | Numerator Source | Denominator Value | Denominator Source | Period | Currency | Unit | Calculated Value | Calculation Status | Evidence Quality Tier | Limitations |
|---|---|---:|---|---:|---|---|---|---|---:|---|---|---|
| Total debt / EBITDA | carrying debt / reported EBITDA | 1503.1 | T4.6 Total Debt | 365.2 | T4.4 EBITDA (Reported) | FY2024 / 2024-12-31 | USD | US$m | 4.12 | Calculated | Calculated | Reported EBITDA reconstructed from issuer bridge components |
| Net debt / EBITDA | net debt / reported EBITDA | 1468.7 | Net debt data | 365.2 | T4.4 EBITDA (Reported) | FY2024 / 2024-12-31 | USD | US$m | 4.02 | Calculated | Calculated | Net debt deducts unrestricted cash only |
| EBITDA / cash interest | reported EBITDA / cash interest paid | 365.2 | T4.4 EBITDA (Reported) | 117.8 | T4.5 Cash Interest Paid | FY2024 / 2024-12-31 | USD | US$m | 3.10 | Calculated | Calculated | Uses cash interest paid, not expense |
| Total debt / adjusted EBITDA | carrying debt / issuer adjusted EBITDA | 1503.1 | T4.6 Total Debt | 412.1 | T4.4 EBITDA (Adjusted) | FY2024 / 2024-12-31 | USD | US$m | 3.65 | Calculated | Calculated | Non-GAAP measure |
| Net debt / adjusted EBITDA | net debt / issuer adjusted EBITDA | 1468.7 | Net debt data | 412.1 | T4.4 EBITDA (Adjusted) | FY2024 / 2024-12-31 | USD | US$m | 3.56 | Calculated | Calculated | Non-GAAP measure; net debt deducts unrestricted cash only |
| Adjusted EBITDA / cash interest | issuer adjusted EBITDA / cash interest paid | 412.1 | T4.4 EBITDA (Adjusted) | 117.8 | T4.5 Cash Interest Paid | FY2024 / 2024-12-31 | USD | US$m | 3.50 | Calculated | Calculated | Uses cash interest paid |
| Total debt / EBITDA | carrying debt / reported EBITDA | 1429.4 | T4.6 Total Debt | 378.9 | T4.4 EBITDA (Reported) | FY2025 / 2025-12-31 | USD | US$m | 3.77 | Calculated | Calculated | Reported EBITDA reconstructed from issuer bridge components |
| Net debt / EBITDA | net debt / reported EBITDA | 1392.5 | Net debt data | 378.9 | T4.4 EBITDA (Reported) | FY2025 / 2025-12-31 | USD | US$m | 3.68 | Calculated | Calculated | Net debt deducts unrestricted cash only |
| EBITDA / cash interest | reported EBITDA / cash interest paid | 378.9 | T4.4 EBITDA (Reported) | 111.6 | T4.5 Cash Interest Paid | FY2025 / 2025-12-31 | USD | US$m | 3.40 | Calculated | Calculated | Uses cash interest paid, not expense |
| Total debt / adjusted EBITDA | carrying debt / issuer adjusted EBITDA | 1429.4 | T4.6 Total Debt | 431.5 | T4.4 EBITDA (Adjusted) | FY2025 / 2025-12-31 | USD | US$m | 3.31 | Calculated | Calculated | Non-GAAP measure |
| Net debt / adjusted EBITDA | net debt / issuer adjusted EBITDA | 1392.5 | Net debt data | 431.5 | T4.4 EBITDA (Adjusted) | FY2025 / 2025-12-31 | USD | US$m | 3.23 | Calculated | Calculated | Non-GAAP measure; net debt deducts unrestricted cash only |
| Adjusted EBITDA / cash interest | issuer adjusted EBITDA / cash interest paid | 431.5 | T4.4 EBITDA (Adjusted) | 111.6 | T4.5 Cash Interest Paid | FY2025 / 2025-12-31 | USD | US$m | 3.87 | Calculated | Calculated | Uses cash interest paid |
| Total debt / EBITDA | carrying debt / LTM reported EBITDA | 2004.1 | Net debt data gross debt | 392.3 | T4.8 Reported EBITDA | 2026-09-30 | USD | US$m | 5.11 | Calculated | Calculated | LTM includes Celero only from close |
| Net debt / EBITDA | net debt / LTM reported EBITDA | 1929.2 | Net debt data | 392.3 | T4.8 Reported EBITDA | 2026-09-30 | USD | US$m | 4.92 | Calculated | Calculated | Net debt deducts unrestricted cash only |
| EBITDA / cash interest | LTM reported EBITDA / cash interest paid | 392.3 | T4.8 Reported EBITDA | 113.8 | T4.8 Cash interest paid | 2026-09-30 | USD | US$m | 3.45 | Calculated | Calculated | Uses cash interest paid, not covenant interest expense |
| Total debt / adjusted EBITDA | carrying debt / LTM issuer adjusted EBITDA | 2004.1 | Net debt data gross debt | 459.8 | T4.8 Adjusted EBITDA | 2026-09-30 | USD | US$m | 4.36 | Calculated | Calculated | LTM non-GAAP measure |
| Net debt / adjusted EBITDA | net debt / LTM issuer adjusted EBITDA | 1929.2 | Net debt data | 459.8 | T4.8 Adjusted EBITDA | 2026-09-30 | USD | US$m | 4.20 | Calculated | Calculated | Net debt deducts unrestricted cash only |
| Adjusted EBITDA / cash interest | LTM adjusted EBITDA / cash interest paid | 459.8 | T4.8 Adjusted EBITDA | 113.8 | T4.8 Cash interest paid | 2026-09-30 | USD | US$m | 4.04 | Calculated | Calculated | Uses cash interest paid, not covenant interest expense |

### T4.10 KPI dashboard

| KPI Category | Metric Name | FY2024 | FY2025 | Q3 2025 | Q3 2026 | 9M 2025 | 9M 2026 | Trend Direction | Analyst Note |
|---|---|---:|---:|---:|---:|---:|---:|---|---|
| Segment revenue, USDm | Merchant Services | 384.0 | 398.6 | 98.0 | 135.1 | 297.2 | 347.5 | Higher | Includes Celero from July 31, 2026; source: 10-K_2025-12-31_dlx.htm.jsonl, page 113; 10-Q_2026-09-30_dlx.htm.jsonl, pages 42–43 |
| Segment revenue, USDm | B2B Payments | 287.9 | 290.5 | 73.1 | 77.3 | 214.2 | 224.4 | Higher | Segment definition follows issuer reporting; same sources as above |
| Segment revenue, USDm | Data Solutions | 234.0 | 307.3 | 89.2 | 102.9 | 234.3 | 282.6 | Higher | Segment definition follows issuer reporting; same sources as above |
| Segment revenue, USDm | Print | 1205.1 | 1136.8 | 279.9 | 238.6 | 852.3 | 736.7 | Lower | Print remains exposed to secular check/form demand decline; same sources as above |
| Segment revenue, USDm | All other | 10.8 | Not supplied: no separate FY2025 line | Not supplied: not separately reported | Not supplied: not separately reported | Not supplied: not separately reported | Not supplied: not separately reported | Not comparable | The business exit and segment presentation changed; 2025 and interim source tables report four segments |
| Segment adjusted EBITDA, USDm | Merchant Services | 78.5 | 85.9 | 20.4 | 32.1 | 63.5 | 83.9 | Higher | Issuer segment adjusted EBITDA; includes Celero in 2026 after close; source: 10-K_2025-12-31_dlx.htm.jsonl, pages 113–114; 10-Q_2026-09-30_dlx.htm.jsonl, pages 42–43 |
| Segment adjusted EBITDA, USDm | B2B Payments | 57.1 | 64.4 | 16.8 | 22.5 | 45.8 | 58.0 | Higher | Issuer segment adjusted EBITDA; same sources as above |
| Segment adjusted EBITDA, USDm | Data Solutions | 60.5 | 86.4 | 29.1 | 27.6 | 69.1 | 68.6 | Lower | Q3 2026 result slipped versus prior quarter-year comparator while nine-month amount was close to prior period; same sources as above |
| Segment adjusted EBITDA, USDm | Print | 376.6 | 366.9 | 93.5 | 84.3 | 274.7 | 256.0 | Lower | Margin support and cost savings partly offset lower revenue; same sources as above |
| Segment adjusted EBITDA, USDm | Corporate operations | -166.2 | -172.1 | -40.9 | -39.4 | -127.6 | -112.7 | Better | Unallocated corporate costs reduce total segment earnings to consolidated issuer-adjusted EBITDA; same sources as above |
| Segment adjusted EBITDA, USDm | All other | 5.6 | Not supplied: no separate FY2025 line | Not supplied: not separately reported | Not supplied: not separately reported | Not supplied: not separately reported | Not supplied: not separately reported | Not comparable | Segment business-exit perimeter differs; same sources as above |
| Segment adjusted EBITDA, USDm | Total consolidated adjusted EBITDA | 412.1 | 431.5 | 118.9 | 127.1 | 325.5 | 353.8 | Higher | Consolidated issuer-adjusted measure; source: 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7 |
| Segment adjusted EBITDA margin, % | Merchant Services | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 20.8 | 23.8 | 21.4 | 24.1 | Higher | Issuer-reported; Q3 and 9M margins; source: EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 5 |
| Segment adjusted EBITDA margin, % | B2B Payments | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 23.0 | 29.1 | 21.4 | 25.8 | Higher | Issuer-reported; Q3 and 9M margins; same source as above |
| Segment adjusted EBITDA margin, % | Data Solutions | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 32.6 | 26.8 | 29.5 | 24.3 | Lower | Issuer-reported; quarterly and 9M periods moved lower; same source as above |
| Segment adjusted EBITDA margin, % | Print | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 33.4 | 35.3 | 32.2 | 34.7 | Higher | Issuer-reported; mix and cost controls offset volume decline; same source as above |
| Segment adjusted EBITDA margin, % | Consolidated adjusted EBITDA | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 22.0 | 22.9 | 20.4 | 22.2 | Higher | Issuer-reported margin; the comparable-adjusted series is separately defined; same source as above |
| Segment adjusted EBITDA margin, % | Comparable adjusted EBITDA | Not supplied: annual margin not separately reported | Not supplied: annual margin not separately reported | 22.8 | 22.9 | 20.9 | 22.2 | Higher | Issuer-reported comparator adjusts for business exits; same source as above |

### T4.11 Definition conflict register

| Metric Name | Canonical Definition | Issuer-Reported Definition | Source of Conflict | Periods Affected | Materiality | Modules Affected | Resolution / Recommendation |
|---|---|---|---|---|---|---|---|
| EBITDA (Reported) | Unadjusted EBITDA with a consistent issuer-reported bridge or component calculation | Q3 release defines EBITDA by adding interest, taxes and D&A to net income after non-controlling interest; this differs from EBIT plus D&A | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7 | FY2024–LTM 2026-09-30 | High: leverage denominator differs materially from EBIT plus D&A | Financial foundation | Use the issuer bridge consistently; keep EBIT plus D&A separate and do not mix the definitions |
| Adjusted EBITDA | Reported EBITDA plus explicitly identified adjustments; never treated as cash flow | Issuer excludes stated acquisition amortization, transaction costs, restructuring, share-based compensation, selected legal/environmental items and other specified amounts | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7 | FY2024–9M 2026 | High: add-backs affect leverage and may recur | Financial foundation | Show adjusted separately, retain issuer-defined add-backs and use reported EBITDA as the primary ratio denominator |
| Debt: principal versus carrying value | Debt uses balance-sheet carrying value; principal is a separate contractual amount | Issuer reports USD 2025.5 million principal and USD 2004.1 million carrying debt at September 30, 2026 after discount and issuance costs | 10-Q_2026-09-30_dlx.htm.jsonl, pages 18–19, 49 | September 30, 2026 | Medium: USD 21.4 million difference | Financial foundation | Use carrying debt in leverage and net-debt tables; reconcile principal separately |
| Net debt cash offset | Cash and cash equivalents available to offset debt, with restricted cash excluded | Issuer defines net debt as total debt less cash and cash equivalents; settlement restricted cash is reported separately | 10-Q_2026-09-30_dlx.htm.jsonl, pages 10, 39; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 5 | FY2024–September 30, 2026 | Medium: settlement cash is not unrestricted liquidity | Financial foundation | Use the reported unrestricted cash line; do not deduct restricted settlement cash |
| Free cash flow | OCF less capital-asset purchases; identify interest, taxes and working capital included | Issuer uses the same formula but states that mandatory debt service and other cash needs reduce discretion | 10-K_2025-12-31_dlx.htm.jsonl, page 50; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 9 | FY2024–LTM 2026-09-30 | Medium: not all FCF is discretionary | Financial foundation | Label as issuer non-GAAP FCF and do not treat it as cash available solely for debt reduction |
| Interest coverage | Use cash interest paid for the reported cash-coverage KPI | Loan covenant uses agreement-defined consolidated interest expense, not cash interest paid | 10-Q_2026-09-30_dlx.htm.jsonl, pages 20–21, 44 | September 30, 2026 | High: reported coverage cannot establish covenant headroom | Financial foundation | Show cash coverage and covenant test separately; do not infer headroom |

### T4.13 Readiness

| Requested Use | Readiness Status | Gaps or Limitations | Recommended Actions |
|---|---|---|---|
| Consolidated financial foundation and disclosed credit profile through September 30, 2026 | Ready with Limitations | Agreement-defined covenant ratios and headroom, floating spreads/floors, and relative lien priority are not established; current pension detail and updated contract commitments are limited; scheduled dividend total is not stated | Obtain the full amended credit agreement and current covenant certificate, confirm current debt and commitment schedules, and refresh post-period cash events |

### T4.18 Debt instruments

| Instrument | Type | Carrying Value | Principal | Drawn | Commitment | Security | Ranking | Currency | Reporting Currency Amount | FX Rate | Coupon or Margin | Rate Type | Reference Rate | Spread (bps) | Floor (bps) | Maturity | Annual Amortisation | Source |
|---|---|---:|---:|---:|---:|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| Term loan under Deluxe Corporation amended credit agreement | Term loan | 787.9 | 800.0 | 800.0 | 800.0 | First lien on substantially all issuer and subsidiary-guarantor assets, subject to exceptions | 1 | USD | 787.9 | Not applicable | SOFR or alternative base rate plus leverage-based margin; exact margin not stated | Floating | SOFR or alternative base rate | Not supplied: exact spread not stated | Not supplied: floor not stated | 2031-07-31 | 15.0 in Q4 2026; 60.0 each in 2027–2029; 65.0 in 2030; 40.0 in 2031 before maturity balloon | 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–20, 49 |
| Revolving facility under Deluxe Corporation amended credit agreement | Revolver | 200.5 | 200.5 | 200.5 | 400.0 | First lien on substantially all issuer and subsidiary-guarantor assets, subject to exceptions | 1 | USD | 200.5 | Not applicable | SOFR or alternative base rate plus leverage-based margin; exact margin not stated | Floating | SOFR or alternative base rate | Not supplied: exact spread not stated | Not supplied: floor not stated | 2031-07-31 | 0 | 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–21, 49 |
| Deluxe Corporation senior unsecured notes due June 2029 | Notes | 471.4 | 475.0 | Not applicable | Not applicable | Unsecured | Not supplied: no relative legal ranking stated | USD | 471.4 | Not applicable | 8.0% | Fixed | Not applicable | Not applicable | Not applicable | June 2029 | 0 | 10-Q_2026-09-30_dlx.htm.jsonl, pages 21, 49 |
| Deluxe Corporation senior secured notes due September 2029 | Notes | 444.3 | 450.0 | Not applicable | Not applicable | Secured; collateral and priority relative to first-lien facilities not stated | Not supplied: relative lien priority not stated | USD | 444.3 | Not applicable | 8.125% | Fixed | Not applicable | Not applicable | Not applicable | September 2029; accelerates to February 1, 2029 if 2021 unsecured notes remain outstanding then | 0 | 10-Q_2026-09-30_dlx.htm.jsonl, pages 21, 49 |
| Deluxe Receivables LLC receivables securitization obligations | Receivables financing | 100.0 | 100.0 | 100.0 | 100.0 maximum, subject to borrowing base | Accounts receivable collateral; Deluxe Receivables LLC is consolidated | Not supplied: priority relative to credit facilities not stated | USD | 100.0 | Not applicable | Commercial paper rate or SOFR plus applicable margin; current rate 5.21% at September 30, 2026 | Floating | Commercial paper or SOFR | Not supplied: exact margin not stated | Not supplied: floor not stated | December 2028 unless extended | 0 | 10-Q_2026-09-30_dlx.htm.jsonl, pages 18, 21–22 |

The first-lien facilities have USD 9.7 million of letters of credit against the revolver commitment; availability is calculated separately from debt drawn. The issuer states the term loan and revolving borrowings are secured by substantially all assets of the issuer and subsidiary guarantors, subject to exceptions. The filing names Deluxe Receivables LLC as party to its securitization facility but does not establish co-issuers or the full guarantor schedule for the other instruments; it also does not enumerate the notes’ guarantor scope or the securitization’s priority relative to other liens.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–22

### Debt instrument limitations

The September 2026 filing gives the latest balance sheet and acquisition accounting, but the purchase-price allocation remains preliminary and there is no full operative agreement text in the pinned sources. Contractual debt terms are reported at summary level. Annual pension and lease schedules are not fully refreshed to September 2026; where interim values are not separately disclosed, they are identified as gaps.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 12–13, 19–24; 10-K_2025-12-31_dlx.htm.jsonl, pages 102–106, 110–111

## Calculations

| ID | Formula | Inputs | Result | Source / locator |
|---|---|---|---:|---|
| FY24-GP | Revenue less absolute cost of revenue | 2121.8 - 995.3 | 1126.5 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67 |
| FY25-GP | Revenue less absolute cost of revenue | 2133.2 - 1002.5 | 1130.7 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67 |
| Q325-GP | Revenue less absolute cost of revenue | 540.2 - 249.1 | 291.1 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| Q326-GP | Revenue less absolute cost of revenue | 553.9 - 266.3 | 287.6 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| 9M25-GP | Revenue less absolute cost of revenue | 1598.0 - 746.6 | 851.4 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| 9M26-GP | Revenue less absolute cost of revenue | 1591.2 - 764.6 | 826.6 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| FY24-EBITDA | Net income + signed NCI + D&A + interest expense + tax provision | 52.9 - 0.1 + 165.5 + 123.3 + 23.6 | 365.2 US$m | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| FY25-EBITDA | Net income + signed NCI + D&A + interest expense + tax provision | 82.2 - 0.1 + 137.9 + 122.0 + 36.9 | 378.9 US$m | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| LTM-REV | FY2025 + 9M2026 - 9M2025 | 2133.2 + 1591.2 - 1598.0 | 2126.4 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| LTM-EBITDA | FY2025 + 9M2026 - 9M2025 | 378.9 + 305.2 - 291.8 | 392.3 US$m | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 4 |
| LTM-AEBITDA | FY2025 + 9M2026 - 9M2025 | 431.5 + 353.8 - 325.5 | 459.8 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, pages 4, 7 |
| LTM-EBIT | FY2025 + 9M2026 - 9M2025 | 232.4 + 180.1 - 184.7 | 227.8 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| LTM-DA | FY2025 + 9M2026 - 9M2025 | 137.9 + 118.3 - 101.0 | 155.2 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 51; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 4 |
| LTM-INT | FY2025 + 9M2026 - 9M2025 | 122.0 + 90.6 - 92.8 | 119.8 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| LTM-CASHINT | FY2025 + 9M2026 - 9M2025 | 111.6 + 85.8 - 83.6 | 113.8 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 90; 10-Q_2026-09-30_dlx.htm.jsonl, page 44 |
| LTM-NI | FY2025 + 9M2026 - 9M2025 | 82.2 + 68.0 - 70.2 | 80.0 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3 |
| LTM-OCF | FY2025 + 9M2026 - 9M2025 | 270.6 + 215.9 - 168.5 | 318.0 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| LTM-CAPEX | FY2025 + 9M2026 - 9M2025 | 95.3 + 81.0 - 72.6 | 103.7 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69; 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| LTM-FCF | FY2025 + 9M2026 - 9M2025 | 175.3 + 134.9 - 95.9 | 214.3 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 50; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 9 |
| LTM-TAX | FY2025 + 9M2026 - 9M2025 | 30.9 + 2.7 - 30.6 | 3.0 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 56; 10-Q_2026-09-30_dlx.htm.jsonl, page 44 |
| WC24 | Sum of six operating working-capital changes | 3.5 + 2.5 - 35.2 + 10.5 - 29.8 - 60.4 | -108.9 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69 |
| WC25 | Sum of six operating working-capital changes | -19.9 + 2.7 - 20.5 - 3.9 - 29.2 - 20.3 | -91.1 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69 |
| WC9M25 | Sum of six operating working-capital changes | -20.7 + 2.6 - 19.5 - 8.7 - 22.9 - 30.9 | -100.1 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| WC9M26 | Sum of six operating working-capital changes | 1.1 - 2.8 - 32.5 + 3.4 - 20.4 - 17.1 | -68.3 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| OCF-BEFORE-WC24 | OCF less working-capital change | 194.3 - (-108.9) | 303.2 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69 |
| OCF-BEFORE-WC25 | OCF less working-capital change | 270.6 - (-91.1) | 361.7 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 69 |
| OCF-BEFORE-WC9M25 | OCF less working-capital change | 168.5 - (-100.1) | 268.6 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| OCF-BEFORE-WC9M26 | OCF less working-capital change | 215.9 - (-68.3) | 284.2 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 4 |
| FCF24 | OCF less capex | 194.3 - 94.3 | 100.0 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 50 |
| FCF25 | OCF less capex | 270.6 - 95.3 | 175.3 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 50 |
| FCF9M25 | OCF less capex | 168.5 - 72.6 | 95.9 US$m | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 9 |
| FCF9M26 | OCF less capex | 215.9 - 81.0 | 134.9 US$m | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 9 |
| ND24 | Total debt less unrestricted cash | 1503.1 - 34.4 | 1468.7 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ND25 | Total debt less unrestricted cash | 1429.4 - 36.9 | 1392.5 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ND26 | Total debt less unrestricted cash | 2004.1 - 74.9 | 1929.2 US$m | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 5 |
| LIQ24 | Revolver commitment less drawn amount and letters of credit | 400.000 - 18.000 - 7.698 | 374.302 US$m | 10-K_2024-12-31_dlx.htm.jsonl, page 116 |
| LIQ25 | Commitment less drawn less letters of credit | 400.0 - 13.0 - 7.4 | 379.6 US$m | 10-K_2025-12-31_dlx.htm.jsonl, page 108 |
| LIQ26 | Commitment less drawn less letters of credit | 400.0 - 200.5 - 9.7 | 189.8 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 21 |
| MAT26 | Sum of maturity ladder | 15.0 + 60.0 + 160.0 + 985.0 + 65.0 + 740.5 | 2025.5 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, pages 18–19 |
| DEBT-RECON | Contractual principal less unamortized discount and issuance costs | 2025.5 - 21.4 | 2004.1 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 18 |
| LIQ-POOL26 | Cash plus undrawn committed facility | 74.9 + 189.8 | 264.7 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 21 |
| LEV24-TD | Total debt / reported EBITDA | 1503.1 / 365.2 | 4.12x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| LEV24-ND | Net debt / reported EBITDA | 1468.7 / 365.2 | 4.02x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| COV24 | Reported EBITDA / cash interest | 365.2 / 117.8 | 3.10x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 90 |
| LEV25-TD | Total debt / reported EBITDA | 1429.4 / 378.9 | 3.77x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| LEV25-ND | Net debt / reported EBITDA | 1392.5 / 378.9 | 3.68x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 67 |
| COV25 | Reported EBITDA / cash interest | 378.9 / 111.6 | 3.40x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 90 |
| LEV26-TD | Total debt / LTM reported EBITDA | 2004.1 / 392.3 | 5.11x | 10-Q_2026-09-30_dlx.htm.jsonl, pages 18, 39; LTM calculations |
| LEV26-ND | Net debt / LTM reported EBITDA | 1929.2 / 392.3 | 4.92x | 10-Q_2026-09-30_dlx.htm.jsonl, pages 39; LTM calculations |
| COV26 | LTM reported EBITDA / LTM cash interest | 392.3 / 113.8 | 3.45x | T4.8 constructed values |
| ADJ-LEV24-TD | Total debt / adjusted EBITDA | 1503.1 / 412.1 | 3.65x | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ADJ-LEV24-ND | Net debt / adjusted EBITDA | 1468.7 / 412.1 | 3.56x | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ADJ-COV24 | Adjusted EBITDA / cash interest | 412.1 / 117.8 | 3.50x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 90 |
| ADJ-LEV25-TD | Total debt / adjusted EBITDA | 1429.4 / 431.5 | 3.31x | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ADJ-LEV25-ND | Net debt / adjusted EBITDA | 1392.5 / 431.5 | 3.23x | 10-K_2025-12-31_dlx.htm.jsonl, page 51 |
| ADJ-COV25 | Adjusted EBITDA / cash interest | 431.5 / 111.6 | 3.87x | 10-K_2025-12-31_dlx.htm.jsonl, pages 51, 90 |
| ADJ-LEV26-TD | Total debt / adjusted EBITDA | 2004.1 / 459.8 | 4.36x | LTM calculations |
| ADJ-LEV26-ND | Net debt / adjusted EBITDA | 1929.2 / 459.8 | 4.20x | LTM calculations |
| ADJ-COV26 | LTM adjusted EBITDA / LTM cash interest | 459.8 / 113.8 | 4.04x | LTM calculations |
| STACK-TL | Term loan carrying debt / LTM reported EBITDA | 787.9 / 392.3 | 2.01x | 10-Q_2026-09-30_dlx.htm.jsonl, page 49; LTM calculations |
| STACK-RCF | First lien carrying debt cumulative / LTM reported EBITDA | (787.9 + 200.5) / 392.3 | 2.52x | 10-Q_2026-09-30_dlx.htm.jsonl, page 49; LTM calculations |
| LIAB24 | Total assets less total equity | 2831.0 - 620.9 | 2210.1 US$m | 10-K_2025-12-31_dlx.htm.jsonl, pages 66–67 |
| LIAB25 | Total assets less total equity | 2863.6 - 680.7 | 2182.9 US$m | 10-K_2025-12-31_dlx.htm.jsonl, pages 66–67 |
| LIAB26 | Total assets less total equity | 3293.6 - 717.8 | 2575.8 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, page 2 |
| OLEASE26 | Current plus long-term operating lease liabilities | 10.2 + 42.8 | 53.0 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 11 |
| RESTRICTED26 | Restricted cash in settlement assets plus non-current restricted cash | 16.6 + 2.7 | 19.3 US$m | 10-Q_2026-09-30_dlx.htm.jsonl, pages 10, 44 |
| EBITDA-BRIDGE26 | Complete bridge requires all components; non-controlling interest is not numerically stated | 13.0 + Not supplied: source prints a dash + 45.4 + 35.0 + 6.7 + 9.8 + 8.9 + 6.5 + 1.8 | Not calculable: a complete bridge cannot be computed without a numerical non-controlling-interest input | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7 |
| BS-PROFORMA | Dividend aggregate cash outflow | USD 0.30 per share is stated; aggregate payout not stated | Not calculable | EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 2 |

## Gaps

- The complete July 31, 2026 amended credit agreement and covenant certificate are not present in the pinned sources, leaving covenant-defined EBITDA, actual ratios and headroom, exact spreads and floors, and collateral exceptions unestablished; this restricts covenant and borrowing-cost analysis, severity High, and can be closed with the executed agreement and certificate.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–21, 51
- The legal ranking and complete guarantor scope of the 2029 senior unsecured notes, 2029 senior secured notes and receivables securitization are not stated; only the two first-lien facilities have a stated rank, so these instruments are omitted from the ranked debt stack and structural-priority and recovery analysis remains limited, severity High, and can be closed with the indentures, security documents and guarantee schedule.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 19–22
- The income statements present aggregate other income, net but do not separately state interest income, limiting the split between interest and other non-operating income, severity Low, and can be closed with a component disclosure.
Basis: 10-K_2024-12-31_dlx.htm.jsonl, page 75; 10-K_2025-12-31_dlx.htm.jsonl, page 67; 10-Q_2026-09-30_dlx.htm.jsonl, page 3
- The Q3 adjusted EBITDA bridge prints a dash for non-controlling interest, so a full numeric bridge cannot be reconstructed without treating a non-stated component as zero; this limits the component reconciliation while the reported adjusted EBITDA remains stated elsewhere, severity Low, and can be closed with the numerical input.
Basis: EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 7
- The scheduled December 2026 dividend is USD 0.30 per share, but aggregate payment amount and payment-date share count are not stated, so pro forma net debt and leverage cannot be calculated, severity Low, and can be closed with the declared aggregate payment or subsequent cash report.
Basis: EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 2
- Pension and retiree-medical obligations have not been fully updated after FY2025; this limits current claim quantification and benefit timing, severity Medium, and can be closed with current plan obligations and benefit schedules.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, pages 102–106; 10-Q_2026-09-30_dlx.htm.jsonl, pages 9, 18–20
- Multi-year supplier and service commitments were USD 225.0 million at December 31, 2024 and USD 210.0 million at December 31, 2025; no updated remaining amount is stated at September 30, 2026, limiting current fixed-commitment analysis, severity Medium, and can be closed with an updated commitment schedule.
Basis: 10-K_2024-12-31_dlx.htm.jsonl, page 63; 10-K_2025-12-31_dlx.htm.jsonl, page 57; 10-Q_2026-09-30_dlx.htm.jsonl, pages 23–24
- The September 2026 balance sheet reports USD 75.3 million of non-current finance lease liabilities, but the current portion within accrued liabilities and the resulting total finance lease liability are not stated, limiting total fixed-obligation measurement, severity Medium, and can be closed with the current lease-liability split.
Basis: 10-Q_2026-09-30_dlx.htm.jsonl, pages 2, 23
- No factoring or supplier-finance program is disclosed in the searched annual and interim sources, so whether such arrangements affect debt or working capital is not established, severity Low, and can be closed by issuer confirmation or program disclosures.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, pages 107–110; 10-Q_2026-09-30_dlx.htm.jsonl, pages 18–23
- Selected financial-statement dashes leave gain-on-sale and Q3 non-controlling-interest amounts unstated; interim statements do not separately present impairment; and some cash-flow lines are dashed or not separately presented, including the FY2024 acquisition payment, selected-period residual commission buy-out and acquired-asset holdbacks, and 9M 2025 debt issuance costs. These amounts cannot be reconstructed; severity Low, and they can be closed with period-specific cash-flow and income-statement detail.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, pages 67–69; 10-Q_2026-09-30_dlx.htm.jsonl, pages 3–4
- Cash proceeds from equity issuance and share repurchases are not separately stated in the selected cash-flow statements, limiting historical financing comparison, severity Low, and can be closed with transaction-level cash-flow detail.
Basis: 10-K_2024-12-31_dlx.htm.jsonl, page 91; 10-K_2025-12-31_dlx.htm.jsonl, page 91; 10-Q_2026-09-30_dlx.htm.jsonl, page 51
- Recorded litigation liabilities are described as not material but are not quantified individually for FY2024, FY2025 or September 2026, limiting exact contingent-claim measurement, severity Low, and can be closed with a reserve schedule.
Basis: 10-K_2025-12-31_dlx.htm.jsonl, page 112; 10-Q_2026-09-30_dlx.htm.jsonl, page 23
- The sources do not provide comparable all-other segment revenue or EBITDA after the segment presentation changed, and they do not separately report annual adjusted EBITDA margins, limiting trend comparison for these measures, severity Low, and can be closed with comparable historical segment data.
Basis: 10-K_2024-12-31_dlx.htm.jsonl, pages 51, 105–106; 10-K_2025-12-31_dlx.htm.jsonl, pages 113–114; 10-Q_2026-09-30_dlx.htm.jsonl, pages 42–43; EX99.1_2026-09-30_dlx_exhibit991110420268-k-htm.htm.jsonl, page 5

## Next module

The orchestrator selects the next module.
