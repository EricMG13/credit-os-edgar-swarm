# CP-1 Financial Foundation

## Request

Issuer: DIEBOLD NIXDORF, Inc (dbd-28823); as of 2026-11-18. Pathway: credit_snapshot. Scope: establish reported and calculated financial, debt, cash-flow and liquidity data through Q3 2026.

## Sources

| Source | Document | Document date | sha256 | Use |
|---|---|---|---|---|
| 10-K_2024-12-31_dbd.htm.jsonl | Annual report on Form 10-K for the year ended 2024-12-31 | not stated | 82b5edab10f4f813e3b4d95a80c3c0627242d316b939ab218b16f3c218f9ccb2 | Audited FY2024 statements and debt, lease and benefit context |
| 10-K_2025-12-31_dbd.htm.jsonl | Annual report on Form 10-K for the year ended 2025-12-31 | not stated | 7641f45f66e6bb590327958da55ee836901e6672d3c467b402d1e057797f6161 | Audited FY2025 and FY2024 statements, debt terms, maturities, leases and commitments |
| 10-Q_2026-03-31_dbd.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended 2026-03-31 | not stated | d14c4c75d7e7036511acdb3c6a1ea4f7aa72816ebd32ae181aeae1345a3423ed | Q1 2026 interim comparisons and developments |
| 10-Q_2026-06-30_dbd.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended 2026-06-30 | not stated | be3005fde030914c092675638e58083f5bd569aef809dd88176c99a5802b0b65 | Q2 2026 interim comparisons and developments |
| 10-Q_2026-09-30_dbd.htm.jsonl | Quarterly report on Form 10-Q for the quarter ended 2026-09-30 | not stated | ab5fbb8597a516f00d41b9a42678d2893cbfb39f1cbb48bc07cfe58441998f87 | Latest balance sheet, nine-month results, debt, liquidity and subsequent events |
| EX99.1_2026-03-31_dbd_ex-991q12026erlive-htm.htm.jsonl | Q1 2026 earnings release | 2026-04-30 | 31eb72a7175324ebe8b5a1e57506fa026b597f82d76bb2705fcdbd13bda8c2b2 | Q1 performance, adjusted EBITDA and ratings news |
| EX99.1_2026-06-30_dbd_ex-991q22026erlive-htm.htm.jsonl | Q2 2026 earnings release | 2026-07-29 | f28d196c4cda0f5731b58f8f50ae61f75618bdc7f7a9578d744a2c5bdeb4869b | Q2 operating results, cash flow and management outlook |
| EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl | Q3 2026 earnings release | 2026-10-28 | 643961e5258f40afd65d75fdd4e39253686cdc5da0f39ecaf18145b33422072f | Q3 and nine-month performance, adjusted EBITDA bridge, revised outlook and cash-tax update |

### Upstream handoff

| Module | sha256 | Use |
|---|---|---|
| CP-0 | 9dc4fbfc6e61f77f4a848de381e9d615a870d43d275b54db8df9d7dd2eb60fa7 | Source inventory, perimeter and limitations |

## Findings

### Bottom line

Cash generation weakened through Q3 2026: nine-month operating cash flow was negative USD 29.3 million and free cash flow was negative USD 68.5 million, while carrying-value net debt rose to USD 764.4 million. The USD 454.8 million of unrestricted cash and net committed revolver availability cushions near-term needs, but working-capital and tax outflows constrain that buffer.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–13; calculation C06; calculation C11

The reported notes mature in March 2030, with no borrowing drawn under the committed revolver; however, the Q3 filing does not identify the instrument behind USD 26.4 million of other long-term debt or its maturity. The notes and revolver share first-priority collateral, and complete covenant thresholds cannot be established without the executed agreements.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 17–18; 10-K_2025-12-31_dbd.htm.jsonl, pages 78–80

### Events: Sources

| Event date | Date precision | Published | Event | Status | Source | Credit relevance |
|---|---|---|---|---|---|---|
| 2026-10-23 | day | Not supplied: the quarterly filing does not state its publication date | Repurchased 294,094 additional shares for USD 19.3 million through this date | Historical — company reports the purchase through 2026-10-23 | 10-Q_2026-09-30_dbd.htm.jsonl, page 10 | Post-period cash use; treated separately from September 30 balances |
| 2026-10-28 | day | 2026-10-28 | Board authorized a new USD 250 million share repurchase program | Historical — board authorization announced | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 1 | Discretionary future cash use; authorization itself does not reduce cash or increase debt |
| 2026-Q4 | quarter | 2026-10-28 | Additional German estimated tax payments for tax years 2024 and 2025 are scheduled; 2026 cash taxes attributable to 2024 and 2025 are estimated at approximately USD 50 million | Scheduled — company expects additional Q4 2026 payments | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 3 | Further cash outflow after the September balance sheet; the full 2026 cash-tax amount is not disclosed |

### Financials and credit metrics

| Metric | Period | Value | Reporting unit | Basis and limitation | Source |
|---|---|---:|---|---|---|
| Revenue | Q3 2026 | 994.3 | USD millions | GAAP; up 5.2% year over year | 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Revenue | 9M 2026 | 2,816.8 | USD millions | GAAP; up 4.3% year over year | 10-Q_2026-09-30_dbd.htm.jsonl, pages 6–7 |
| Revenue | FY2025 | 3,805.7 | USD millions | Audited, consolidated | 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Revenue | FY2024 | 3,751.1 | USD millions | Audited Successor period | 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Reported EBITDA | Q3 2026 | 66.5 | USD millions | Issuer definition; non-GAAP reconciliation | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 14–15 |
| Reported EBITDA | 9M 2026 | 220.0 | USD millions | Issuer definition; non-GAAP reconciliation | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14 |
| Adjusted EBITDA | Q3 2026 | 127.8 | USD millions | Issuer-adjusted; adjustments listed in EBITDA bridge | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 8, 14–15 |
| Adjusted EBITDA | 9M 2026 | 347.5 | USD millions | Issuer-adjusted; not a cash-flow measure | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 8, 14–15 |
| Net income | Q3 2026 | 7.1 | USD millions | GAAP; compared with USD 41.7 million in Q3 2025 | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11–12 |
| Net cash from operating activities | Q3 2026 | -47.4 | USD millions | GAAP cash flow; release attributes use to VAT refund timing and working capital | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 7 |
| Net cash from operating activities | 9M 2026 | -29.3 | USD millions | GAAP; compared with USD 83.2 million in 9M 2025 | 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–13 |
| Free cash flow | Q3 2026 | -60.3 | USD millions | OCF less capital expenditure and capitalized software; before discrete-tax exclusion | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 7 |
| Free cash flow | 9M 2026 | -68.5 | USD millions | OCF less capital expenditure and capitalized software; includes discrete tax payments | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 7 |
| Free cash flow, excluding discrete taxes | Q3 2026 | -45.9 | USD millions | Issuer non-GAAP measure; excludes USD 14.4 million discrete tax payments | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 7 |
| Free cash flow, excluding discrete taxes | 9M 2026 | -36.2 | USD millions | Issuer non-GAAP measure; excludes USD 32.3 million discrete tax payments | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 7 |
| Net debt, carrying value less reported cash | 2026-09-30 | 764.4 | USD millions | Analyst calculation; cash includes USD 15.9 million restricted cash | calculation C06 |
| Gross debt / EBITDA | LTM to 2026-09-30 | 2.90 | x | Carrying-value debt / calculated reported EBITDA | calculation C04 |
| Net debt / EBITDA | LTM to 2026-09-30 | 2.33 | x | Carrying-value net debt / calculated reported EBITDA | calculation C04 |
| EBITDA / cash interest | LTM to 2026-09-30 | 4.27 | x | Reported EBITDA / cash interest paid | calculation C05 |
| Unrestricted cash plus net committed availability | 2026-09-30 | 454.8 | USD millions | Excludes restricted cash; nets USD 24.2 million of LCs from USD 310 million revolver | calculation C11 |

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 / 2024-12-31 | 2.85 | 1.89 | x | Carrying-value debt; reported cash includes restricted cash; reported EBITDA is calculated |
| FY2025 / 2025-12-31 | 2.88 | 1.69 | x | Carrying-value debt; reported cash includes restricted cash; reported EBITDA is calculated |
| 2026-09-30 | 2.90 | 2.33 | x | Interim balance-sheet debt; EBITDA and cash interest use LTM components; cash includes restricted cash |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
|---|---:|---|---|
| FY2024 / 2024-12-31 | 2.18 | x | Reported EBITDA / cash interest paid |
| FY2025 / 2025-12-31 | 5.51 | x | Reported EBITDA / cash interest paid |
| 2026-09-30 | 4.27 | x | LTM reported EBITDA / LTM cash interest paid |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| FY2024 / 2024-12-31 | 311.3 | 288.1 | US$m | Reported cash includes USD 15.1 million restricted; facility availability nets USD 21.9 million LCs |
| FY2025 / 2025-12-31 | 387.3 | 285.7 | US$m | Reported cash includes USD 18.4 million restricted and excludes USD 29.1 million short-term investments; facility availability nets USD 24.3 million LCs |
| 2026-09-30 | 184.9 | 285.8 | US$m | Reported cash includes USD 15.9 million restricted; facility availability nets USD 24.2 million LCs |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
|---|---:|---|---|
| 2030 | 950.0 | US$m | 7.75% senior secured notes mature 2030-03-31; latest filing does not state a maturity for the USD 26.4 million other long-term debt balance |
| Not supplied: other long-term debt maturity | Not supplied: Q3 2026 filing does not state the maturity | US$m | Q3 debt note reports USD 26.4 million of other long-term debt but not its instrument or due date |

### Net debt data

| Period | Gross debt | Cash | Net debt | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| FY2024 / 2024-12-31 | 927.3 | 311.3 | 616.0 | US$m | Gross debt includes debt-line carrying value net of USD 38.5 million deferred financing fees; principal basis USD 965.8 million; cash includes restricted cash. Source: 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 |
| FY2025 / 2025-12-31 | 938.5 | 387.3 | 551.2 | US$m | Gross debt includes debt-line carrying value net of USD 32.2 million deferred financing fees; principal basis USD 970.7 million, including USD 20.7 million non-current finance lease liability; cash includes restricted cash. Source: 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78, 89 |
| 2026-09-30 | 949.3 | 184.9 | 764.4 | US$m | Gross debt includes USD 976.4 million long-term debt less USD 27.1 million deferred financing fees; the Q3 filing does not identify the USD 26.4 million “Other” component. Cash includes restricted cash. Source: 10-Q_2026-09-30_dbd.htm.jsonl, pages 11, 17 |

### Debt principal to carrying value

| Period | Contractual principal | Reconciling items | Carrying value | Reporting unit | Basis and limitation |
|---|---:|---:|---:|---|---|
| 2026-09-30 | Not supplied: maturity and contractual principal of other long-term debt are not stated | Not supplied: the maturity ladder does not identify the other debt principal by due year; deferred financing fees are USD 27.1 million | 949.3 | US$m | The 2030 notes principal is USD 950.0 million; Q3 long-term debt also includes USD 26.4 million of unidentified “Other” debt and USD 27.1 million of deferred financing fees. Source: 10-Q_2026-09-30_dbd.htm.jsonl, pages 17–18 |

### Post-balance-sheet adjustments

| Event | Date | Amount | Pro forma net debt | Pro forma net leverage | Reporting unit | Basis and limitation |
|---|---|---:|---:|---:|---|---|
| Additional share repurchases through 2026-10-23 | 2026-10-23 | 19.3 | 783.7 | 2.39 | USD millions | Calculated mechanically from 2026-09-30 carrying-value net debt plus USD 19.3 million cash use; does not include unreported operating cash flows after quarter-end. Source: 10-Q_2026-09-30_dbd.htm.jsonl, page 10; calculation C12 |
| Scheduled German discrete tax payments | Not supplied: source states Q4 2026 only | Not supplied: approximately USD 50 million covers cash taxes attributable to 2024 and 2025 for all of 2026; total 2026 cash taxes are not stated | Not supplied: post-period cash balance and full payment amount are not stated | Not supplied: post-period cash balance and full payment amount are not stated | USD millions | Future payment is excluded from period figures; source states the 2024 and 2025 amounts are estimates. Source: EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 3 |

### Chart data: revenue and EBITDA

| Period | Revenue | Adjusted EBITDA | Reporting unit | Basis and limitation |
|---|---:|---:|---|---|
| Q3 2026 | 994.3 | 127.8 | US$m | Revenue is GAAP; EBITDA is issuer-adjusted and includes specified add-backs |
| Q3 2025 | 945.2 | 121.9 | US$m | Revenue is GAAP; EBITDA is issuer-adjusted and includes specified add-backs |

### Chart data: debt stack

| Facility | Ranking | Secured | Amount | Cumulative leverage | Reporting unit | Basis and limitation |
|---|---:|---|---:|---:|---|---|
| Revolving Credit Facility, undrawn | 1 | Yes | 0.0 | 0.00 | US$m | First-priority collateral pari passu with the notes; guaranteed by the Guarantors; USD 310 million commitment, USD 24.2 million LCs outstanding, matures 2029-12-18 |
| 2030 Senior Secured Notes | 1 | Yes | 950.0 | 2.90 | US$m | First-priority liens pari passu with the revolver; issuer Diebold Nixdorf, Incorporated; guarantor scope is described in the debt instrument table |

### Chart data: EBITDA bridge

| Step | Amount | Reporting unit | Basis and limitation |
|---|---:|---|---|
| Q3 2026 reported EBITDA | 66.5 | US$m | Opening amount; company-defined EBITDA |
| Share-based compensation | 4.3 | US$m | Add-back stated by issuer |
| Restructuring and other savings initiative expenses | 34.5 | US$m | Add-back stated by issuer |
| Non-core Turkey operation | 1.8 | US$m | Add-back stated by issuer; includes the loss contribution |
| Impairment of unconsolidated subsidiary | 16.9 | US$m | Add-back stated by issuer |
| Foreign exchange loss (gain), net | -0.5 | US$m | Adjustment stated by issuer; net gain reduces adjusted EBITDA bridge |
| Equity in loss of unconsolidated subsidiaries | 2.6 | US$m | Add-back stated by issuer |
| Non-routine income or expense, net | 1.7 | US$m | Add-back stated by issuer |
| Q3 2026 adjusted EBITDA | 127.8 | US$m | Closing issuer-adjusted amount; amounts reconcile exactly |

### Period

| Period | Start | End |
|---|---|---|
| Q3 2026 | 2026-07-01 | 2026-09-30 |
| Q3 2025 | 2025-07-01 | 2025-09-30 |
| 9M 2026 | 2026-01-01 | 2026-09-30 |
| 9M 2025 | 2025-01-01 | 2025-09-30 |
| FY2025 | 2025-01-01 | 2025-12-31 |
| FY2024 | 2024-01-01 | 2024-12-31 |
| 2026-09-30 | Not applicable: balance-sheet instant | 2026-09-30 |
| 2025-12-31 | Not applicable: balance-sheet instant | 2025-12-31 |
| 2024-12-31 | Not applicable: balance-sheet instant | 2024-12-31 |

### T4.1 Source register

| Source File Name | Document Type | Period Coverage | Currency | Unit | Perimeter | Accounting Basis | Evidence Quality Tier | Analytical Use | Limitations |
|---|---|---|---|---|---|---|---|---|---|
| 10-K_2024-12-31_dbd.htm.jsonl | Form 10-K; audited financial statements | FY2024 and FY2023 balance-sheet comparison | USD | millions | Diebold Nixdorf, Inc and consolidated subsidiaries | U.S. GAAP; Successor from emergence | Tier 1 for audited statements | Historical financials, debt, leases, benefits | FY2024 is the Successor period; predecessor periods in that report are not comparable |
| 10-K_2025-12-31_dbd.htm.jsonl | Form 10-K; audited financial statements | FY2025 and FY2024 | USD | millions | Diebold Nixdorf, Inc and consolidated subsidiaries | U.S. GAAP; Successor | Tier 1 for audited statements | Annual statements, debt terms, maturity obligations, leases and benefits | Management measures and forward outlook are unaudited; FY2025 adjusted EBITDA not supplied |
| 10-Q_2026-03-31_dbd.htm.jsonl | Form 10-Q; unaudited quarterly filing | Q1 and 3M 2026, comparative 2025 | USD | millions | Diebold Nixdorf, Inc and consolidated subsidiaries | U.S. GAAP; interim | Tier 2b | Interim statements, debt and liquidity updates | No independent review report is included in the pinned text |
| 10-Q_2026-06-30_dbd.htm.jsonl | Form 10-Q; unaudited quarterly filing | Q2 and 6M 2026, comparative 2025 | USD | millions | Diebold Nixdorf, Inc and consolidated subsidiaries | U.S. GAAP; interim | Tier 2b | Interim statements, debt and liquidity updates | No independent review report is included in the pinned text |
| 10-Q_2026-09-30_dbd.htm.jsonl | Form 10-Q; unaudited quarterly filing | Q3 and 9M 2026, comparative 2025 | USD | millions | Diebold Nixdorf, Inc and consolidated subsidiaries | U.S. GAAP; interim | Tier 2b | Latest statements, debt, cash flow, liquidity and subsequent events | No independent review report is included in the pinned text; “Other” debt instrument is unidentified |
| EX99.1_2026-03-31_dbd_ex-991q12026erlive-htm.htm.jsonl | Issuer earnings release | Q1 2026 | USD | millions | Diebold Nixdorf, Inc and subsidiaries | Non-GAAP measures alongside GAAP summary | Tier 2b | Q1 operating trend and rating event | Management presentation; reconcile non-GAAP data to filings |
| EX99.1_2026-06-30_dbd_ex-991q22026erlive-htm.htm.jsonl | Issuer earnings release | Q2 2026 | USD | millions | Diebold Nixdorf, Inc and subsidiaries | Non-GAAP measures alongside GAAP summary | Tier 2b | Q2 operating trend and cash flow | Management presentation; reconcile non-GAAP data to filings |
| EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl | Issuer earnings release | Q3 and 9M 2026 | USD | millions | Diebold Nixdorf, Inc and subsidiaries | Non-GAAP measures alongside GAAP summary | Tier 2b | Adjusted EBITDA bridge, FCF, tax update and outlook | Management presentation; adjusted EBITDA is not a cash-flow measure |

### T4.2 Entity period key

| Entity Name | Entity Role | Fiscal Year End | Reporting Currency | Reporting Unit | Consolidation Perimeter | Accounting Basis | Available Periods |
|---|---|---|---|---|---|---|---|
| Diebold Nixdorf, Incorporated | Reporting issuer and note issuer | December 31 | USD | USD millions | Issuer and consolidated subsidiaries; debt guarantees apply to specified Guarantors, not necessarily every consolidated subsidiary | U.S. GAAP; FY2025/FY2024 audited Successor periods; 2026 interim statements unaudited | FY2024, FY2025, Q3 2025, Q3 2026, 9M 2025, 9M 2026, 2026-09-30 balance sheet |

### T4.3 Normalization register

| Adjustment Description | Source File | Adjustment Type | Before Value | After Value | Rationale | Affected Periods |
|---|---|---|---|---|---|---|
| No currency, unit, accounting-basis or perimeter conversion applied | 10-K_2025-12-31_dbd.htm.jsonl; 10-Q_2026-09-30_dbd.htm.jsonl | None required | USD millions; U.S. GAAP; consolidated | Same | Statements share USD millions and consolidated U.S. GAAP presentation; successor annual periods are comparable | FY2024, FY2025, 2026 interim periods |

### T4.4 Income statement

| Line item | Q3 2026 | Q3 2025 | 9M 2026 | 9M 2025 | FY2025 | FY2024 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---:|---:|---|---|---|
| Services revenue | 565.0 | 544.2 | 1,654.2 | 1,595.3 | 2,168.9 | 2,150.4 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11–12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Products revenue | 429.3 | 401.0 | 1,162.6 | 1,106.2 | 1,636.8 | 1,600.7 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Total revenues | 994.3 | 945.2 | 2,816.8 | 2,701.5 | 3,805.7 | 3,751.1 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Cost of sales — services | -413.1 | -408.4 | -1,251.3 | -1,211.8 | -1,648.5 | -1,616.9 | USD millions | Reported; signs normalized as expenses | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Cost of sales — products | -334.0 | -291.7 | -865.7 | -808.3 | -1,196.0 | -1,214.2 | USD millions | Reported; signs normalized as expenses | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11–12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Total cost of sales | -747.1 | -700.1 | -2,117.0 | -2,020.1 | -2,844.5 | -2,831.1 | USD millions | Reported; signs normalized as expenses | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Gross profit | 247.2 | 245.1 | 699.8 | 681.4 | 961.2 | 920.0 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Selling and administrative expense | -172.2 | -150.9 | -491.7 | -456.9 | -632.5 | -643.6 | USD millions | Reported; signs normalized as expenses | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Research, development and engineering expense | -19.8 | -20.3 | -62.4 | -65.3 | -86.7 | -93.6 | USD millions | Reported; signs normalized as expenses | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Other operating expense (income) | -16.4 | -0.1 | -16.9 | 0.4 | Not supplied: filing prints dash | -0.7 | USD millions | Reported; source income shown as positive here only where relabelled | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Total costs and expenses below gross profit | -208.4 | -171.3 | -571.0 | -521.8 | -719.2 | -737.9 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Operating profit | 38.8 | 73.8 | 128.8 | 159.6 | 242.0 | 182.1 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Interest income | 5.6 | 2.1 | 10.6 | 6.1 | 8.9 | 12.3 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Interest expense | -26.7 | -21.8 | -74.1 | -65.1 | -85.7 | -155.3 | USD millions | Reported expense; cash interest is separately stated in cash-flow table | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Foreign exchange gain (loss), net | 0.5 | -0.8 | -4.2 | -41.5 | -44.1 | 13.8 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Miscellaneous, net | -2.9 | -0.9 | 3.0 | 3.2 | 4.0 | 1.5 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Loss on extinguishment of debt | Not supplied: no Q3 2026 value stated | Not supplied: no Q3 2025 value stated | Not supplied: no 9M 2026 value stated | Not supplied: no 9M 2025 value stated | Not supplied: filing prints dash | -7.1 | USD millions | Reported; annual filing prints dash for FY2025 | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Income before taxes | 15.3 | 52.4 | 64.1 | 62.3 | 125.1 | 47.3 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Income tax expense | 5.6 | 9.6 | 30.5 | 12.2 | 24.1 | 64.3 | USD millions | Reported expense; source presents expense as a positive amount | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Equity in earnings (loss) of unconsolidated subsidiaries, net | -2.6 | -1.1 | -4.7 | -3.1 | -3.5 | 2.5 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Net income (loss) | 7.1 | 41.7 | 28.9 | 47.0 | 97.5 | -14.5 | USD millions | Reported GAAP | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| Depreciation and amortization for EBITDA | 32.7 | 33.1 | 97.1 | 100.2 | 127.5 | 132.3 | USD millions | Reported; release measure differs from cash-flow D&A in 9M2026 by cloud-software amortization | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 14–15; 10-K_2025-12-31_dbd.htm.jsonl, page 56 |
| EBITDA (Reported) | 66.5 | 104.1 | 220.0 | 218.4 | 325.9 | 325.1 | USD millions | Q3/9M issuer-defined; annual values calculated using net income + tax + interest expense - interest income + D&A | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14; calculation C01–C04 |
| EBITDA (Adjusted) | 127.8 | 121.9 | 347.5 | 320.4 | Not supplied: FY2025 adjusted EBITDA not stated | Not supplied: FY2024 adjusted EBITDA not stated | USD millions | Issuer-adjusted; add-backs are shown in the Q3 bridge and release | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 8, 14–15 |

### T4.5 Cash flow statement

| Line item | FY2025 | FY2024 | 9M 2026 | 9M 2025 | Unit | Basis | Source |
|---|---:|---:|---:|---:|---|---|---|
| Net income (loss) | 97.5 | -14.5 | 28.9 | 47.0 | USD millions | Reported | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Depreciation and amortization | 127.5 | 132.3 | 93.7 | 96.8 | USD millions | Reported cash-flow add-back; excludes separately reported financing-cost amortization; Q3 release EBITDA D&A also includes cloud software amortization | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Amortization of deferred financing costs | 6.4 | 1.9 | 5.1 | 4.7 | USD millions | Reported non-cash adjustment | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Trade receivables change | 25.9 | 99.6 | 20.4 | 54.0 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Inventory change | 65.1 | 20.9 | -51.1 | -13.2 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Accounts payable change | -68.3 | -42.2 | 73.2 | -37.0 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Deferred revenue change | -21.4 | -34.6 | -50.1 | -45.7 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Sales tax and net VAT change | 17.8 | -19.1 | -34.8 | -11.6 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Accrued salaries, wages and commissions change | 9.4 | 29.0 | -33.2 | -17.3 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Income tax balance change | Not supplied: not separately presented in annual statement | Not supplied: not separately presented in annual statement | -68.0 | 3.3 | USD millions | Reported cash-flow source line for 9M periods | 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Restructuring accrual change | 24.7 | 5.8 | Not supplied: not separately presented in interim statement | Not supplied: not separately presented in interim statement | USD millions | Reported only in annual cash-flow statements | 10-K_2025-12-31_dbd.htm.jsonl, page 56 |
| Certain other assets and liabilities change | 12.6 | 2.7 | -31.0 | -18.3 | USD millions | Reported cash-flow source line | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Net Cash from Operating Activities | 300.7 | 149.2 | -29.3 | 83.2 | USD millions | Reported GAAP; nine-month outflow mainly reflects working capital and tax timing | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Capital expenditures | -37.4 | -17.4 | -19.0 | -22.6 | USD millions | Reported cash outflow; maintenance/growth split not stated | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Capitalized software development | -24.3 | -23.0 | -20.2 | -17.3 | USD millions | Reported investing cash outflow | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Free cash flow, calculated | 239.0 | 108.8 | -68.5 | 43.3 | USD millions | OCF less capital expenditure and capitalized software; working capital included | calculation C08 |
| Net Cash from Investing Activities | -97.6 | -45.5 | -8.5 | -59.0 | USD millions | Reported GAAP | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Payments for acquisitions, net of cash received | -24.5 | Not supplied: filing prints dash | Not supplied: filing prints dash | -18.4 | USD millions | Reported investing cash flow | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Revolver borrowings | Not supplied: filing prints dash | 270.0 | 37.0 | Not supplied: filing prints dash | USD millions | Reported gross cash flow; FY2024 includes old and new revolvers | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Revolver repayments | Not supplied: filing prints dash | -270.0 | -37.0 | Not supplied: filing prints dash | USD millions | Reported gross cash flow | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Exit Facility repayment | Not supplied: filing prints dash | -1,250.0 | Not supplied: not separately presented | Not supplied: not separately presented | USD millions | Reported refinancing cash flow | 10-K_2025-12-31_dbd.htm.jsonl, page 56 |
| Proceeds from 2030 notes | Not supplied: filing prints dash | 950.0 | Not supplied: not separately presented | Not supplied: not separately presented | USD millions | Reported financing cash flow; issuance in December 2024 | 10-K_2025-12-31_dbd.htm.jsonl, page 56 |
| Treasury share activity | -130.7 | Not supplied: filing prints dash | -154.9 | -79.6 | USD millions | Reported cash-flow total; includes repurchases and, in 2026, shares withheld for tax plus taxes/fees | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Net Cash from Financing Activities | -143.9 | -366.5 | -160.7 | -88.2 | USD millions | Reported GAAP | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| FX Effect on Cash | 16.8 | -18.2 | -3.9 | 15.3 | USD millions | Reported | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Net Cash Change | 76.0 | -281.0 | -202.4 | -48.7 | USD millions | Reported; operating + investing + financing + FX | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–12 |
| Opening Cash | 311.3 | 592.3 | 387.3 | 311.3 | USD millions | Reported cash, cash equivalents and restricted cash | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |
| Closing Cash | 387.3 | 311.3 | 184.9 | 262.6 | USD millions | Reported cash, cash equivalents and restricted cash | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 13 |
| Cash Interest Paid | 59.1 | 149.4 | 76.4 | 58.8 | USD millions | Cash interest paid; distinct from accrued interest expense | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 13 |
| Cash taxes paid | 57.2 | 56.1 | 75.1 | 35.9 | USD millions | Reported cash taxes paid | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 13 |

### T4.6 Balance sheet

| Line item | Q3 2026 | FY2025 | FY2024 | Unit | Basis | Source |
|---|---:|---:|---:|---|---|---|
| Cash & Equivalents | 184.9 | 387.3 | 311.3 | USD millions | Reported cash, cash equivalents and restricted cash; see liquidity restriction | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Short-term investments | Not supplied: filing prints dash | 29.1 | 16.9 | USD millions | Reported; Q3 dash is not assumed to be zero | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Trade receivables | 577.4 | 609.4 | 588.5 | USD millions | Reported, net of allowances | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Inventories | 561.7 | 521.0 | 528.1 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Prepaid expenses | 32.1 | 50.9 | 45.8 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Income tax receivables | 102.7 | Not supplied: not separately presented | Not supplied: not separately presented | USD millions | Reported separately only at Q3 2026 | 10-Q_2026-09-30_dbd.htm.jsonl, page 11 |
| Other current assets | 196.4 | 189.1 | 177.3 | USD millions | Annual reports aggregate some current tax balances here | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total current assets | 1,655.2 | 1,786.8 | 1,667.9 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Property, plant and equipment, net | 314.0 | 286.0 | 246.2 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Deferred income tax assets | 114.5 | 105.0 | 69.5 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Goodwill | 626.2 | 642.4 | 586.4 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Customer relationships and other intangible assets, net | 725.8 | 792.4 | 778.6 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Other assets | 227.7 | 241.8 | 194.9 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total Assets | 3,663.4 | 3,854.4 | 3,543.5 | USD millions | Reported; ties to liabilities and equity | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Accounts payable | 493.0 | 431.1 | 460.2 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Deferred revenue | 254.1 | 325.8 | 320.7 | USD millions | Contract liabilities / customer advances; not debt | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11, 15; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Payroll and other benefits liabilities | 159.2 | 201.6 | 173.2 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Accrued taxes | 111.1 | Not supplied: included in annual other current liabilities | Not supplied: included in annual other current liabilities | USD millions | Q3 2026 line separated; annual line is aggregated | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Other current liabilities | 285.8 | 413.0 | 312.2 | USD millions | Q3 separate from accrued taxes; annual reports aggregate tax balances | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total current liabilities | 1,303.2 | 1,371.5 | 1,266.3 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total Debt | 949.3 | 938.5 | 927.3 | USD millions | Long-term debt at carrying value after deferred financing fees; no current financial borrowing reported | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11, 17; 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 |
| Pensions, post-retirement and other benefits | 111.8 | 120.4 | 124.4 | USD millions | Reported liability; outside debt | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Deferred income tax liabilities | 195.5 | 200.7 | 176.8 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Other liabilities | 159.5 | 118.5 | 110.5 | USD millions | Includes non-current operating lease liabilities; lease obligations remain outside reported debt lines unless included within long-term debt | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total Liabilities | 2,719.3 | 2,749.6 | 2,605.3 | USD millions | Reported | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |
| Total Equity | 944.1 | 1,104.8 | 938.2 | USD millions | Includes noncontrolling interests | 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54 |

### T4.18 Debt instruments

| Instrument | Type | Carrying Value | Principal | Drawn | Commitment | Security | Ranking | Currency | Reporting Currency Amount | FX Rate | Coupon or Margin | Rate Type | Reference Rate | Spread (bps) | Floor (bps) | Maturity | Annual Amortisation | Source |
|---|---|---:|---:|---:|---:|---|---|---|---:|---|---|---|---|---|---|---|---|---|
| 2030 Senior Secured Notes | Senior secured notes | Not supplied: carrying value not disclosed separately | 950.0 | Not applicable | Not applicable | First-priority liens on substantially all tangible and intangible assets of issuer and Guarantors, subject to exclusions and permitted liens | 1; pari passu with revolving facility | USD | 950.0 | Not applicable | 7.75% | Fixed | Not applicable | Not applicable | Not applicable | 2030-03-31 | 0.0 | 10-K_2025-12-31_dbd.htm.jsonl, page 78 |
| Revolving Credit Facility | Revolving credit facility | 0.0 | 0.0 | 0.0 | 310.0 | First-priority liens on substantially all assets of issuer and Guarantors, subject to exclusions and permitted liens | 1; pari passu with notes | USD | 0.0 | Not applicable | Adjusted SOFR + 2.75%–3.50%; adjusted base rate + 1.75%–2.50% | Floating | SOFR or adjusted base rate | 275–350 SOFR; 175–250 base rate | 0 bp SOFR floor | 2029-12-18 | 0.0 | 10-Q_2026-09-30_dbd.htm.jsonl, pages 17–18; 10-K_2025-12-31_dbd.htm.jsonl, page 79 |
| Other long-term debt | Type not stated in Q3 debt note | Not supplied: instrument-level carrying value not stated | Not supplied: contractual principal not identified | Not supplied: drawn amount is not separately identified | Not applicable | Not supplied: security is not stated | Not supplied: legal ranking is not stated | USD | 26.4 | Not applicable | Not supplied: rate not stated | Not stated | Not supplied: reference rate not stated | Not supplied: spread not stated | Not supplied: floor not stated | Not supplied: maturity not stated | Not supplied: schedule not stated | 10-Q_2026-09-30_dbd.htm.jsonl, page 17 |
| Deferred financing cost adjustment | Aggregate contra-debt costs | -27.1 | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | USD | -27.1 | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | Not applicable | 10-Q_2026-09-30_dbd.htm.jsonl, page 17 |

### T4.8 Constructed period register

| Metric Name | Derived Period Type | Full-Year Component (USD millions) | Current Stub (USD millions) | Prior-Year Stub (USD millions) | Derived Value (USD millions) | Calculation Status | Source Files | Limitations |
|---|---|---:|---:|---:|---:|---|---|---|
| Revenue | LTM to 2026-09-30 | 3,805.7 | 2,816.8 | 2,701.5 | 3,921.0 | Calculated | 10-K_2025-12-31_dbd.htm.jsonl; 10-Q_2026-09-30_dbd.htm.jsonl | FY2025 plus 9M 2026 less 9M 2025 |
| EBITDA (Reported) | LTM to 2026-09-30 | 325.9 | 220.0 | 218.4 | 327.5 | Calculated | 10-K_2025-12-31_dbd.htm.jsonl; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl | Annual EBITDA calculated using issuer definition; interim values issuer-reported |
| Cash interest paid | LTM to 2026-09-30 | 59.1 | 76.4 | 58.8 | 76.7 | Calculated | 10-K_2025-12-31_dbd.htm.jsonl; 10-Q_2026-09-30_dbd.htm.jsonl | Cash interest, not income-statement interest expense |
| Operating cash flow | LTM to 2026-09-30 | 300.7 | -29.3 | 83.2 | 188.2 | Calculated | 10-K_2025-12-31_dbd.htm.jsonl; 10-Q_2026-09-30_dbd.htm.jsonl | FY2025 + 9M 2026 - 9M 2025 |
| Free cash flow | LTM to 2026-09-30 | 239.0 | -68.5 | 43.3 | 127.2 | Calculated | 10-K_2025-12-31_dbd.htm.jsonl; 10-Q_2026-09-30_dbd.htm.jsonl | OCF less physical capex and capitalized software; includes working capital |
| EBITDA (Adjusted) | LTM to 2026-09-30 | Not supplied: FY2025 adjusted EBITDA not stated | 347.5 | 320.4 | Not calculable: full-year component missing | Not Calculable | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl | Pinned sources do not state FY2025 adjusted EBITDA; no LTM adjusted EBITDA or adjusted leverage is produced |

### T4.9 Calculation register

| Metric Name | Formula | Numerator Value | Numerator Source | Denominator Value | Denominator Source | Period | Currency | Unit | Calculated Value | Calculation Status | Evidence Quality Tier | Limitations |
|---|---|---:|---|---:|---|---|---|---|---:|---|---|---|
| Total debt / EBITDA | Carrying debt / reported EBITDA | 927.3 | 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 | 325.1 | 10-K_2025-12-31_dbd.htm.jsonl, page 55; calculation C01 | FY2024 / 2024-12-31 | USD | US$m | 2.85 | Calculated | Tier 1 | EBITDA calculated using issuer definition |
| Net debt / EBITDA | Carrying debt less reported cash / reported EBITDA | 616.0 | Calculation C07 | 325.1 | 10-K_2025-12-31_dbd.htm.jsonl, page 55; calculation C01 | FY2024 / 2024-12-31 | USD | US$m | 1.89 | Calculated | Tier 1 | Cash includes restricted cash |
| EBITDA / cash interest | Reported EBITDA / cash interest paid | 325.1 | 10-K_2025-12-31_dbd.htm.jsonl, page 55; calculation C01 | 149.4 | 10-K_2025-12-31_dbd.htm.jsonl, page 56 | FY2024 / 2024-12-31 | USD | US$m | 2.18 | Calculated | Tier 1 | Interest denominator is cash paid |
| Total debt / EBITDA | Carrying debt / reported EBITDA | 938.5 | 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 | 325.9 | 10-K_2025-12-31_dbd.htm.jsonl, page 55; calculation C02 | FY2025 / 2025-12-31 | USD | US$m | 2.88 | Calculated | Tier 1 | EBITDA calculated using issuer definition |
| Net debt / EBITDA | Carrying debt less reported cash / reported EBITDA | 551.2 | Calculation C08 | 325.9 | 10-K_2025-12-31_dbd.htm.jsonl, page 55; calculation C02 | FY2025 / 2025-12-31 | USD | US$m | 1.69 | Calculated | Tier 1 | Cash includes restricted cash; short-term investments excluded |
| EBITDA / cash interest | Reported EBITDA / cash interest paid | 325.9 | Calculation C02 | 59.1 | 10-K_2025-12-31_dbd.htm.jsonl, page 56 | FY2025 / 2025-12-31 | USD | US$m | 5.51 | Calculated | Tier 1 | Interest denominator is cash paid |
| Total debt / EBITDA | Carrying debt / reported LTM EBITDA | 949.3 | 10-Q_2026-09-30_dbd.htm.jsonl, page 17 | 327.5 | Calculation C04 | 2026-09-30 | USD | US$m | 2.90 | Calculated | Tier 2b | Interim numerator; LTM denominator |
| Net debt / EBITDA | Carrying debt less reported cash / reported LTM EBITDA | 764.4 | Calculation C06 | 327.5 | Calculation C04 | 2026-09-30 | USD | US$m | 2.33 | Calculated | Tier 2b | Cash includes restricted cash |
| EBITDA / cash interest | Reported LTM EBITDA / LTM cash interest paid | 327.5 | Calculation C04 | 76.7 | Calculation C05 | 2026-09-30 | USD | US$m | 4.27 | Calculated | Tier 2b | FY2025 plus current stub less prior-year stub |
| Total debt / adjusted EBITDA | Carrying debt / adjusted EBITDA | 949.3 | 10-Q_2026-09-30_dbd.htm.jsonl, page 17 | Not calculable: LTM adjusted EBITDA is not supplied | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14; T4.8 | 2026-09-30 | USD | US$m | Not calculable: LTM adjusted EBITDA is not supplied | Not Calculable | Tier 2b | FY2025 adjusted EBITDA is not stated |
| Net debt / adjusted EBITDA | Carrying-value net debt / adjusted EBITDA | 764.4 | Calculation C06 | Not calculable: LTM adjusted EBITDA is not supplied | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14; T4.8 | 2026-09-30 | USD | US$m | Not calculable: LTM adjusted EBITDA is not supplied | Not Calculable | Tier 2b | FY2025 adjusted EBITDA is not stated |
| Adjusted EBITDA / cash interest | Adjusted EBITDA / cash interest paid | Not calculable: LTM adjusted EBITDA is not supplied | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14; T4.8 | 76.7 | Calculation C05 | 2026-09-30 | USD | US$m | Not calculable: LTM adjusted EBITDA is not supplied | Not Calculable | Tier 2b | FY2025 adjusted EBITDA is not stated |

### T4.10 KPI dashboard

| KPI Category | Metric Name | FY2025 | FY2024 | Q3 2026 | Q3 2025 | 9M 2026 | 9M 2025 | Trend Direction | Analyst Note |
|---|---|---:|---:|---:|---:|---:|---:|---|---|
| Revenue | Consolidated revenue (USD millions) | 3,805.7 | 3,751.1 | 994.3 | 945.2 | 2,816.8 | 2,701.5 | Higher | Q3/9M totals are GAAP; annual periods are audited Successor results |
| Segment revenue | Banking (USD millions) | 2,797.0 | 2,762.8 | 698.2 | 690.2 | 1,960.6 | 1,999.0 | Mixed | Q3 Banking increased; 9M Banking declined due lower product volumes |
| Segment revenue | Retail (USD millions) | 1,008.7 | 988.3 | 296.1 | 255.0 | 856.2 | 702.5 | Higher | Retail is the principal growth contributor in 2026 |
| Profitability | Reported EBITDA (USD millions) | 325.9 | 325.1 | 66.5 | 104.1 | 220.0 | 218.4 | Mixed | Annual EBITDA calculated under issuer definition; quarterly figures issuer-reported |
| Profitability | Adjusted EBITDA (USD millions) | Not supplied: annual figure not stated | Not supplied: annual figure not stated | 127.8 | 121.9 | 347.5 | 320.4 | Higher | Issuer-adjusted figures include restructuring, share compensation and other exclusions |
| Margin | GAAP gross margin | 25.3% | 24.5% | 24.9% | 25.9% | 24.8% | 25.2% | Lower | Q3 gross margin declined year over year as product margin pressure outweighed service gains |
| Cash flow | Operating cash flow (USD millions) | 300.7 | 149.2 | -47.4 | 37.4 | -29.3 | 83.2 | Lower | Nine-month working capital and tax uses offset positive EBITDA |
| Cash flow | Free cash flow (USD millions) | 239.0 | 108.8 | -60.3 | 24.5 | -68.5 | 43.3 | Lower | Calculated annual/YTD values include capitalized software; Q3 values issuer-reported |

### T4.11 Definition conflict register

| Metric Name | Canonical Definition | Issuer-Reported Definition | Source of Conflict | Periods Affected | Materiality | Modules Affected | Resolution / Recommendation |
|---|---|---|---|---|---|---|---|
| Gross debt / principal | Gross debt is balance-sheet carrying value net of deferred issuance costs | Q3 issuer “debt instruments” and net-debt calculation use USD 976.4 million before USD 27.1 million deferred fees; balance-sheet carrying debt is USD 949.3 million | 10-Q_2026-09-30_dbd.htm.jsonl, page 17; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 16 | 2026-09-30 | Material: USD 27.1 million changes net debt and leverage | Financial foundation; Fundamental credit | Use USD 949.3 million carrying value for leverage; retain USD 976.4 million as issuer debt-instrument amount and disclose the fee difference |
| Net debt | Carrying debt less balance-sheet cash, with cash definition shown | Company net debt uses debt-instrument amount before financing fees and includes restricted cash and short-term investments where present | 10-Q_2026-09-30_dbd.htm.jsonl, page 17; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 16; 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 | FY2025 and 2026-09-30 | Material: issuer net debt is USD 791.5 million at Q3; calculated carrying-value net debt is USD 764.4 million | Financial foundation; Fundamental credit | Present both definitions, do not substitute issuer figure into carrying-value ratios |
| EBITDA (Reported) | Net income excluding income tax, net interest and depreciation and amortization under issuer's definition | 2026 release D&A includes cloud-software amortization not present in the cash-flow D&A row; FY EBITDA is calculated where annual issuer EBITDA is not printed | 10-Q_2026-09-30_dbd.htm.jsonl, page 12; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 14–15 | FY2024–Q3 2026 | Moderate: definitions differ by USD 3.4 million for 9M 2026 D&A | Financial foundation; Fundamental credit | Use issuer’s EBITDA reconciliation for interim periods and the same formula from annual statements; keep cash-flow D&A separate |
| Share repurchases | Cash outflow from treasury-share activity | Q1–Q3 disclosed program purchases total USD 148.6 million, while cash-flow treasury activity is USD 154.9 million including USD 1.5 million taxes/fees and USD 4.8 million tax-withheld shares; rounded quarterly amounts sum to USD 148.5 million | 10-Q_2026-09-30_dbd.htm.jsonl, pages 10, 19; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 1 | 9M 2026 | Minor: source totals differ by USD 0.1 million across rounded program quarters | Financial foundation; Fundamental credit | Use the filing's aggregate USD 148.6 million program figure for program repurchases and USD 154.9 million for total treasury cash flow |

### T4.13 Readiness

| Requested Use | Readiness Status | Gaps or Limitations | Recommended Actions |
|---|---|---|---|
| Q3 2026 financial foundation and issuer-grounded credit metrics | Ready with Limitations | Latest interim financial statements, debt carrying value, cash and cash flow are available. Q3 “Other” long-term debt of USD 26.4 million has no instrument description or maturity; annual debt maturity schedule is as of FY2025; covenant levels and current compliance calculations are not reported. | Use carrying-value debt and cash definitions shown here; obtain executed credit agreement, current compliance certificate and updated maturity schedule before stating covenant headroom or maturity timing for “Other” debt. |

### Confidence inputs

| Input | Value |
|---|---|
| Directly Sourced | 59 |
| Calculated | 21 |
| Assumption-Based | 0 |
| Analyst Inference | 7 |
| Weak Lineage | 0 |
| Untraced | 0 |
| Conflicting | 4 |
| Insufficient Information | 11 |
| Fields present | 13 |
| Fields total | 13 |
| Source gate | pass |
| CRITICAL | 0 |
| MATERIAL | 2 |
| MINOR | 2 |

### Limitations

The supplied filings support operating and financial reconstruction, but they do not include executed debt agreements or a current compliance certificate. Maintenance-test thresholds, covenant headroom and the legal scope of exceptions are therefore not established; the revolving-rate margin grid is not a maintenance covenant test.
Basis: 10-K_2025-12-31_dbd.htm.jsonl, page 79; 10-Q_2026-09-30_dbd.htm.jsonl, pages 17–18

### Credit analysis

Revenue reached USD 2,816.8 million in 9M 2026, up 4.3% year over year, but growth was concentrated in Retail: 9M Banking revenue declined 1.9% while Retail rose 21.9%. This exposes the credit story to product mix: Retail growth supports scale, while lower Banking product volumes and Q3 product-margin pressure can offset higher product volumes and pricing. Services gross margin benefited from VAT credits and execution, but those credits are not a repeatable substitute for durable product economics.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 6–8; calculation C09

Reported EBITDA was USD 220.0 million for 9M 2026, while adjusted EBITDA was USD 347.5 million. The USD 127.5 million gap comprises USD 78.2 million of restructuring and savings expenses, USD 16.9 million of investment impairment, USD 10.8 million for the non-core Turkey operation and other issuer-listed items. These adjustments raise the headline measure by 58% versus reported EBITDA; their scale makes sustainable cash earnings less certain, especially because the non-core Turkey adjustment removes a loss and restructuring savings are not yet fully realized.
Basis: EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 8, 14–15; calculation C10

The cash conversion break is clearer than the adjusted EBITDA trend: 9M 2026 operating cash flow was negative USD 29.3 million and FCF was negative USD 68.5 million, compared with positive USD 83.2 million and USD 43.3 million, respectively, in 9M 2025. Inventory, deferred revenue, tax and payroll movements drove a net USD 174.6 million cash use in the listed asset and liability changes; cash flow before those movements was USD 145.3 million. Debt service capacity therefore depends on collections, inventory turns and timing of tax payments, not adjusted EBITDA alone.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–13; calculation C13

Carrying-value gross leverage was 2.90x and net leverage 2.33x at September 30, 2026, compared with FY2025 levels of 2.88x and 1.69x. Carrying debt increased only USD 10.8 million from year-end, but reported cash fell USD 202.4 million, lifting calculated net debt by USD 213.2 million. LTM cash-interest cover was 4.27x, below FY2025’s 5.51x but above FY2024’s 2.18x; lower annual cash interest after the December 2024 refinancing improved cover, while the Q3 2026 cash decline weakened net leverage.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–13, 17; 10-K_2025-12-31_dbd.htm.jsonl, pages 54–56, 78; calculation C04; calculation C05; calculation C06; calculation C08

Liquidity at September 30 included USD 169.0 million unrestricted cash after excluding USD 15.9 million restricted cash, plus USD 285.8 million net committed revolver availability after USD 24.2 million of letters of credit, for USD 454.8 million. The revolving facility matures on December 18, 2029, not within the next twelve months. Yet the business consumed USD 68.5 million of FCF in 9M 2026, paid USD 75.1 million of cash taxes and returned USD 148.6 million through its share repurchase program; an additional USD 19.3 million was repurchased after quarter-end. Further German cash taxes and a new USD 250 million authorization can compete with operating investment for the same liquidity buffer.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 9–10, 13, 17, 23; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 1, 3, 7; calculation C11; calculation C12

The funded debt stack is concentrated in USD 950.0 million of 7.75% senior secured notes due March 2030; the USD 310 million revolver is undrawn, but USD 24.2 million of letters of credit consume capacity. The notes and revolver share first-priority collateral and are guaranteed by specified domestic subsidiaries. Separately, operating lease liabilities were USD 175.6 million at Q3 2026 and pension, post-retirement and other benefit obligations were USD 111.8 million; these are outside debt carrying value. The financial statement's USD 26.4 million “Other” debt balance prevents a complete current maturity wall or legal-priority analysis.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 11, 14, 17–18, 23; 10-K_2025-12-31_dbd.htm.jsonl, pages 78–79, 89–90

Customer contract liabilities also fund working capital: deferred revenue declined from USD 325.8 million at year-end to USD 254.1 million at Q3, while the cash flow statement records a USD 50.1 million nine-month use from deferred revenue. That shrinkage removes part of the customer-advance float supporting operations, increasing reliance on collections and external liquidity if demand or service billings soften. The available sources do not identify factoring or supplier-finance programs.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, pages 11–15; 10-K_2025-12-31_dbd.htm.jsonl, pages 89–90

## Calculations

| ID | Formula and inputs | Result | Source / locator |
|---|---|---:|---|
| C01 | FY2024 EBITDA = net income -14.5 + tax expense 64.3 + interest expense 155.3 - interest income 12.3 + D&A 132.3 | USD 325.1 million | 10-K_2025-12-31_dbd.htm.jsonl, page 55 |
| C02 | FY2025 EBITDA = net income 97.5 + tax expense 24.1 + interest expense 85.7 - interest income 8.9 + D&A 127.5 | USD 325.9 million | 10-K_2025-12-31_dbd.htm.jsonl, pages 55–56 |
| C03 | Net debt at 2024-12-31 = carrying debt 927.3 - cash and restricted cash 311.3 | USD 616.0 million | 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 |
| C04 | LTM EBITDA = FY2025 EBITDA 325.9 + 9M 2026 EBITDA 220.0 - 9M 2025 EBITDA 218.4 | USD 327.5 million | 10-K_2025-12-31_dbd.htm.jsonl, pages 55–56; EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14 |
| C05 | LTM cash interest = FY2025 cash interest 59.1 + 9M 2026 cash interest 76.4 - 9M 2025 cash interest 58.8 | USD 76.7 million | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, page 13 |
| C06 | Net debt at 2026-09-30 = carrying debt 949.3 - cash and restricted cash 184.9 | USD 764.4 million | 10-Q_2026-09-30_dbd.htm.jsonl, pages 11, 17 |
| C07 | Net debt at 2024-12-31 = carrying debt 927.3 - cash and restricted cash 311.3 | USD 616.0 million | 10-K_2025-12-31_dbd.htm.jsonl, pages 54, 78 |
| C08 | FY2025/FY2024/9M2026/9M2025 FCF = OCF less capex less capitalized software: 300.7-37.4-24.3; 149.2-17.4-23.0; -29.3-19.0-20.2; 83.2-22.6-17.3 | USD 239.0 / 108.8 / -68.5 / 43.3 million | 10-K_2025-12-31_dbd.htm.jsonl, page 56; 10-Q_2026-09-30_dbd.htm.jsonl, pages 12–13 |
| C09 | LTM revenue = FY2025 revenue 3,805.7 + 9M 2026 revenue 2,816.8 - 9M 2025 revenue 2,701.5 | USD 3,921.0 million | 10-K_2025-12-31_dbd.htm.jsonl, page 55; 10-Q_2026-09-30_dbd.htm.jsonl, page 11 |
| C10 | 9M 2026 adjusted EBITDA premium = adjusted EBITDA 347.5 - reported EBITDA 220.0 | USD 127.5 million | EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14 |
| C11 | Unrestricted liquidity = (cash and restricted cash 184.9 - restricted cash 15.9) + (revolver commitment 310.0 - LCs 24.2) | USD 454.8 million | 10-Q_2026-09-30_dbd.htm.jsonl, pages 9, 11, 23 |
| C12 | Mechanical pro forma net debt after post-quarter repurchases = net debt 764.4 + cash repurchased 19.3; leverage = 783.7 / LTM EBITDA 327.5 | USD 783.7 million; 2.39x | 10-Q_2026-09-30_dbd.htm.jsonl, page 10; calculation C04; calculation C06 |
| C13 | 9M 2026 working-capital/asset-liability cash effect = 20.4 - 51.1 - 34.8 + 73.2 - 50.1 - 33.2 - 68.0 - 31.0; OCF before listed changes = -29.3 - (-174.6) | USD -174.6 million; USD 145.3 million | 10-Q_2026-09-30_dbd.htm.jsonl, page 12 |

## Gaps

- The latest debt note gives USD 26.4 million as “Other” long-term debt but provides no instrument description, rate, security, rank or maturity. This prevents a complete maturity schedule and a full instrument-level carrying/principal reconciliation. Severity: Medium. Obtain the current debt schedule and underlying instrument note.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, page 17

- The latest filed debt agreement summary does not state maintenance covenant thresholds, steps or current covenant calculations; the pricing grid based on a first-lien debt ratio is not a maintenance test. Headroom and covenant capacity are not calculable. Severity: High. Obtain the executed credit agreement and a current compliance certificate.
Basis: 10-K_2025-12-31_dbd.htm.jsonl, pages 78–79; 10-Q_2026-09-30_dbd.htm.jsonl, pages 17–18

- No current debt repayment calendar for the USD 26.4 million “Other” balance is provided. The FY2025 contractual schedule identifies USD 950.0 million of notes due in 2030 and separately lists finance lease payments; the annual schedule is not an updated Q3 2026 maturity ladder. Severity: Medium. Obtain the current contractual debt and lease maturity schedule.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, page 17; 10-K_2025-12-31_dbd.htm.jsonl, page 19

- The quarterly filing does not update finance-lease liability detail; FY2025 disclosed USD 6.1 million current and USD 20.7 million non-current finance-lease liabilities, with non-current finance leases included in long-term debt. The identity of the Q3 “Other” debt balance is not confirmed. Severity: Medium. Obtain the Q3 finance-lease note or current lease-liability roll-forward.
Basis: 10-K_2025-12-31_dbd.htm.jsonl, pages 89–90; 10-Q_2026-09-30_dbd.htm.jsonl, page 17

- FY2025 and FY2024 annual adjusted EBITDA are not stated in the supplied filings, so adjusted EBITDA LTM, adjusted leverage and a comparable annual adjusted EBITDA bridge cannot be constructed. Severity: Medium. Obtain annual issuer reconciliations or calculate only if all issuer-defined bridge items are available.
Basis: EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, page 14; 10-K_2025-12-31_dbd.htm.jsonl, pages 55–56

- The Q3 disclosure estimates approximately USD 50 million of 2024 and 2025 German cash taxes during 2026, but does not state the full-year 2026 cash-tax amount or exact Q4 payment date. Severity: Medium. Update liquidity after the tax payments are made and disclosed.
Basis: EX99.1_2026-09-30_dbd_ex-991q32026erlive-htm.htm.jsonl, pages 3, 7

- The 2026 interim statements separate accrued taxes and other current liabilities, while annual statements aggregate some of those balances; current tax receivables are likewise separately reported only in Q3. A direct line-by-line annual-to-interim current-liability comparison is not fully normalized. Severity: Low. Retain the filing presentation and use total current liabilities for comparisons.
Basis: 10-Q_2026-09-30_dbd.htm.jsonl, page 11; 10-K_2025-12-31_dbd.htm.jsonl, page 54

- No factoring, reverse-factoring, supplier-finance or accounts-receivable sale program was identified in the pinned source text after searching those terms and their common synonyms. Severity: Low. Treat the absence as “not disclosed in supplied filings,” not as proof that no program exists.
Basis: 10-K_2025-12-31_dbd.htm.jsonl, pages 62–63, 90–93; 10-Q_2026-09-30_dbd.htm.jsonl, pages 12–13, 22–23

## Next module

The orchestrator selects the next module.
